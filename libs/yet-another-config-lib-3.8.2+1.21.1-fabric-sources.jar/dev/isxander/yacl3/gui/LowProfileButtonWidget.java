package dev.isxander.yacl3.gui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_7919;

public class LowProfileButtonWidget extends /*? if >=1.21.11 {*//*Button.Plain*//*?} else {*/class_4185/*?}*/ {
    public LowProfileButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    public LowProfileButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress, class_7919 tooltip) {
        this(x, y, width, height, message, onPress);
        method_47400(tooltip);
    }

    //? if >=1.21.11 {
    /*@Override
    protected void renderContents(GuiGraphics guiGraphics, int i, int j, float f) {
        if (isHoveredOrFocused() && isActive()) {
            this.renderDefaultSprite(guiGraphics);
        }
        this.renderDefaultLabel(guiGraphics.textRendererForWidget(this, GuiGraphics.HoveredTextEffects.NONE));
    }
    *///?} else {
    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float deltaTicks) {
        if (!method_25367() || !field_22763) {
            int j = this.field_22763 ? 0xFFFFFFFF : 0xFFA0A0A0;
            this.method_48589(graphics, class_310.method_1551().field_1772, j);
        } else {
            super.method_48579(graphics, mouseX, mouseY, deltaTicks);
        }
    }
    //?}
}
