package dev.isxander.yacl3.gui;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public class TooltipButtonWidget extends /*? if >=1.21.11 {*//*Button.Plain*//*?} else {*/class_4185/*?}*/ {

    protected final class_437 screen;

    public TooltipButtonWidget(class_437 screen, int x, int y, int width, int height, class_2561 message, class_2561 tooltip, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
        this.screen = screen;
        if (tooltip != null)
            method_47400(class_7919.method_47407(tooltip));
    }
}
