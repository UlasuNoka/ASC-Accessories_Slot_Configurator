package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.gui.image.ImageRenderer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_3673;
import net.minecraft.class_3675;
import net.minecraft.class_5481;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import net.minecraft.class_8030;

//? if >=1.21.9 {
/*import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
*///?}

public class OptionDescriptionWidget extends class_339 {
    private static final int AUTO_SCROLL_TIMER = 1500;
    private static final float AUTO_SCROLL_SPEED = 1; // lines per second

    private @Nullable DescriptionWithName description;
    private List<class_5481> wrappedText;

    private static final class_310 minecraft = class_310.method_1551();
    private static final class_327 font = minecraft.field_1772;

    private Supplier<class_8030> dimensions;

    private float targetScrollAmount, currentScrollAmount;
    private int maxScrollAmount;
    private int descriptionY;

    private int lastInteractionTime;
    private boolean scrollingBackward;

    public OptionDescriptionWidget(Supplier<class_8030> dimensions, @Nullable DescriptionWithName description) {
        super(0, 0, 0, 0, description == null ? class_2561.method_43473() : description.name());
        this.dimensions = dimensions;
        this.setOptionDescription(description);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float delta) {
        if (description == null) return;

        currentScrollAmount = class_3532.method_16439(delta * 0.5f, currentScrollAmount, targetScrollAmount);

        class_8030 dimensions = this.dimensions.get();
        this.method_46421(dimensions.method_49620());
        this.method_46419(dimensions.method_49618());
        this.field_22758 = dimensions.comp_1196();
        this.field_22759 = dimensions.comp_1197();

        int y = method_46427();

        int nameWidth = font.method_27525(description.name());
        if (nameWidth > method_25368()) {
            //? if >=1.21.11 {
            /*graphics.textRendererForWidget(this, GuiGraphics.HoveredTextEffects.TOOLTIP_ONLY)
                    .acceptScrollingWithDefaultCenter(description.name(), getX(), getX() + getWidth(), y, y + font.lineHeight);
            *///?} else {
            method_52718(graphics, font, description.name(), method_46426(), y, method_46426() + method_25368(), y + font.field_2000, -1);
            //?}
        } else {
            graphics.method_27535(font, description.name(), method_46426(), y, 0xFFFFFFFF);
        }

        y += 5 + font.field_2000;

        graphics.method_44379(method_46426(), y, method_46426() + method_25368(), method_46427() + method_25364());

        y -= (int)currentScrollAmount;

        if (description.description().image().isDone()) {
            var image = description.description().image().join();
            if (image.isPresent()) {
                y += image.get().render(graphics, method_46426(), y, method_25368(), delta) + 5;
            }
        }

        if (wrappedText == null)
            wrappedText = font.method_1728(description.description().text(), method_25368());

        descriptionY = y;
        for (var line : wrappedText) {
            //? if >=1.21.11 {
            /*graphics.textRenderer(GuiGraphics.HoveredTextEffects.TOOLTIP_AND_CURSOR)
                    .accept(getX(), y, line);
            *///?} else {
            graphics.method_35720(font, line, method_46426(), y, 0xFFFFFFFF);
            //?}
            y += font.field_2000;
        }

        graphics.method_44380();

        maxScrollAmount = Math.max(0, y + (int)currentScrollAmount - method_46427() - method_25364());

        if (method_25367()) {
            lastInteractionTime = currentTimeMS();
        }
        class_2583 hoveredStyle = getDescStyle(mouseX, mouseY);
        if (hoveredStyle != null && hoveredStyle.method_10969() != null) {
            graphics.method_51441(font, hoveredStyle, mouseX, mouseY);
        }

        if (method_25370()) {
            graphics./*? if >=1.21.9 && <1.21.11 {*//*submitOutline*//*?} else {*/method_49601/*?}*/(method_46426(), method_46427(), method_25368(), method_25364(), -1);
        }
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        return this.onMouseClicked(mouseButtonEvent.x(), mouseButtonEvent.y());
    }
    *///?} else {
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return this.onMouseClicked(mouseX, mouseY);
    }
    //?}

    protected boolean onMouseClicked(double mouseX, double mouseY) {
        class_2583 clickedStyle = getDescStyle((int) mouseX, (int) mouseY);
        if (clickedStyle != null && clickedStyle.method_10970() != null) {
            // TODO: reimplement
            //? if <1.21.11 {
            if (minecraft.field_1755.method_25430(clickedStyle)) {
                method_25354(minecraft.method_1483());
                return true;
            }
            //?}
            return false;
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        if (method_25405(mouseX, mouseY)) {
            targetScrollAmount = class_3532.method_15363(targetScrollAmount - (int) vertical * 10, 0, maxScrollAmount);
            lastInteractionTime = currentTimeMS();
            return true;
        }
        return false;
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean keyPressed(KeyEvent keyEvent) {
        return this.onKeyPressed(keyEvent.key());
    }
    *///?} else {
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return this.onKeyPressed(keyCode);
    }
    //?}
    protected boolean onKeyPressed(int keyCode) {
        if (method_25370()) {
            switch (keyCode) {
                case class_3675.field_31932 ->
                        targetScrollAmount = class_3532.method_15363(targetScrollAmount - 10, 0, maxScrollAmount);
                case class_3675.field_31982 ->
                        targetScrollAmount = class_3532.method_15363(targetScrollAmount + 10, 0, maxScrollAmount);
                default -> {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public void tick() {
        if (description != null) {
            description.description().image()
                    .getNow(Optional.empty())
                    .ifPresent(ImageRenderer::tick);
        }

        float pxPerTick = AUTO_SCROLL_SPEED / 20f * font.field_2000;
        if (maxScrollAmount > 0 && currentTimeMS() - lastInteractionTime > AUTO_SCROLL_TIMER) {
            if (scrollingBackward) {
                pxPerTick *= -1;
                if (targetScrollAmount + pxPerTick < 0) {
                    scrollingBackward = false;
                    lastInteractionTime = currentTimeMS();
                }
            } else {
                if (targetScrollAmount + pxPerTick > maxScrollAmount) {
                    scrollingBackward = true;
                    lastInteractionTime = currentTimeMS();
                }
            }

            targetScrollAmount = class_3532.method_15363(targetScrollAmount + pxPerTick, 0, maxScrollAmount);
        }
    }

    private class_2583 getDescStyle(int mouseX, int mouseY) {
        boolean clicked = /*? if >=1.21.4 {*/ /*isMouseOver(mouseX, mouseY) *//*?} else {*/ method_25361(mouseX, mouseY) /*?}*/;
        if (!clicked)
            return null;

        int x = mouseX - method_46426();
        int y = mouseY - descriptionY;

        if (x < 0 || x > method_46426() + method_25368()) return null;
        if (y < 0 || y > method_46427() + method_25364()) return null;

        int line = y / font.field_2000;

        if (line >= wrappedText.size()) return null;

        // TODO reimplement
        //? if >=1.21.11 {
        /*return null;
        *///?} else {
        return font.method_27527().method_30876(wrappedText.get(line), x);
        //?}
    }

    @Override
    protected void method_47399(class_6382 builder) {
        if (description != null) {
            builder.method_37034(class_6381.field_33788, description.name());
            builder.method_37034(class_6381.field_33790, description.description().text());
        }

    }

    public void setOptionDescription(DescriptionWithName description) {
        this.description = description;
        this.wrappedText = null;
        this.targetScrollAmount = 0;
        this.currentScrollAmount = 0;
        this.lastInteractionTime = currentTimeMS();
    }

    private int currentTimeMS() {
        return (int)(class_3673.method_15974() * 1000);
    }

    @Nullable
    @Override
    public class_8016 method_48205(class_8023 event) {
        // prevents focusing on this widget
        return null;
    }

}
