package dev.isxander.yacl3.gui.utils;

import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class MiscUtil {
    public static <T> T getFromRegistry(class_2378<T> registry, class_2960 identifier) {
        //? if >=1.21.2 {
        /*return registry.getValue(identifier);
        *///?} else {
        return registry.method_10223(identifier);
        //?}
    }
}
