package dev.isxander.yacl3.gui.utils;

import net.minecraft.class_364;

//? if >=1.21.9 {
/*import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
*///?}

public final class WidgetUtils {

    public static boolean mouseClicked(class_364 l, double mouseX, double mouseY, int button) {
        //? if >=1.21.9 {
        /*return l.mouseClicked(new MouseButtonEvent(mouseX, mouseY, new MouseButtonInfo(button, 0)), false);
        *///?} else {
        return l.method_25402(mouseX, mouseY, button);
        //?}
    }

    public static boolean keyPressed(class_364 l, int keyCode, int scanCode, int modifiers) {
        //? if >=1.21.9 {
        /*return l.keyPressed(new KeyEvent(keyCode, scanCode, modifiers));
        *///?} else {
        return l.method_25404(keyCode, scanCode, modifiers);
        //?}
    }

    public static boolean charTyped(class_364 l, char codePoint, int modifiers) {
        //? if >=1.21.9 {
        /*return l.charTyped(new CharacterEvent(codePoint, modifiers));
        *///?} else {
        return l.method_25400(codePoint, modifiers);
        //?}
    }

    public static boolean mouseDragged(class_364 l, double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        //? if >=1.21.9 {
        /*return l.mouseDragged(new MouseButtonEvent(mouseX, mouseY, new MouseButtonInfo(button, 0)), deltaX, deltaY);
        *///?} else {
        return l.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        //?}
    }

    private WidgetUtils() {
    }
}
