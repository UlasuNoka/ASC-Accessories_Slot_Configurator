package dev.isxander.yacl3.gui.utils;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1011;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4668;
import net.minecraft.class_5250;
import net.minecraft.class_757;
import net.minecraft.class_7833;
//? if >=1.21.6 {
/*import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.renderer.RenderPipelines;
*///?} elif >=1.21.2 {
/*import net.minecraft.client.renderer.RenderStateShard;
*///?} else {
import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.platform.GlStateManager;
import dev.isxander.yacl3.debug.DebugProperties;

public class GuiUtils {
    //? if <1.21.2 {
    private static Function<class_2960, class_1921> GUI_TEXTURED = class_156.method_34866(
            location -> class_1921.method_24048(
                    "yacl:gui_textured",
                    class_290.field_1575,
                    class_293.class_5596.field_27382,
                    786432,
                    class_1921.class_4688.method_23598()
                            .method_34577(new class_4668.class_4683(location, false, false))
                            .method_34578(new class_4668.class_5942(class_757::method_34543))
                            .method_23615(class_4668.field_21370)
                            .method_23604(class_4668.field_21348)
                            .method_23617(false)
            )
    );
    //?}

    //? if >=1.21.2 && <1.21.6 {
    /*public static Function<ResourceLocation, RenderType> GUI_TEXTURED_FILTERED = Util.memoize(
            location -> RenderType.create(
                    "yacl:gui_textured_filtered",
                    //? if <1.21.5 {
                    /^DefaultVertexFormat.POSITION_TEX_COLOR,
                    VertexFormat.Mode.QUADS,
                    ^///?}
                    786432,
                    //? if >=1.21.5 {
                    net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED,
                    //?}
                    RenderType.CompositeState.builder()
                            .setTextureState(new RenderType.TextureStateShard(location, net.minecraft.util.TriState.TRUE, false))
                            //? if <1.21.5 {
                            /^.setShaderState(RenderStateShard.POSITION_TEXTURE_COLOR_SHADER)
                            .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                            .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
                            ^///?}
                            .createCompositeState(false)
            )
    );
    *///?}

    public static void pushPose(class_332 graphics) {
        //? if >=1.21.6 {
        /*graphics.pose().pushMatrix();
        *///?} else {
        graphics.method_51448().method_22903();
        //?}
    }

    public static void popPose(class_332 graphics) {
        //? if >=1.21.6 {
        /*graphics.pose().popMatrix();
        *///?} else {
        graphics.method_51448().method_22909();
        //?}
    }

    public static void translate2D(class_332 graphics, float x, float y) {
        //? if >=1.21.6 {
        /*graphics.pose().translate(x, y);
        *///?} else {
        graphics.method_51448().method_46416(x, y, 0);
        //?}
    }

    public static void translateZ(class_332 graphics, float z) {
        //? if <1.21.6 {
        graphics.method_51448().method_46416(0, 0, z);
        //?}
    }

    public static void scale2D(class_332 graphics, float x, float y) {
        //? if >=1.21.6 {
        /*graphics.pose().scale(x, y);
        *///?} else {
        graphics.method_51448().method_22905(x, y, 1);
        //?}
    }

    public static void rotate2D(class_332 graphics, float angle) {
        //? if >=1.21.6 {
        /*graphics.pose().rotate(angle * Mth.DEG_TO_RAD);
        *///?} else {
        graphics.method_51448().method_49278(class_7833.field_40718.rotationDegrees(angle), 0, 0, 1);
        //?}
    }

    public static void blitGuiTex(class_332 graphics, class_2960 texture, int x, int y, float u, float v, int textureWidth, int textureHeight, int width, int height) {
        blitGuiTex(graphics, texture, x, y, u, v, textureWidth, textureHeight, width, height, false);
    }

    public static void blitGuiTex(class_332 graphics, class_2960 texture, int x, int y, float u, float v, int textureWidth, int textureHeight, int width, int height, boolean linearFiltering) {
        //? if <1.21.2
        doTextureFiltering();

        graphics.method_25290(
                //? if >=1.21.2
                //guiTextured(linearFiltering),
                texture,
                x, y,
                u, v,
                textureWidth, textureHeight,
                width, height
        );
    }

    public static void blitGuiTexColor(class_332 graphics, class_2960 texture, int x, int y, float u, float v, int textureWidth, int textureHeight, int width, int height, int color) {
        //? if <1.21.2 {
        float a = (color >> 24 & 255) / 255.0F;
        float r = (color >> 16 & 255) / 255.0F;
        float g = (color >> 8 & 255) / 255.0F;
        float b = (color & 255) / 255.0F;
        graphics.method_51422(r, g, b, a);
        //?}
        graphics.method_25290(
                //? if >=1.21.2
                //guiTextured(false),
                texture,
                x, y,
                u, v,
                textureWidth, textureHeight,
                width, height
                //? if >=1.21.2
                //,color
        );
        //? if <1.21.2
        graphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void blitSprite(class_332 graphics, class_2960 sprite, int x, int y, int width, int height) {
        graphics.method_52706(
                //? if >=1.21.2
                //guiTextured(false),
                sprite,
                x, y,
                width, height
        );
    }

    //? if >=1.21.6 {
    /*public static RenderPipeline guiTextured(boolean textureFiltering) {
        // in 1.21.6, texture filtering is done on the texture level on resource reload, ignored
        return RenderPipelines.GUI_TEXTURED;
    }
    *///?} elif >=1.21.2 {
    /*public static Function<ResourceLocation, RenderType> guiTextured(boolean textureFiltering) {
        return textureFiltering ? GUI_TEXTURED_FILTERED : RenderType::guiTextured;
    }
    *///?} else {
    public static Function<class_2960, class_1921> guiTextured(boolean textureFiltering) {
        return GUI_TEXTURED;
    }
    //?}

    public static class_5250 translatableFallback(String key, class_2561 fallback) {
        if (class_2477.method_10517().method_4678(key))
            return class_2561.method_43471(key);
        return fallback.method_27661();
    }

    public static String shortenString(String string, class_327 font, int maxWidth, String suffix) {
        if (string.isEmpty())
            return string;

        boolean firstIter = true;
        while (font.method_1727(string) > maxWidth) {
            string = string.substring(0, Math.max(string.length() - 1 - (firstIter ? 1 : suffix.length() + 1), 0)).trim();
            string += suffix;

            if (string.equals(suffix))
                break;

            firstIter = false;
        }

        return string;
    }


    public static void setPixelARGB(class_1011 nativeImage, int x, int y, int argb) {
        // In 1.21.2+, you set the pixel color in ARGB format, where it internally converts to ABGR.
        // Before this, you need to directly set the pixel color in ABGR format.

        //? if >=1.21.2 {
        /*nativeImage.setPixel(x, y, argb);
        *///?} else {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        int abgr = (a << 24) | (b << 16) | (g << 8) | r;
        nativeImage.method_4305(x, y, abgr); // method name is misleading. It's actually ABGR.
        //?}
    }

    // On new versions this should be done via the render pipeline. Setting global state will not work.
    //? if <1.21.2 {
    public static void doTextureFiltering() {
        if (DebugProperties.IMAGE_FILTERING) {
            GlStateManager._texParameter(GlConst.GL_TEXTURE_2D, GlConst.GL_TEXTURE_MAG_FILTER, GlConst.GL_LINEAR);
            GlStateManager._texParameter(GlConst.GL_TEXTURE_2D, GlConst.GL_TEXTURE_MIN_FILTER, GlConst.GL_LINEAR);
        }
    }
    //?}

    public static int extractAlpha(int argb) {
        //? if >=1.21.2 {
        /*return ARGB.alpha(argb);
        *///?} else {
        return (argb >> 24) & 0xFF;
        //?}
    }

    public static int putAlpha(int rgb, int alpha) {
        //? if >=1.21.2 {
        /*return ARGB.color(alpha, rgb);
        *///?} else {
        return (rgb & 0x00FFFFFF) | (alpha << 24);
        //?}
    }
}
