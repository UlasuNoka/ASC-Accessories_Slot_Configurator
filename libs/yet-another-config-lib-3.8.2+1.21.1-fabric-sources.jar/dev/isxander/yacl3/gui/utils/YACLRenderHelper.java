package dev.isxander.yacl3.gui.utils;

import dev.isxander.yacl3.platform.YACLPlatform;
import net.minecraft.class_332;

public class YACLRenderHelper {
    private static final net.minecraft.class_8666 SPRITES = new net.minecraft.class_8666(
            YACLPlatform.mcRl("widget/button"), // normal
            YACLPlatform.mcRl("widget/button_disabled"), // disabled & !focused
            YACLPlatform.mcRl("widget/button_highlighted"), // !disabled & focused
            YACLPlatform.mcRl("widget/slider_highlighted") // disabled & focused
    );

    public static void renderButtonTexture(class_332 graphics, int x, int y, int width, int height, boolean enabled, boolean focused) {
        GuiUtils.blitSprite(graphics, SPRITES.method_52729(enabled, focused), x, y, width, height);
    }
}
