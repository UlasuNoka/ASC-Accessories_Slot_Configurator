package dev.isxander.yacl3.gui.utils;


import dev.isxander.yacl3.platform.YACLPlatform;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_151;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ItemRegistryHelper {

    /**
     * Checks whether the given string is an identifier referring to a known item
     *
     * @param identifier Item identifier, either of the format "namespace:path" or "path". If no namespace is included,
     *                   the default vanilla namespace "minecraft" is used.
     * @return true if the identifier refers to a registered item, false otherwise
     */
    public static boolean isRegisteredItem(String identifier) {
        try {
            class_2960 itemResourceLocation = YACLPlatform.parseRl(identifier.toLowerCase());
            return class_7923.field_41178.method_10250(itemResourceLocation);
        } catch (class_151 e) {
            return false;
        }
    }

    /**
     * Looks up the item of the given identifier string.
     *
     * @param identifier  Item identifier, either of the format "namespace:path" or "path". If no namespace is included,
     *                    the default vanilla namespace "minecraft" is used.
     * @param defaultItem Fallback item that gets returned if the identifier does not name a registered item.
     * @return The item identified by the given string, or the fallback if the identifier is not known.
     */
    public static class_1792 getItemFromName(String identifier, class_1792 defaultItem) {
        try {
            class_2960 itemResourceLocation = YACLPlatform.parseRl(identifier.toLowerCase());
            if (class_7923.field_41178.method_10250(itemResourceLocation)) {
                return MiscUtil.getFromRegistry(class_7923.field_41178, itemResourceLocation);
            }
        } catch (class_151 ignored) {
        }
        return defaultItem;
    }

    /**
     * Looks up the item of the given identifier string.
     *
     * @param identifier Item identifier, either of the format "namespace:path" or "path". If no namespace is included,
     *                   the default vanilla namespace "minecraft" is used.
     * @return The item identified by the given string, or `Items.AIR` if the identifier is not known.
     */
    public static class_1792 getItemFromName(String identifier) {
        return getItemFromName(identifier, class_1802.field_8162);
    }

    /**
     * Returns a list of item identifiers matching the given string. The value matches an identifier if:
     * <li>No namespace is provided in the value and the value is a substring of the path segment of any identifier,
     * regardless of namespace.</li>
     * <li>A namespace is provided, equals the identifier's namespace, and the value is the begin of the identifier's
     * path segment.</li>
     *
     * @param value (partial) identifier, either of the format "namespace:path" or "path".
     * @return list of matching item identifiers; empty if the given string does not correspond to any known identifiers
     */
    public static Stream<class_2960> getMatchingItemResourceLocations(String value) {
        int sep = value.indexOf(class_2960.field_33380);
        Predicate<class_2960> filterPredicate;
        if (sep == -1) {
            filterPredicate = identifier ->
                    identifier.method_12832().contains(value)
                            || MiscUtil.getFromRegistry(class_7923.field_41178, identifier)
                                    /*? if >=1.21.2 {*/ /*.getName() *//*?} else {*/ .method_7848() /*?}*/
                                    .getString().toLowerCase().contains(value.toLowerCase());
        } else {
            String namespace = value.substring(0, sep);
            String path = value.substring(sep + 1);
            filterPredicate = identifier -> identifier.method_12836().equals(namespace) && identifier.method_12832().startsWith(path);
        }
        return class_7923.field_41178.method_10235().stream()
                .filter(filterPredicate)
                /*
                 Sort items as follows based on the given "value" string's path:
                 - if both items' paths begin with the entered string, sort the identifiers (including namespace)
                 - otherwise, if either of the items' path begins with the entered string, sort it to the left
                 - else neither path matches: sort by identifiers again

                 This allows the user to enter "diamond_ore" and match "minecraft:diamond_ore" before
                 "minecraft:deepslate_diamond_ore", even though the second is lexicographically smaller
                 */
                .sorted((id1, id2) -> {
                    String path = (sep == -1 ? value : value.substring(sep + 1)).toLowerCase();
                    boolean id1StartsWith = id1.method_12832().toLowerCase().startsWith(path);
                    boolean id2StartsWith = id2.method_12832().toLowerCase().startsWith(path);
                    if (id1StartsWith) {
                        if (id2StartsWith) {
                            return id1.method_12833(id2);
                        }
                        return -1;
                    }
                    if (id2StartsWith) {
                        return 1;
                    }
                    return id1.method_12833(id2);
                });
    }
}
