package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.api.OptionDescription;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public record DescriptionWithName(class_2561 name, OptionDescription description) {
    public static DescriptionWithName of(class_2561 name, OptionDescription description) {
        return new DescriptionWithName(name.method_27661().method_27692(class_124.field_1067), description);
    }
}
