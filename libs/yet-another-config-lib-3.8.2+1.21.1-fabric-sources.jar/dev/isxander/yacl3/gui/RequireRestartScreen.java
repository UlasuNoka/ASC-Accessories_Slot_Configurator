package dev.isxander.yacl3.gui;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_410;
import net.minecraft.class_437;

public class RequireRestartScreen extends class_410 {
    public RequireRestartScreen(class_437 parent) {
        super(option -> {
            if (option) class_310.method_1551().method_1592();
            else class_310.method_1551().method_1507(parent);
        },
                class_2561.method_43471("yacl.restart.title").method_27695(class_124.field_1061, class_124.field_1067),
                class_2561.method_43471("yacl.restart.message"),
                class_2561.method_43471("yacl.restart.yes"),
                class_2561.method_43471("yacl.restart.no")
        );
    }
}
