package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import net.minecraft.class_5489;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;

/**
 * Simply renders some text as a label.
 */
public class LabelController implements Controller<class_2561> {
    private final Option<class_2561> option;
    /**
     * Constructs a label controller
     *
     * @param option bound option
     */
    public LabelController(Option<class_2561> option) {
        this.option = option;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Option<class_2561> option() {
        return option;
    }

    @Override
    public class_2561 formatValue() {
        return option().pendingValue();
    }

    @Override
    public AbstractWidget provideWidget(YACLScreen screen, Dimension<Integer> widgetDimension) {
        return new LabelControllerElement(screen, widgetDimension);
    }

    public class LabelControllerElement extends AbstractWidget {
        private List<class_5481> wrappedText;
        protected class_5489 wrappedTooltip;
        protected boolean focused;

        protected final YACLScreen screen;

        public LabelControllerElement(YACLScreen screen, Dimension<Integer> dim) {
            super(dim);
            this.screen = screen;
            option().addListener((opt, pending) -> updateTooltip());
            updateTooltip();
            updateText();
        }

        @Override
        public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
            updateText();

            int y = getDimension().y();
            for (class_5481 text : wrappedText) {
                graphics.method_51430(textRenderer, text, getDimension().x() + getXPadding(), y + getYPadding(), option().available() ? -1 : 0xFFA0A0A0, true);
                y += textRenderer.field_2000;
            }

            if (method_25370()) {
                graphics.method_25294(getDimension().x() - 1, getDimension().y() - 1, getDimension().xLimit() + 1, getDimension().y(), -1);
                graphics.method_25294(getDimension().x() - 1, getDimension().y() - 1, getDimension().x(), getDimension().yLimit() + 1, -1);
                graphics.method_25294(getDimension().x() - 1, getDimension().yLimit(), getDimension().xLimit() + 1, getDimension().yLimit() + 1, -1);
                graphics.method_25294(getDimension().xLimit(), getDimension().y() - 1, getDimension().xLimit() + 1, getDimension().yLimit() + 1, -1);
            }

            GuiUtils.pushPose(graphics);
            GuiUtils.translateZ(graphics, 100);
            if (method_25405(mouseX, mouseY)) {
                class_2583 style = getStyle(mouseX, mouseY);
                if (style != null && style.method_10969() != null) {
                    class_2568 hoverEvent = style.method_10969();

                    //? if >=1.21.6 {
                    /*graphics.renderComponentHoverEffect(textRenderer, style, mouseX, mouseY);
                    *///?} elif >=1.21.5 {
                    /*if (hoverEvent instanceof HoverEvent.ShowItem showItem) {
                        ItemStack stack = showItem.item();
                        renderItemStackTooltip(graphics, mouseX, mouseY, stack);
                    } else if (hoverEvent instanceof HoverEvent.ShowEntity showEntity) {
                        HoverEvent.EntityTooltipInfo entity = showEntity.entity();
                        renderEntityTooltip(graphics, mouseX, mouseY, entity);
                    } else if (hoverEvent instanceof HoverEvent.ShowText showText) {
                        Component text = showText.value();
                        renderTextTooltip(graphics, mouseX, mouseY, text);
                    }
                    *///?} else {
                    @Nullable class_2568.class_5249 itemStackContent = hoverEvent.method_10891(class_2568.class_5247.field_24343);
                    @Nullable class_2568.class_5248 entityContent = hoverEvent.method_10891(class_2568.class_5247.field_24344);
                    @Nullable class_2561 text = hoverEvent.method_10891(class_2568.class_5247.field_24342);

                    if (itemStackContent != null) {
                        class_1799 stack = itemStackContent.method_27683();
                        renderItemStackTooltip(graphics, mouseX, mouseY, stack);
                    } else if (entityContent != null) {
                        renderEntityTooltip(graphics, mouseX, mouseY, entityContent);
                    } else if (text != null) {
                        renderTextTooltip(graphics, mouseX, mouseY, text);
                    }
                    //?}
                }

                //? if >=1.21.9 {
                /*if (style != null && style.getClickEvent() != null) {
                    graphics.requestCursor(com.mojang.blaze3d.platform.cursor.CursorTypes.POINTING_HAND);
                }
                *///?}
            }
            GuiUtils.popPose(graphics);
        }

        //? if <=1.21.5 {
        private void renderItemStackTooltip(class_332 graphics, int mouseX, int mouseY, class_1799 itemStack) {
            graphics.method_51437(textRenderer, class_437.method_25408(client, itemStack), itemStack.method_32347(), mouseX, mouseY);
        }
        private void renderEntityTooltip(class_332 graphics, int mouseX, int mouseY, class_2568.class_5248 entity) {
            if (this.client.field_1690.field_1827) {
                graphics.method_51434(textRenderer, entity.method_27682(), mouseX, mouseY);
            }
        }
        private void renderTextTooltip(class_332 graphics, int mouseX, int mouseY, class_2561 text) {
            class_5489 multilineText = class_5489.method_30890(textRenderer, text, getDimension().width());
            YACLScreen.renderMultilineTooltip(graphics, textRenderer, multilineText, getDimension().centerX(), getDimension().y(), getDimension().yLimit(), screen.field_22789, screen.field_22790);
        }
        //?}

        @Override
        public boolean onMouseClicked(double mouseX, double mouseY, int button) {
            if (!method_25405(mouseX, mouseY))
                return false;

            class_2583 style = getStyle((int) mouseX, (int) mouseY);

            if(style == null)
                return false;

            // TODO: reimplement
            //? if >=1.21.11 {
            /*return false;
            *///?} else {
            return screen.method_25430(style);
            //?}
        }

        @Nullable
        protected class_2583 getStyle(int mouseX, int mouseY) {
            if (!getDimension().isPointInside(mouseX, mouseY))
                return null;

            int x = mouseX - getDimension().x() - getXPadding();
            int y = mouseY - getDimension().y() - getYPadding();
            int line = y / textRenderer.field_2000;

            if (x < 0 || x > getDimension().xLimit()) return null;
            if (y < 0 || y > getDimension().yLimit()) return null;
            if (line < 0 || line >= wrappedText.size()) return null;

            // TODO reimplement
            //? if >=1.21.11 {
            /*return null;
            *///?} else {
            return textRenderer.method_27527().method_30876(wrappedText.get(line), x);
            //?}
        }

        private int getXPadding() {
            return 4;
        }

        private int getYPadding() {
            return 3;
        }

        private void updateText() {
            wrappedText = textRenderer.method_1728(formatValue(), getDimension().width() - getXPadding() * 2);
            setDimension(getDimension().withHeight(wrappedText.size() * textRenderer.field_2000 + getYPadding() * 2));
        }

        private void updateTooltip() {
            this.wrappedTooltip = class_5489.method_30890(textRenderer, option().tooltip(), screen.field_22789 / 3 * 2 - 10);
        }

        @Override
        public boolean matchesSearch(String query) {
            return formatValue().getString().toLowerCase().contains(query.toLowerCase());
        }

        @Nullable
        @Override
        public class_8016 method_48205(class_8023 focusNavigationEvent) {
            if (!option().available())
                return null;
            return !this.method_25370() ? class_8016.method_48193(this) : null;
        }

        @Override
        public boolean method_25370() {
            return focused;
        }

        @Override
        public void method_25365(boolean focused) {
            this.focused = focused;
        }

        @Override
        public void method_37020(class_6382 builder) {
            builder.method_37034(class_6381.field_33788, formatValue());
        }

        @Override
        public class_6380 method_37018() {
            return class_6380.field_33786;
        }
    }
}
