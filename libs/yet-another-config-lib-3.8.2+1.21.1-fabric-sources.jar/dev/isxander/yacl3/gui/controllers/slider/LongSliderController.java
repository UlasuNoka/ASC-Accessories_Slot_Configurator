package dev.isxander.yacl3.gui.controllers.slider;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ValueFormatter;
import org.apache.commons.lang3.Validate;

import java.util.function.Function;
import net.minecraft.class_2561;

/**
 * {@link ISliderController} for longs.
 */
public class LongSliderController implements ISliderController<Long> {
    public static final Function<Long, class_2561> DEFAULT_FORMATTER = value -> class_2561.method_43470(String.format("%,d", value).replaceAll("[\u00a0\u202F]", " "));

    private final Option<Long> option;

    private final long min, max, interval;

    private final ValueFormatter<Long> valueFormatter;

    /**
     * Constructs a {@link ISliderController} for longs
     * using the default value formatter {@link LongSliderController#DEFAULT_FORMATTER}.
     *
     * @param option bound option
     * @param min minimum slider value
     * @param max maximum slider value
     * @param interval step size (or increments) for the slider
     */
    public LongSliderController(Option<Long> option, long min, long max, long interval) {
        this(option, min, max, interval, DEFAULT_FORMATTER);
    }

    /**
     * Constructs a {@link ISliderController} for longs.
     *
     * @param option bound option
     * @param min minimum slider value
     * @param max maximum slider value
     * @param interval step size (or increments) for the slider
     * @param valueFormatter format the value into any {@link class_2561}
     */
    public LongSliderController(Option<Long> option, long min, long max, long interval, Function<Long, class_2561> valueFormatter) {
        Validate.isTrue(max > min, "`max` cannot be smaller than `min`");
        Validate.isTrue(interval > 0, "`interval` must be more than 0");
        Validate.notNull(valueFormatter, "`valueFormatter` must not be null");

        this.option = option;
        this.min = min;
        this.max = max;
        this.interval = interval;
        this.valueFormatter = valueFormatter::apply;
    }

    public static LongSliderController createInternal(Option<Long> option, long min, long max, long interval, ValueFormatter<Long> formatter) {
        return new LongSliderController(option, min, max, interval, formatter::format);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Option<Long> option() {
        return option;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public class_2561 formatValue() {
        return valueFormatter.format(option().pendingValue());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double min() {
        return min;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double max() {
        return max;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double interval() {
        return interval;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setPendingValue(double value) {
        option().requestSet((long) value);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public double pendingValue() {
        return option().pendingValue();
    }

}
