package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.ItemRegistryHelper;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Simple controller that simply runs the button action on press
 * and renders a {@link} Text on the right.
 */
public class ItemController extends AbstractDropdownController<class_1792> {

	/**
	 * Constructs an item controller
	 *
	 * @param option bound option
	 */
	public ItemController(Option<class_1792> option) {
		super(option);
	}

	@Override
	public String getString() {
		return class_7923.field_41178.method_10221(option.pendingValue()).toString();
	}

	@Override
	public void setFromString(String value) {
		option.requestSet(ItemRegistryHelper.getItemFromName(value, option.pendingValue()));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public class_2561 formatValue() {
		return class_2561.method_43470(getString());
	}


	@Override
	public boolean isValueValid(String value) {
		return ItemRegistryHelper.isRegisteredItem(value);
	}

	@Override
	protected String getValidValue(String value, int offset) {
		return ItemRegistryHelper.getMatchingItemResourceLocations(value)
				.skip(offset)
				.findFirst()
				.map(class_2960::toString)
				.orElseGet(this::getString);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AbstractWidget provideWidget(YACLScreen screen, Dimension<Integer> widgetDimension) {
		return new ItemControllerElement(this, screen, widgetDimension);
	}
}
