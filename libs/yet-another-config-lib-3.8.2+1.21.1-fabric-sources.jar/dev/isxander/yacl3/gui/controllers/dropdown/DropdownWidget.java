package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.api.utils.MutableDimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.controllers.ControllerPopupWidget;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class DropdownWidget<T> extends ControllerPopupWidget<AbstractDropdownController<T>> {
	public static final int MAX_SHOWN_NUMBER_OF_ITEMS = 7;
	public static final int DROPDOWN_PADDING = 2;

	private final AbstractDropdownControllerElement<T, ?> dropdownElement;

	protected Dimension<Integer> dropdownDim;

	// Scroll offset in the list of possible values
	protected int firstVisibleIndex = 0;
	// Stores the current selection position. The item at this position in the dropdown list will be chosen as the
	// accepted value when the element is closed.
	protected int selectedIndex = 0;

	public DropdownWidget(AbstractDropdownController<T> control, YACLScreen screen, Dimension<Integer> dim, AbstractDropdownControllerElement<T, ?> dropdownElement) {
		super(control, screen, dim, dropdownElement);
		this.dropdownElement = dropdownElement;

		setDimension(dim);
	}

	@Override
	public void setDimension(Dimension<Integer> dim) {
		super.setDimension(dim);

		// Set up the dropdown above the controller ...
		int dropdownHeight = dim.height() * numberOfVisibleItems();
		int dropdownY = dim.y() - dropdownHeight - DROPDOWN_PADDING;

		// ... unless it doesn't fit, then place it below
		if (dropdownY < screen.tabArea.method_49618()) {
			dropdownY = dim.yLimit() + DROPDOWN_PADDING;
		}

		dropdownDim = Dimension.ofInt(dim.x(), dropdownY, dim.width(), dropdownHeight);
	}

	public int entryHeight() {
		return dropdownElement.getDimension().height();
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (dropdownLength() == 0) return;

		GuiUtils.pushPose(graphics);
        GuiUtils.translateZ(graphics, 200);

		// Background
		//graphics.setColor(0.25f, 0.25f, 0.25f, 1.0f);
		GuiUtils.blitGuiTexColor(
                graphics,
				class_437.field_49511,
				dropdownDim.x(), dropdownDim.y(),
				0.0f, 0.0f,
				dropdownDim.width(), dropdownDim.height(),
				32, 32,
                0xFF3F3F3F
		);
		//graphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
		graphics./*? if >=1.21.9 && <1.21.11 {*//*submitOutline*//*?} else {*/method_49601/*?}*/(dropdownDim.x(), dropdownDim.y(), dropdownDim.width(), dropdownDim.height(), -1);

		// Highlight the currently selected element
		//graphics.setColor(0.0f, 0.0f, 0.0f, 0.5f);
		int y = dropdownDim.y() + 2 + entryHeight() * selectedVisibleIndex();
		graphics.method_25294(dropdownDim.x(), y, dropdownDim.xLimit(), y + entryHeight(), 0x7F000000);
		//graphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
		graphics./*? if >=1.21.9 && <1.21.11 {*//*submitOutline*//*?} else {*/method_49601/*?}*/(dropdownDim.x(), y, dropdownDim.width(), entryHeight(), -1);

		// Render all visible elements
		MutableDimension<Integer> entryDimension = Dimension.ofInt(
				dropdownDim.x() - dropdownElement.getDecorationPadding(),
				dropdownDim.y() + 2,
				dropdownDim.width(),
				entryHeight()
		);
		for (int i = firstVisibleIndex; i < lastVisibleIndex(); ++i) {
			dropdownElement.renderDropdownEntry(graphics, entryDimension, i);
			entryDimension.move(0, entryHeight());
		}

        GuiUtils.popPose(graphics);
	}

	@Override
	public boolean onMouseClicked(double mouseX, double mouseY, int button) {
		if (method_25405(mouseX, mouseY)) {
			// Closes and cleans up the dropdown
			dropdownElement.unfocus();
			return true;
		} else if (dropdownElement.method_25405(mouseX, mouseY)) {
			return dropdownElement.onMouseClicked(mouseX, mouseY, button);
		} else {
			close();
			return false;
		}
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
		if (method_25405(mouseX, mouseY)) {
			if (vertical < 0) {
				scrollDown();
			} else {
				scrollUp();
			}
			return true;
		}
		return super.method_25401(mouseX, mouseY, horizontal, vertical);
	}

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (method_25405(mouseX, mouseY)) {
            int index = (int) ((mouseY - dropdownDim.y()) / entryHeight());
            selectVisibleItem(index);
        }
    }

    @Override
	public boolean method_25405(double mouseX, double mouseY) {
		return dropdownDim.isPointInside((int) mouseX, (int) mouseY);
	}

	@Override
	public boolean onCharTyped(char chr, String cpStr, int modifiers) {
		// Done to allow for typing whilst the color picker is visible
		return dropdownElement.onCharTyped(chr, cpStr, modifiers);
	}

	public int dropdownLength() {
		return dropdownElement.matchingValues.size();
	}

	public int numberOfVisibleItems() {
		return Math.min(MAX_SHOWN_NUMBER_OF_ITEMS, dropdownLength());
	}

	public int lastVisibleIndex() {
		return Math.min(firstVisibleIndex + MAX_SHOWN_NUMBER_OF_ITEMS, dropdownLength());
	}

	public int selectedIndex() {
		return selectedIndex;
	}
	public void resetSelectedIndex() {
		selectedIndex = 0;
	}
	/**
	 * @return the offset of the selected element relative to the first visible entry
	 */
	public int selectedVisibleIndex() {
		return selectedIndex - firstVisibleIndex;
	}

	public void selectVisibleItem(int visibleIndex) {
		selectedIndex = Math.min(firstVisibleIndex + visibleIndex, dropdownLength() - 1);
	}

	public void selectNextEntry() {
		if (selectedIndex == dropdownLength() - 1) {
			selectedIndex = 0;
		} else {
			selectedIndex++;
		}
		if (selectedIndex - firstVisibleIndex >= MAX_SHOWN_NUMBER_OF_ITEMS / 2) {
			centerOnSelectedItem();
		}
	}

	public void selectPreviousEntry() {
		if (selectedIndex == 0) {
			selectedIndex = dropdownLength() - 1;
		} else {
			selectedIndex--;
		}
		if (selectedIndex - firstVisibleIndex <= MAX_SHOWN_NUMBER_OF_ITEMS / 2) {
			centerOnSelectedItem();
		}
	}

	private void centerOnSelectedItem() {
		// Limit the visible options to allow scrolling through the suggestion list
		int begin = Math.max(0, selectedIndex - MAX_SHOWN_NUMBER_OF_ITEMS / 2);
		int end = begin + MAX_SHOWN_NUMBER_OF_ITEMS;
		if (end >= dropdownLength()) {
			end = dropdownLength();
			begin = Math.max(0, end - MAX_SHOWN_NUMBER_OF_ITEMS);
		}
		firstVisibleIndex = begin;
	}

	public void scrollDown() {
		if (firstVisibleIndex + 1 + MAX_SHOWN_NUMBER_OF_ITEMS <= dropdownLength()) {
			firstVisibleIndex++;
		}
		if (selectedIndex < firstVisibleIndex) selectedIndex = firstVisibleIndex;
	}
	public void scrollUp() {
		if (firstVisibleIndex > 0) {
			firstVisibleIndex--;
		}
		if (selectedIndex > firstVisibleIndex + MAX_SHOWN_NUMBER_OF_ITEMS - 1) {
			selectedIndex = firstVisibleIndex + MAX_SHOWN_NUMBER_OF_ITEMS - 1;
		}
	}


	@Override
	public void close() {
		dropdownElement.removeDropdownWidget();
	}

	@Override
	public class_2561 popupTitle() {
		return class_2561.method_43471("yacl.control.dropdown.dropdown_widget_title");
	}

}
