package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.ItemRegistryHelper;
import dev.isxander.yacl3.gui.utils.MiscUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7923;

public class ItemControllerElement extends AbstractDropdownControllerElement<class_1792, class_2960> {
	private final ItemController itemController;
	protected class_1792 currentItem = null;
	protected Map<class_2960, class_1792> matchingItems = new HashMap<>();


	public ItemControllerElement(ItemController control, YACLScreen screen, Dimension<Integer> dim) {
		super(control, screen, dim);
		this.itemController = control;
	}

	@Override
	protected void drawValueText(class_332 graphics, int mouseX, int mouseY, float delta) {
		var oldDimension = getDimension();
		setDimension(getDimension().withWidth(getDimension().width() - getDecorationPadding()));
		super.drawValueText(graphics, mouseX, mouseY, delta);
		setDimension(oldDimension);
		if (currentItem != null) {
			graphics.method_51445(new class_1799(currentItem), getDimension().xLimit() - getXPadding() - getDecorationPadding() + 2, getDimension().y() + 2);
		}
	}

	@Override
	public List<class_2960> computeMatchingValues() {
		List<class_2960> identifiers = ItemRegistryHelper.getMatchingItemResourceLocations(inputField).toList();
		currentItem = ItemRegistryHelper.getItemFromName(inputField, null);
		for (class_2960 identifier : identifiers) {
			matchingItems.put(identifier, MiscUtil.getFromRegistry(class_7923.field_41178, identifier));
		}
		return identifiers;
	}

	@Override
	protected void renderDropdownEntry(class_332 graphics, Dimension<Integer> entryDimension, class_2960 identifier) {
		super.renderDropdownEntry(graphics, entryDimension, identifier);
		graphics.method_51445(
				new class_1799(matchingItems.get(identifier)),
				entryDimension.xLimit() - 2,
				entryDimension.y() + 1
		);
	}

	@Override
	public String getString(class_2960 identifier) {
		return identifier.toString();
	}

	@Override
	protected int getDecorationPadding() {
		return 16;
	}

	@Override
	protected int getDropdownEntryPadding() {
		return 4;
	}

	@Override
	protected int getControlWidth() {
		return super.getControlWidth() + getDecorationPadding();
	}

	@Override
	protected class_2561 getValueText() {
		if (inputField.isEmpty() || itemController == null)
			return super.getValueText();

		if (inputFieldFocused)
			return class_2561.method_43470(inputField);

		return itemController.option().pendingValue()
                //? if >=1.21.2 {
                /*.getName();
                *///?} else {
                .method_7848();
                //?}
	}
}
