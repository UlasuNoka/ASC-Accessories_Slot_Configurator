package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.controllers.string.StringControllerElement;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import dev.isxander.yacl3.gui.utils.KeyUtils;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;

public abstract class AbstractDropdownControllerElement<T, U> extends StringControllerElement {

	private final AbstractDropdownController<T> dropdownController;
	protected DropdownWidget<T> dropdownWidget;

	protected boolean dropdownVisible = false;

	// Stores a cached list of matching values
	protected List<U> matchingValues = null;

	public AbstractDropdownControllerElement(AbstractDropdownController<T> control, YACLScreen screen, Dimension<Integer> dim) {
		super(control, screen, dim, false);
		this.dropdownController = control;
		this.dropdownController.option.addListener((opt, val) -> this.matchingValues = this.computeMatchingValues());
	}

	public void ensureValidValue() {
		if (!dropdownController.isValueValid(inputField)) {
			if (dropdownWidget == null) {
				inputField = dropdownController.getValidValue(inputField);
			} else {
				inputField = dropdownController.getValidValue(inputField, dropdownWidget.selectedIndex());
				dropdownWidget.resetSelectedIndex();
			}
			caretPos = getDefaultCaretPos();
			this.matchingValues = this.computeMatchingValues();
		}
	}

	@Override
	public boolean onMouseClicked(double mouseX, double mouseY, int button) {
		if (super.onMouseClicked(mouseX, mouseY, button)) {
			if (!dropdownVisible) {
				createDropdownWidget();
				doSelectAll();
			}
			return true;
		}
		return false;
	}

	@Override
	public void method_25365(boolean focused) {
		if (focused) {
			doSelectAll();
			super.method_25365(true);
		} else unfocus();
	}

	@Override
	public void unfocus() {
		if (dropdownVisible) {
			removeDropdownWidget();
		}
		super.unfocus();
	}

	@Override
	public boolean onKeyPressed(int keyCode, int scanCode, int modifiers) {
		if (!inputFieldFocused)
			return false;
		if (dropdownVisible) {
			switch (keyCode) {
				case class_3675.field_31982 -> {
					dropdownWidget.selectNextEntry();
					return true;
				}
				case class_3675.field_31932 -> {
					dropdownWidget.selectPreviousEntry();
					return true;
				}
				case class_3675.field_31948 -> {
					if (KeyUtils.hasShiftDown(modifiers)) {
						dropdownWidget.selectPreviousEntry();
					} else {
						dropdownWidget.selectNextEntry();
					}
					return true;
				}
			}
		} else {
			if (keyCode == class_3675.field_31957 || keyCode == class_3675.field_31980) {
				createDropdownWidget();
				return true;
			}
		}
		return super.onKeyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean onCharTyped(char chr, String cpStr, int modifiers) {
		if (!inputFieldFocused) {
			return false;
		}
		if (!dropdownVisible) {
			createDropdownWidget();
		}
		return super.onCharTyped(chr, cpStr, modifiers);
	}

	@Override
	protected int getValueColor() {
		if (inputFieldFocused) {
			if (!dropdownController.isValueValid(inputField)) {
				return 0xFFF06080;
			}
		}
		return super.getValueColor();
	}

	@Override
	public boolean modifyInput(Consumer<StringBuilder> builder) {
		boolean success = super.modifyInput(builder);
		if (success) {
			this.matchingValues = this.computeMatchingValues();
		}
		return success;
	}

	public abstract List<U> computeMatchingValues();

	public boolean matchingValue(String value) {
		return value.toLowerCase().contains(inputField.toLowerCase());
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		if (matchingValues == null) matchingValues = computeMatchingValues();

		super.method_25394(graphics, mouseX, mouseY, delta);
	}

	void renderDropdownEntry(class_332 graphics, Dimension<Integer> entryDimension, int index) {
		renderDropdownEntry(graphics, entryDimension, matchingValues.get(index));
	}
	protected void renderDropdownEntry(class_332 graphics, Dimension<Integer> entryDimension, U value) {
		String entry = getString(value);
		class_2561 text;
		if (entry.isBlank()) {
			text = class_2561.method_43471("yacl.control.text.blank").method_27692(class_124.field_1080);
		} else {
			text = shortenString(entry);
		}
		graphics.method_51439(
				textRenderer,
				text,
				entryDimension.xLimit() - textRenderer.method_27525(text) - getDropdownEntryPadding(),
				getTextY(entryDimension),
				-1,
				true
		);
	}

	protected int getTextY(Dimension<Integer> dim) {
		return (int)(dim.y() + dim.height() / 2f - textRenderer.field_2000 / 2f);
	}

	@Override
	public void setDimension(Dimension<Integer> dim) {
		super.setDimension(dim);

		if (dropdownWidget != null) {
			dropdownWidget.setDimension(dropdownWidget.getDimension().withY(this.getDimension().y()));
			// checks if the popup is being partially rendered offscreen
			if (this.getDimension().y() < screen.tabArea.method_49618() || this.getDimension().yLimit() > screen.tabArea.method_49619()) {
				removeDropdownWidget();
			}
		}
	}

	public abstract String getString(U object);

	public class_2561 shortenString(String value) {
		return class_2561.method_43470(GuiUtils.shortenString(value, textRenderer, getDimension().width() - 20, "..."));
	}

	protected int getDecorationPadding() {
		return super.getXPadding();
	}

	protected int getDropdownEntryPadding() {
		return 0;
	}

	public void createDropdownWidget() {
		dropdownVisible = true;
		dropdownWidget = new DropdownWidget<>(dropdownController, screen, getDimension(), this);
		screen.addPopupControllerWidget(dropdownWidget);
	}

	public DropdownWidget<T> dropdownWidget() {
		return dropdownWidget;
	}

	public boolean isDropdownVisible() {
		return dropdownVisible;
	}

	public void removeDropdownWidget() {
		ensureValidValue();
		screen.clearPopupControllerWidget();
		this.dropdownVisible = false;
		this.dropdownWidget = null;
	}
}
