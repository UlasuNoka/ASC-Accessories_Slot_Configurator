package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5489;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8023;
import org.jetbrains.annotations.Nullable;

public abstract class ControllerWidget<T extends Controller<?>> extends AbstractWidget {
    protected final T control;
    protected class_5489 wrappedTooltip;
    protected final YACLScreen screen;

    protected boolean focused = false;
    protected boolean hovered = false;

    protected final class_2561 modifiedOptionName;
    protected final String optionNameString;

    public ControllerWidget(T control, YACLScreen screen, Dimension<Integer> dim) {
        super(dim);
        this.control = control;
        this.screen = screen;
        control.option().addListener((opt, pending) -> updateTooltip());
        updateTooltip();
        this.modifiedOptionName = control.option().name().method_27661().method_27692(class_124.field_1056);
        this.optionNameString = control.option().name().getString().toLowerCase();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        hovered = method_25405(mouseX, mouseY);

        class_2561 name = control.option().changed() ? modifiedOptionName : control.option().name();
        class_2561 shortenedName = class_2561.method_43470(GuiUtils.shortenString(name.getString(), textRenderer, getDimension().width() - getControlWidth() - getXPadding() - 7, "...")).method_10862(name.method_10866());

        drawButtonRect(graphics, getDimension().x(), getDimension().y(), getDimension().xLimit(), getDimension().yLimit(), (hovered && isAvailable()) || focused, isAvailable());
        graphics.method_51439(textRenderer, shortenedName, getDimension().x() + getXPadding(), getTextY(), getValueColor(), true);


        drawValueText(graphics, mouseX, mouseY, delta);
        if (isHovered()) {
            drawHoveredControl(graphics, mouseX, mouseY, delta);
        }
    }

    protected void drawHoveredControl(class_332 graphics, int mouseX, int mouseY, float delta) {

    }

    protected void drawValueText(class_332 graphics, int mouseX, int mouseY, float delta) {
        class_2561 valueText = getValueText();
        graphics.method_51439(textRenderer, valueText, getDimension().xLimit() - textRenderer.method_27525(valueText) - getXPadding(), getTextY(), getValueColor(), true);
    }

    private void updateTooltip() {
        this.wrappedTooltip = class_5489.method_30890(textRenderer, control.option().tooltip(), screen.field_22789 / 3 * 2 - 10);
    }

    protected int getControlWidth() {
        return isHovered() ? getHoveredControlWidth() : getUnhoveredControlWidth();
    }

    public boolean isHovered() {
        return isAvailable() && (hovered || focused);
    }

    protected abstract int getHoveredControlWidth();

    protected int getUnhoveredControlWidth() {
        return textRenderer.method_27525(getValueText());
    }

    protected int getXPadding() {
        return 5;
    }

    protected int getYPadding() {
        return 2;
    }

    protected class_2561 getValueText() {
        return control.formatValue();
    }

    protected boolean isAvailable() {
        return control.option().available();
    }

    protected int getValueColor() {
        return isAvailable() ? -1 : inactiveColor;
    }

    @Override
    public boolean canReset() {
        return true;
    }

    protected int getTextY() {
        return (int)(getDimension().y() + getDimension().height() / 2f - textRenderer.field_2000 / 2f);
    }

    @Nullable
    @Override
    public class_8016 method_48205(class_8023 focusNavigationEvent) {
        return !this.method_25370() ? class_8016.method_48193(this) : null;
    }

    @Override
    public boolean method_25370() {
        return focused;
    }

    @Override
    public void method_25365(boolean focused) {
        this.focused = focused;
    }

    @Override
    public void unfocus() {
        this.focused = false;
    }

    @Override
    public boolean matchesSearch(String query) {
        return optionNameString.contains(query.toLowerCase());
    }

    @Override
    public class_6380 method_37018() {
        return focused ? class_6380.field_33786 : isHovered() ? class_6380.field_33785 : class_6380.field_33784;
    }

    @Override
    public void method_37020(class_6382 builder) {
        builder.method_37034(class_6381.field_33788, control.option().name());
        builder.method_37034(class_6381.field_33790, control.option().tooltip());
    }
}
