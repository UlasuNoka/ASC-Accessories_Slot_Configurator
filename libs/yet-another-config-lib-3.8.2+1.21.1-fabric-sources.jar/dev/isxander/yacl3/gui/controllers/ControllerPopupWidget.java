package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;

public abstract class ControllerPopupWidget<T extends Controller<?>> extends ControllerWidget<Controller<?>> implements class_364 {
    public final ControllerWidget<?> entryWidget;
    public ControllerPopupWidget(T control, YACLScreen screen, Dimension<Integer> dim, ControllerWidget<?> entryWidget) {
        super(control, screen, dim);
        this.entryWidget = entryWidget;
    }

    public ControllerWidget<?> entryWidget() {
        return entryWidget;
    }

    public void renderBackground(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {}

    @Override
    public boolean onKeyPressed(int keycode, int scancode, int modifiers) {
        return entryWidget.onKeyPressed(keycode, scancode, modifiers);
    }

    public void close() {}

    public class_2561 popupTitle() {
        return class_2561.method_43471("yacl.control.text.blank");
    }

    @Override
    protected int getHoveredControlWidth() {
        return 0;
    }

}
