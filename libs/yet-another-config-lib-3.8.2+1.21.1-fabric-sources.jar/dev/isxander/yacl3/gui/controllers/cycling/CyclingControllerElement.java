package dev.isxander.yacl3.gui.controllers.cycling;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.controllers.ControllerWidget;
import dev.isxander.yacl3.gui.utils.KeyUtils;
import net.minecraft.class_332;
import net.minecraft.class_3675;

public class CyclingControllerElement extends ControllerWidget<ICyclingController<?>> {

    public CyclingControllerElement(ICyclingController<?> control, YACLScreen screen, Dimension<Integer> dim) {
        super(control, screen, dim);
    }

    @Override
    protected void drawValueText(class_332 graphics, int mouseX, int mouseY, float delta) {
        super.drawValueText(graphics, mouseX, mouseY, delta);

        if (this.hovered) {
            //? if >=1.21.9
            //graphics.requestCursor(isAvailable() ? com.mojang.blaze3d.platform.cursor.CursorTypes.POINTING_HAND : com.mojang.blaze3d.platform.cursor.CursorTypes.NOT_ALLOWED);
        }
    }

    public void cycleValue(int increment) {
        int targetIdx = control.getPendingValue() + increment;
        if (targetIdx >= control.getCycleLength()) {
            targetIdx -= control.getCycleLength();
        } else if (targetIdx < 0) {
            targetIdx += control.getCycleLength();
        }
        control.setPendingValue(targetIdx);
    }

    @Override
    public boolean onMouseClicked(double mouseX, double mouseY, int button) {
        if (!method_25405(mouseX, mouseY) || (button != 0 && button != 1) || !isAvailable())
            return false;

        playDownSound();
        cycleValue(button == 1 || KeyUtils.hasShiftDown() || KeyUtils.hasControlDown() ? -1 : 1);

        return true;
    }

    @Override
    public boolean onKeyPressed(int keyCode, int scanCode, int modifiers) {
        if (!focused)
            return false;

        switch (keyCode) {
            case class_3675.field_31983 ->
                    cycleValue(-1);
            case class_3675.field_31984 ->
                    cycleValue(1);
            case class_3675.field_31957, class_3675.field_31947, class_3675.field_31980 ->
                    cycleValue(KeyUtils.hasControlDown(modifiers) || KeyUtils.hasShiftDown(modifiers) ? -1 : 1);
            default -> {
                return false;
            }
        }

        return true;
    }

    @Override
    protected int getHoveredControlWidth() {
        return getUnhoveredControlWidth();
    }
}
