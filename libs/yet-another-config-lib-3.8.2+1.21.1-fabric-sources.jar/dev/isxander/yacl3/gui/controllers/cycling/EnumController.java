package dev.isxander.yacl3.gui.controllers.cycling;

import dev.isxander.yacl3.api.NameableEnum;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ValueFormatter;
import java.util.Arrays;
import java.util.function.Function;
import net.minecraft.class_2561;

/**
 * Simple controller type that displays the enum on the right.
 * <p>
 * Cycles forward with left click, cycles backward with right click or when shift is held
 *
 * @param <T> enum type
 */
public class EnumController<T extends Enum<T>> extends CyclingListController<T> {
    public static <T extends Enum<T>> Function<T, class_2561> getDefaultFormatter() {
        return value -> {
            if (value instanceof NameableEnum nameableEnum)
                return nameableEnum.getDisplayName();
            //? if <1.21.11 {
            if (value instanceof net.minecraft.class_7291 translatableOption)
                return translatableOption.method_42627();
            //?}
            return class_2561.method_43470(value.toString());
        };
    }

    public EnumController(Option<T> option, Class<T> enumClass) {
        this(option, getDefaultFormatter(), enumClass.getEnumConstants());
    }

    /**
     * Constructs a cycling enum controller.
     *
     * @param option bound option
     * @param valueFormatter format the enum into any {@link class_2561}
     * @param availableValues all enum constants that can be cycled through
     */
    public EnumController(Option<T> option, Function<T, class_2561> valueFormatter, T[] availableValues) {
        super(option, Arrays.asList(availableValues), valueFormatter);
    }

    public static <T extends Enum<T>> EnumController<T> createInternal(Option<T> option, ValueFormatter<T> formatter, T[] values) {
        return new EnumController<>(option, formatter::format, values);
    }
}
