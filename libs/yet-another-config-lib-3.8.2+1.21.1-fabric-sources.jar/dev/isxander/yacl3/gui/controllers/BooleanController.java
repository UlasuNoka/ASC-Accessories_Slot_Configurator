package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ValueFormatter;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_5244;

/**
 * This controller renders a simple formatted {@link class_2561}
 */
public class BooleanController implements Controller<Boolean> {

    public static final Function<Boolean, class_2561> ON_OFF_FORMATTER = (state) ->
            state
                    ? class_5244.field_24332
                    : class_5244.field_24333;

    public static final Function<Boolean, class_2561> TRUE_FALSE_FORMATTER = (state) ->
            state
                    ? class_2561.method_43471("yacl.control.boolean.true")
                    : class_2561.method_43471("yacl.control.boolean.false");

    public static final Function<Boolean, class_2561> YES_NO_FORMATTER = (state) ->
            state
                    ? class_5244.field_24336
                    : class_5244.field_24337;

    private final Option<Boolean> option;
    private final ValueFormatter<Boolean> valueFormatter;
    private final boolean coloured;

    /**
     * Constructs a tickbox controller
     * with the default value formatter of {@link BooleanController#ON_OFF_FORMATTER}
     *
     * @param option bound option
     */
    public BooleanController(Option<Boolean> option) {
        this(option, ON_OFF_FORMATTER, false);
    }

    /**
     * Constructs a tickbox controller
     * with the default value formatter of {@link BooleanController#ON_OFF_FORMATTER}
     *
     * @param option bound option
     * @param coloured value format is green or red depending on the state
     */
    public BooleanController(Option<Boolean> option, boolean coloured) {
        this(option, ON_OFF_FORMATTER, coloured);
    }

    /**
     * Constructs a tickbox controller
     *
     * @param option bound option
     * @param valueFormatter format value into any {@link class_2561}
     * @param coloured value format is green or red depending on the state
     */
    public BooleanController(Option<Boolean> option, Function<Boolean, class_2561> valueFormatter, boolean coloured) {
        this.option = option;
        this.valueFormatter = valueFormatter::apply;
        this.coloured = coloured;
    }

    @ApiStatus.Internal
    public static BooleanController createInternal(Option<Boolean> option, ValueFormatter<Boolean> formatter, boolean coloured) {
        return new BooleanController(option, formatter::format, coloured);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Option<Boolean> option() {
        return option;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public class_2561 formatValue() {
        return valueFormatter.format(option().pendingValue());
    }

    /**
     * Value format is green or red depending on the state
     */
    public boolean coloured() {
        return coloured;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AbstractWidget provideWidget(YACLScreen screen, Dimension<Integer> widgetDimension) {
        return new BooleanControllerElement(this, screen, widgetDimension);
    }

    public static class BooleanControllerElement extends ControllerWidget<BooleanController> {
        public BooleanControllerElement(BooleanController control, YACLScreen screen, Dimension<Integer> dim) {
            super(control, screen, dim);
        }

        @Override
        protected void drawHoveredControl(class_332 graphics, int mouseX, int mouseY, float delta) {

        }

        @Override
        protected void drawValueText(class_332 graphics, int mouseX, int mouseY, float delta) {
            super.drawValueText(graphics, mouseX, mouseY, delta);

            if (hovered) {
                //? if >=1.21.9
                //graphics.requestCursor(isAvailable() ? com.mojang.blaze3d.platform.cursor.CursorTypes.POINTING_HAND : com.mojang.blaze3d.platform.cursor.CursorTypes.NOT_ALLOWED);
            }
        }

        @Override
        public boolean onMouseClicked(double mouseX, double mouseY, int button) {
            if (!method_25405(mouseX, mouseY) || !isAvailable())
                return false;

            toggleSetting();
            return true;
        }

        @Override
        protected int getHoveredControlWidth() {
            return getUnhoveredControlWidth();
        }

        public void toggleSetting() {
            control.option().requestSet(!control.option().pendingValue());
            playDownSound();
        }

        @Override
        protected class_2561 getValueText() {
            if (control.coloured()) {
                return super.getValueText().method_27661().method_27692(control.option().pendingValue() ? class_124.field_1060 : class_124.field_1061);
            }

            return super.getValueText();
        }

        @Override
        public boolean onKeyPressed(int keyCode, int scanCode, int modifiers) {
            if (!method_25370()) {
                return false;
            }

            if (keyCode == class_3675.field_31957 || keyCode == class_3675.field_31947 || keyCode == class_3675.field_31980) {
                toggleSetting();
                return true;
            }

            return false;
        }
    }
}
