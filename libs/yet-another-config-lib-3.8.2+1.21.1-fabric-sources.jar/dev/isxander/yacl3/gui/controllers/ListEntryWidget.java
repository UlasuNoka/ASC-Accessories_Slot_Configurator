package dev.isxander.yacl3.gui.controllers;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.api.ListOption;
import dev.isxander.yacl3.api.ListOptionEntry;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.TooltipButtonWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_6382;

public class ListEntryWidget extends AbstractWidget implements class_4069 {
    private final TooltipButtonWidget removeButton, moveUpButton, moveDownButton;
    private final AbstractWidget entryWidget;

    private final ListOption<?> listOption;
    private final ListOptionEntry<?> listOptionEntry;

    private final String optionNameString;

    private class_364 focused;
    private boolean dragging;

    public ListEntryWidget(YACLScreen screen, ListOptionEntry<?> listOptionEntry, AbstractWidget entryWidget) {
        super(entryWidget.getDimension().withHeight(Math.min(entryWidget.getDimension().height(), 20) - ((listOptionEntry.parentGroup().indexOf(listOptionEntry) == listOptionEntry.parentGroup().options().size() - 1) ? 0 : 2))); // -2 to remove the padding
        this.listOptionEntry = listOptionEntry;
        this.listOption = listOptionEntry.parentGroup();
        this.optionNameString = listOptionEntry.name().getString().toLowerCase();
        this.entryWidget = entryWidget;

        Dimension<Integer> dim = entryWidget.getDimension();
        entryWidget.setDimension(dim.clone().move(20 * 2, 0).expand(-20 * 3, 0));

        removeButton = new TooltipButtonWidget(screen, dim.xLimit() - 20, dim.y(), 20, 20, class_2561.method_43470("\u274c"), class_2561.method_43471("yacl.list.remove"), btn -> {
            listOption.removeEntry(listOptionEntry);
            updateButtonStates();
        });

        moveUpButton = new TooltipButtonWidget(screen, dim.x(), dim.y(), 20, 20, class_2561.method_43470("\u2191"), class_2561.method_43471("yacl.list.move_up"), btn -> {
            int index = listOption.indexOf(listOptionEntry) - 1;
            if (index >= 0) {
                listOption.removeEntry(listOptionEntry);
                listOption.insertEntry(index, listOptionEntry);
                updateButtonStates();
            }
        });

        moveDownButton = new TooltipButtonWidget(screen, dim.x() + 20, dim.y(), 20, 20, class_2561.method_43470("\u2193"), class_2561.method_43471("yacl.list.move_down"), btn -> {
            int index = listOption.indexOf(listOptionEntry) + 1;
            if (index < listOption.options().size()) {
                listOption.removeEntry(listOptionEntry);
                listOption.insertEntry(index, listOptionEntry);
                updateButtonStates();
            }
        });

        updateButtonStates();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        updateButtonStates(); // update every render in case option becomes available/unavailable

        removeButton.method_46419(getDimension().y());
        moveUpButton.method_46419(getDimension().y());
        moveDownButton.method_46419(getDimension().y());
        entryWidget.setDimension(entryWidget.getDimension().withY(getDimension().y()));

        removeButton.method_25394(graphics, mouseX, mouseY, delta);
        moveUpButton.method_25394(graphics, mouseX, mouseY, delta);
        moveDownButton.method_25394(graphics, mouseX, mouseY, delta);
        entryWidget.method_25394(graphics, mouseX, mouseY, delta);
    }

    protected void updateButtonStates() {
        removeButton.field_22763 = listOption.available() && listOption.numberOfEntries() > listOption.minimumNumberOfEntries();
        moveUpButton.field_22763 = listOption.indexOf(listOptionEntry) > 0 && listOption.available();
        moveDownButton.field_22763 = listOption.indexOf(listOptionEntry) < listOption.options().size() - 1 && listOption.available();
    }

    @Override
    public void unfocus() {
        entryWidget.unfocus();
    }

    @Override
    public void method_37020(class_6382 builder) {
        entryWidget.method_37020(builder);
    }

    @Override
    public boolean matchesSearch(String query) {
        return optionNameString.contains(query.toLowerCase());
    }

    @Override
    public List<? extends class_364> method_25396() {
        return ImmutableList.of(moveUpButton, moveDownButton, entryWidget, removeButton);
    }

    @Override
    public boolean method_25397() {
        return dragging;
    }

    @Override
    public void method_25398(boolean dragging) {
        this.dragging = dragging;
    }

    @Nullable
    @Override
    public class_364 method_25399() {
        return focused;
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        this.focused = focused;
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent mouseButtonEvent, boolean doubleClick) {
        return ContainerEventHandler.super.mouseClicked(mouseButtonEvent, doubleClick);
    }
    *///?} else {
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        return class_4069.super.method_25402(mouseX, mouseY, button);
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent mouseButtonEvent) {
        return ContainerEventHandler.super.mouseReleased(mouseButtonEvent);
    }
    *///?} else {
    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return class_4069.super.method_25406(mouseX, mouseY, button);
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent mouseButtonEvent, double dx, double dy) {
        return ContainerEventHandler.super.mouseDragged(mouseButtonEvent, dx, dy);
    }
    *///?} else {
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dx, double dy) {
        return class_4069.super.method_25403(mouseX, mouseY, button, dx, dy);
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent keyEvent) {
        return ContainerEventHandler.super.keyPressed(keyEvent);
    }
    *///?} else {
    @Override
    public boolean method_25404(int keycode, int scancode, int modifiers) {
        return class_4069.super.method_25404(keycode, scancode, modifiers);
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean keyReleased(net.minecraft.client.input.KeyEvent keyEvent) {
        return ContainerEventHandler.super.keyReleased(keyEvent);
    }
    *///?} else {
    @Override
    public boolean method_16803(int keycode, int scancode, int modifiers) {
        return class_4069.super.method_16803(keycode, scancode, modifiers);
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent characterEvent) {
        return ContainerEventHandler.super.charTyped(characterEvent);
    }
    *///?} else {
    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return class_4069.super.method_25400(codePoint, modifiers);
    }
    //?}
}
