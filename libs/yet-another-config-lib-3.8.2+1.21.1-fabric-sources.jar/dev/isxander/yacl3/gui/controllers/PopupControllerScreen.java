package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.gui.YACLScreen;
import net.minecraft.class_332;
import net.minecraft.class_437;

//? if >=1.21.9 {
/*import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
*///?}

public class PopupControllerScreen extends class_437 {
    private final YACLScreen backgroundYaclScreen;
    private final ControllerPopupWidget<?> controllerPopup;
    public PopupControllerScreen(YACLScreen backgroundYaclScreen, ControllerPopupWidget<?> controllerPopup) {
        super(controllerPopup.popupTitle()); //Gets narrated by the narrator
        this.backgroundYaclScreen = backgroundYaclScreen;
        this.controllerPopup = controllerPopup;
    }


    @Override
    protected void method_25426() {
        this.method_37063(this.controllerPopup);
    }

    @Override
    protected void method_48640() {
        super.method_48640();
        this.method_25419();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        controllerPopup.renderBackground(graphics, mouseX, mouseY, delta);
        this.backgroundYaclScreen.method_25394(graphics, -1, -1, delta); //mouseX/Y set to -1 to prevent hovering outlines

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void method_25420(
            class_332 guiGraphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        // in 1.21.6+ renderBackground isn't called in render, it's called earlier before the blur pass
        //? if >=1.21.6
        //this.backgroundYaclScreen.renderBackground(guiGraphics, mouseX, mouseY, partialTick);
    }


    //? if >=1.21.9 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        if (!super.mouseClicked(mouseButtonEvent, bl)) {
            this.onClose();
            return false;
        }
        return true;
    }
    *///?} else {
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!super.method_25402(mouseX, mouseY, button)) {
            this.method_25419();
            return false;
        }
        return true;
    }
    //?}

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        if (controllerPopup.method_25401(mouseX, mouseY, horizontal, vertical)) {
            return true;
        }
        backgroundYaclScreen.method_25401(mouseX, mouseY, horizontal, vertical); //mouseX & mouseY are needed here
        return super.method_25401(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        controllerPopup.method_16014(mouseX, mouseY);
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean charTyped(CharacterEvent characterEvent) {
        return controllerPopup.charTyped(characterEvent);
    }
    *///?} else {
    @Override
    public boolean method_25400(char codePoint, int modifiers) {
        return controllerPopup.method_25400(codePoint, modifiers);
    }
    //?}


    //? if >=1.21.9 {
    /*@Override
    public boolean keyPressed(KeyEvent keyEvent) {
        return controllerPopup.keyPressed(keyEvent);
    }
    *///?} else {
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        return controllerPopup.method_25404(keyCode, scanCode, modifiers);
    }
    //?}

    @Override
    public void method_25393() {
        super.method_25393();
        this.backgroundYaclScreen.method_25393();
    }

    @Override
    public void method_25419() {
        this.field_22787.field_1755 = backgroundYaclScreen;
        this.controllerPopup.close();
    }

}
