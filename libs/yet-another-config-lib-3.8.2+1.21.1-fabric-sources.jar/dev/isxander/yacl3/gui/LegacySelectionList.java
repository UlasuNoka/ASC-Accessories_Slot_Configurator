//? if <1.21.9 {
package dev.isxander.yacl3.gui;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.mixin.AbstractSelectionListAccessor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import net.minecraft.class_4265;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8016;
import net.minecraft.class_8021;
import net.minecraft.class_8023;
import net.minecraft.class_8030;

public abstract class LegacySelectionList<E extends LegacySelectionList.Entry<E>> extends class_4265<E> implements class_8021 {

    public LegacySelectionList(class_310 client, int y, int width, int height) {
        //? if >=1.21.4 {
        /*super(client, width, height, y, 0);
        ((AbstractSelectionListAccessor) this).setRenderHeader(false);
        *///?} else {
        super(client, width, height, y, 20);
         //?}

        //? if <1.21.4
        method_25315(false, 0);
    }

    // for parity with modern, no need in legacy as everything is positioned on render
    protected void repositionEntries() {}

    /*
    The default implementation of scrollbarX does not respect left/right positioning of the list.
    */
    //? if <1.21.4 {
    @Override
    protected int method_25329() {
        return this.scrollBarX();
    }
    //?} else {
    /*@Override
    *///?}
    protected int scrollBarX() {
        return this.method_46426() + this.method_25368() - field_45909;
    }

    /*
    The legacy list has a fixed entry height for elements.
    This implementation allows each element to define its own height.
    So we override the relevant methods to use this behaviour instead.
     */
    //? <1.21.4 {
    @Override
    protected int method_25317() {
        return this.contentHeight();
    }
    //?} else {
    /*@Override
    *///?}
    protected int contentHeight() {
        return method_25396().stream().mapToInt(E::method_25364).sum();
    }

    @Override
    protected void centerScrollOn(E entry) {
        double d = (this.field_22759) / -2d;
        for (int i = 0; i < this.method_25396().indexOf(entry) && i < this.method_25340(); i++)
            d += method_25396().get(i).method_25364();
        this.method_25307(d);
    }

    @Override
    /*? if >=1.21.2 {*/ /*public *//*?} else {*/ protected /*?}*/
    int method_25337(int index) {
        int integer = method_46427() + 4 - (int) this.scrollAmount() + field_22748;
        for (int i = 0; i < method_25396().size() && i < index; i++)
            integer += method_25396().get(i).method_25364();
        return integer;
    }

    @Override
    protected void ensureVisible(E entry) {
        int entryIndex = this.method_25396().indexOf(entry);

        int top = this.method_25337(entryIndex);
        int j = top - this.method_46427() - 4 - entry.method_25364();
        if (j < 0) {
            this.method_25307(this.scrollAmount() + j);
        }

        int k = this.method_46427() + this.method_25364() - top - entry.method_25364() * 2;
        if (k < 0) {
            this.method_25307(this.scrollAmount() - k);
        }
    }

    @Nullable
    @Override
    protected E method_25308(double x, double y) {
        y += scrollAmount();

        if (x < this.method_46426() || x > this.method_46426() + this.method_25368())
            return null;

        int currentY = this.method_46427() - field_22748 + 4;
        for (E entry : method_25396()) {
            if (y >= currentY && y <= currentY + entry.method_25364()) {
                return entry;
            }

            currentY += entry.method_25364();
        }

        return null;
    }

    @Override
    protected void method_25311(class_332 graphics, int mouseX, int mouseY, float delta) {
        int left = this.method_25342();
        int right = this.method_25322();
        int count = this.method_25340();

        for(int i = 0; i < count; ++i) {
            E entry = method_25396().get(i);
            int top = this.method_25337(i);
            int bottom = top + entry.method_25364();
            int entryHeight = entry.method_25364() - 4;
            if (bottom >= this.method_46427() && top <= this.method_46427() + this.method_25364()) {
                this.method_44397(graphics, mouseX, mouseY, delta, i, left, top, right, entryHeight);
            }
        }
    }

    //? if <1.21.4 {
    public double scrollAmount() {
        return this.method_25341();
    }
    //?}


    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        this.method_25307(this.scrollAmount() - scrollY * 20);
        return true;
    }

    public abstract static class Entry<E extends LegacySelectionList.Entry<E>> extends class_4265.class_4266<E> implements class_8021 {
        public static final int CONTENT_PADDING = 2;
        private int x, y, width, height;
        private boolean hovered;
        private final LegacySelectionList<E> parent;

        public Entry(LegacySelectionList<E> parent) {
            this.parent = parent;
        }

        public abstract void renderContent(class_332 graphics, int mouseX, int mouseY, boolean hovered, float deltaTicks);

        @Override
        public void method_25343(class_332 guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            this.method_46421(left);
            this.method_46419(top);
            this.setWidth(width);
            this.hovered = hovering;
            // don't set height as the entry itself controls that

            this.renderContent(guiGraphics, mouseX, mouseY, hovering, partialTick);
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            return this.method_48202().method_58137((int) mouseX, (int) mouseY);
        }

        @Override
        public boolean method_25370() {
            return parent.method_25336() == this;
        }

        public boolean isHovered() {
            return hovered;
        }

        @Override
        public int method_46426() {
            return x;
        }

        @Override
        public int method_46427() {
            return y;
        }

        @Override
        public void method_46421(int x) {
            this.x = x;
        }

        @Override
        public void method_46419(int y) {
            this.y = y;
        }

        @Override
        public int method_25368() {
            return width;
        }

        @Override
        public int method_25364() {
            return height;
        }

        public void setWidth(int width) {
            this.width = width;
        }

        public void setHeight(int height) {
            this.height = height;
        }

        public int getContentX() {
            return this.method_46426() + CONTENT_PADDING;
        }

        public int getContentY() {
            return this.method_46427() + CONTENT_PADDING;
        }

        public int getContentHeight() {
            return this.method_25364() - CONTENT_PADDING * 2;
        }

        public int getContentYMiddle() {
            return this.getContentY() + this.getContentHeight() / CONTENT_PADDING;
        }

        public int getContentBottom() {
            return this.getContentY() + this.getContentHeight();
        }

        public int getContentWidth() {
            return this.method_25368() - CONTENT_PADDING * 2;
        }

        public int getContentXMiddle() {
            return this.getContentX() + this.getContentWidth() / CONTENT_PADDING;
        }

        public int getContentRight() {
            return this.getContentX() + this.getContentWidth();
        }

        @Override
        public void method_48206(Consumer<class_339> consumer) {

        }

        @Override
        public @NotNull class_8030 method_48202() {
            return class_8021.super.method_48202();
        }
    }

    public static class Holder<T extends LegacySelectionList<?>> extends class_339 implements class_4069, WidgetAndType<T> {
        private final T list;

        public Holder(T list) {
            super(0, 0, 100, 0, class_5244.field_39003);
            this.list = list;
        }

        @Override
        public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float deltaTick) {
            this.list.method_25394(guiGraphics, mouseX, mouseY, deltaTick);
        }

        @Override
        protected void method_47399(class_6382 output) {
            this.list.method_37020(output);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return ImmutableList.of(this.list);
        }

        public T getList() {
            return list;
        }

        @Override
        public boolean method_25402(double mouseX, double mouseY, int button /*? if >=1.21.9 {*/ /*,boolean doubleClick *//*?}*/) {
            return this.list.method_25402(mouseX, mouseY, button /*? if >=1.21.9 {*/ /*,doubleClick *//*?}*/);
        }

        @Override
        public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
            return this.list.method_25403(mouseX, mouseY, button, deltaX, deltaY);
        }

        @Override
        public boolean method_25406(double mouseX, double mouseY, int button) {
            return this.list.method_25406(mouseX, mouseY, button);
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
            System.out.println("Legacy list scrolled: " + horizontal + ", " + vertical);
            return this.list.method_25401(mouseX, mouseY, horizontal, vertical);
        }

        @Override
        public boolean method_25404(int i, int j, int k) {
            return this.list.method_25404(i, j, k);
        }

        @Override
        public boolean method_25400(char c, int i) {
            return this.list.method_25400(c, i);
        }

        @Override
        public boolean method_25397() {
            return this.list.method_25397();
        }

        @Override
        public void method_25398(boolean dragging) {
            this.list.method_25398(dragging);
        }

        @Nullable
        @Override
        public class_364 method_25399() {
            return this.list.method_25336();
        }

        @Override
        public void method_25395(@Nullable class_364 listener) {
            this.list.method_25395(listener);
        }

        @Nullable
        @Override
        public class_8016 method_48205(class_8023 event) {
            return this.list.method_48205(event);
        }

        @Nullable
        @Override
        public class_8016 method_48218() {
            return this.list.method_48218();
        }

        @Override
        public void method_46421(int x) {
            this.list.method_46421(x);
        }

        @Override
        public void method_46419(int y) {
            this.list.method_46419(y);
        }

        @Override
        public int method_46426() {
            return this.list.method_46426();
        }

        @Override
        public int method_46427() {
            return this.list.method_46427();
        }

        @Override
        public void method_25358(int width) {
            this.list.method_25358(width);
        }

        @Override
        public void method_53533(int height) {
            this.list.method_53533(height);
        }

        @Override
        public int method_25368() {
            return this.list.method_25368();
        }

        @Override
        public int method_25364() {
            return this.list.method_25364();
        }

        @Override
        public void method_48206(Consumer<class_339> consumer) {
            this.list.method_48206(consumer);
        }

        @Override
        public T getType() {
            return this.list;
        }

        @Override
        public class_339 getWidget() {
            return this;
        }

        @Override
        public boolean method_25405(double mouseX, double mouseY) {
            // AbstractWidget impl uses the fields width and height, we override getWidth and getHeight
            // this allows Screen#getChildAt to work, which means scrolling will work.
            return this.method_37303()
                   && this.field_22764
                   && mouseX >= this.method_46426()
                   && mouseY >= this.method_46427()
                   && mouseX < this.method_46426() + this.method_25368()
                   && mouseY < this.method_46427() + this.method_25364()   ;
        }
    }
}
//?}
