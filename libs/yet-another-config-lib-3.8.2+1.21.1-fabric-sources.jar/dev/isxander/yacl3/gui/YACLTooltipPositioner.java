package dev.isxander.yacl3.gui;

import org.joml.Vector2i;
import org.joml.Vector2ic;

import java.util.function.Supplier;
import net.minecraft.class_3532;
import net.minecraft.class_8000;
import net.minecraft.class_8030;

public class YACLTooltipPositioner implements class_8000 {
    private final Supplier<class_8030> buttonDimensions;

    public YACLTooltipPositioner(net.minecraft.class_339 widget) {
        this.buttonDimensions = widget::method_48202;
    }

    public YACLTooltipPositioner(dev.isxander.yacl3.gui.AbstractWidget widget) {
        this.buttonDimensions = () -> {
            var dim = widget.getDimension();
            return new class_8030(dim.x(), dim.y(), dim.width(), dim.height());
        };
    }

    public YACLTooltipPositioner(Supplier<class_8030> buttonDimensions) {
        this.buttonDimensions = buttonDimensions;
    }

    @Override
    public Vector2ic method_47944(int guiWidth, int guiHeight, int x, int y, int width, int height) {
        class_8030 buttonDimensions = this.buttonDimensions.get();

        int centerX = buttonDimensions.method_49620() + buttonDimensions.comp_1196() / 2;
        int aboveY = buttonDimensions.method_49618() - height - 4;
        int belowY = buttonDimensions.method_49618() + buttonDimensions.comp_1197() + 4;

        int maxBelow = guiHeight - (belowY + height);
        int minAbove = aboveY - height;

        int yResult = aboveY;
        if (minAbove < 8)
            yResult = maxBelow > minAbove ? belowY : aboveY;

        int xResult = class_3532.method_15340(centerX - width / 2, -4, guiWidth - width - 4);

        return new Vector2i(xResult, yResult);
    }
}
