package dev.isxander.yacl3.gui.tab;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.gui.render.ColorGradientRenderState;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import dev.isxander.yacl3.mixin.TabNavigationBarAccessor;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_8087;
import net.minecraft.class_8088;
import net.minecraft.class_8089;
import net.minecraft.class_8133;
import net.minecraft.class_8209;
import net.minecraft.class_8667;
import org.jetbrains.annotations.Nullable;

public class ScrollableNavigationBar extends class_8089 {
    private static final int NAVBAR_MARGIN = 28;

    private static final class_327 font = class_310.method_1551().field_1772;

    private int scrollOffset;
    private int maxScrollOffset;

    private final TabNavigationBarAccessor accessor;

    public ScrollableNavigationBar(int width, class_8088 tabManager, Iterable<? extends class_8087> tabs) {
        super(width, tabManager, ImmutableList.copyOf(tabs));
        this.accessor = (TabNavigationBarAccessor) this;

        // add tab tooltips to the tab buttons
        for (class_8209 tabButton : accessor.yacl$getTabButtons()) {
            if (tabButton.method_49609() instanceof TabExt tab) {
                tabButton.method_47400(tab.getTooltip());
            }
        }
    }

    @Override
    public void method_49613() {
        ImmutableList<class_8209> tabButtons = accessor.yacl$getTabButtons();
        int noScrollWidth = accessor.yacl$getWidth() - NAVBAR_MARGIN*2;

        int allTabsWidth = 0;
        // first pass: set the width of each tab button
        for (class_8209 tabButton : tabButtons) {
            int buttonWidth = font.method_27525(tabButton.method_25369()) + 20;
            allTabsWidth += buttonWidth;
            tabButton.method_25358(buttonWidth);
        }

        if (allTabsWidth < noScrollWidth) {
            int equalWidth = noScrollWidth / tabButtons.size();
            var smallTabs = tabButtons.stream().filter(btn -> btn.method_25368() < equalWidth).toList();
            var bigTabs = tabButtons.stream().filter(btn -> btn.method_25368() >= equalWidth).toList();
            int leftoverWidth = noScrollWidth - bigTabs.stream().mapToInt(class_339::method_25368).sum();
            int equalWidthForSmallTabs = leftoverWidth / smallTabs.size();
            for (class_8209 tabButton : smallTabs) {
                tabButton.method_25358(equalWidthForSmallTabs);
            }

            allTabsWidth = noScrollWidth;
        }

        class_8133 layout = ((TabNavigationBarAccessor) this).yacl$getLayout();
        layout.method_48222();
        layout.method_46419(0);
        scrollOffset = 0;

        layout.method_46421(Math.max((accessor.yacl$getWidth() - allTabsWidth) / 2, NAVBAR_MARGIN));
        this.maxScrollOffset = Math.max(0, allTabsWidth - noScrollWidth);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        GuiUtils.pushPose(graphics);
        // render option list BELOW the navbar without need to scissor
        GuiUtils.translateZ(graphics, 10);

        super.method_25394(graphics, mouseX, mouseY, delta);

        class_8667 layout = accessor.yacl$getLayout();
        // draw right fade
        if (this.scrollOffset < this.maxScrollOffset - NAVBAR_MARGIN) {
            int right = accessor.yacl$getWidth();
            ColorGradientRenderState.createHorizontal(
                    graphics,
                    right - 40,
                    layout.method_46427(),
                    right,
                    layout.method_46427() + layout.method_25364(),
                    0x00000000, 0xFF000000
            ).submit(graphics);

            graphics.method_51433(font, "→", right - 10, layout.method_46427() + (layout.method_25364() - font.field_2000) / 2, 0xFFFFFFFF, false);
        }

        // draw left fade
        if (this.scrollOffset > NAVBAR_MARGIN) {
            ColorGradientRenderState.createHorizontal(
                    graphics,
                    0,
                    layout.method_46427(),
                    40,
                    layout.method_46427() + layout.method_25364(),
                    0xFF000000, 0x00000000
            ).submit(graphics);

            graphics.method_51433(font, "←", 5, layout.method_46427() + (layout.method_25364() - font.field_2000) / 2, 0xFFFFFFFF, false);
        }

        GuiUtils.popPose(graphics);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        this.setScrollOffset(this.scrollOffset - (int) (vertical * 15) - (int) (horizontal * 15));
        return true;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return mouseY <= 24;
    }

    public void setScrollOffset(int scrollOffset) {
        class_8133 layout = ((TabNavigationBarAccessor) this).yacl$getLayout();

        layout.method_46421(layout.method_46426() + this.scrollOffset);
        this.scrollOffset = class_3532.method_15340(scrollOffset, 0, maxScrollOffset);
        layout.method_46421(layout.method_46426() - this.scrollOffset);
    }

    public int getScrollOffset() {
        return scrollOffset;
    }

    @Override
    public void method_25395(@Nullable class_364 child) {
        super.method_25395(child);
        if (child instanceof class_8209 tabButton) {
            this.ensureVisible(tabButton);
        }
    }

    protected void ensureVisible(class_8209 tabButton) {
        if (tabButton.method_46426() < NAVBAR_MARGIN) {
            this.setScrollOffset(this.scrollOffset - (NAVBAR_MARGIN - tabButton.method_46426()));
        } else if (tabButton.method_46426() + tabButton.method_25368() > accessor.yacl$getWidth() - NAVBAR_MARGIN) {
            this.setScrollOffset(this.scrollOffset + (tabButton.method_46426() + tabButton.method_25368() - (accessor.yacl$getWidth() - NAVBAR_MARGIN)));
        }
    }

    public ImmutableList<class_8087> getTabs() {
        return accessor.yacl$getTabs();
    }

    public class_8088 getTabManager() {
        return accessor.yacl$getTabManager();
    }
}
