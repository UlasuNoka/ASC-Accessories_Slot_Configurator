package dev.isxander.yacl3.gui.tab;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_7919;
import net.minecraft.class_8087;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface TabExt extends class_8087 {
    @Nullable class_7919 getTooltip();

    default void tick() {}

    default void renderBackground(class_332 graphics) {}

    //? if >=1.21.6
    //@Override
    default @NotNull class_2561 getTabExtraNarration() {
        return class_2561.method_43473();
    }
}
