package dev.isxander.yacl3.gui.image;

import net.minecraft.class_332;

public interface ImageRenderer {
    int render(class_332 graphics, int x, int y, int renderWidth, float tickDelta);

    void close();

    default void tick() {}
}
