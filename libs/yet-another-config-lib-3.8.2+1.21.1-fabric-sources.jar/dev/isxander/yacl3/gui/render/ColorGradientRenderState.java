package dev.isxander.yacl3.gui.render;

import net.minecraft.class_332;
import net.minecraft.class_4588;

public record ColorGradientRenderState(
        BaseRenderState baseState,
        int x0,
        int y0,
        int x1,
        int y1,
        int x0y0Color,
        int x1y0Color,
        int x0y1Color,
        int x1y1Color
) implements YACLGuiElementRenderState {
    @Override
    public void buildVertices(class_4588 vertexConsumer, float z) {
        add2DVertex(vertexConsumer, this.x0(), this.y0(), z).method_39415(this.x0y0Color());
        add2DVertex(vertexConsumer, this.x0(), this.y1(), z).method_39415(this.x0y1Color());
        add2DVertex(vertexConsumer, this.x1(), this.y1(), z).method_39415(this.x1y1Color());
        add2DVertex(vertexConsumer, this.x1(), this.y0(), z).method_39415(this.x1y0Color());
    }

    public static ColorGradientRenderState create(
            class_332 graphics,
            int x0, int y0,
            int x1, int y1,
            int x0y0Color, int x1y0Color,
            int x0y1Color, int x1y1Color
    ) {
        return new ColorGradientRenderState(
                BaseRenderState.create(graphics, null, x0, y0, x1, y1),
                x0, y0, x1, y1,
                x0y0Color, x1y0Color,
                x0y1Color, x1y1Color
        );
    }

    public static ColorGradientRenderState createHorizontal(
            class_332 graphics,
            int x0, int y0,
            int x1, int y1,
            int leftColor, int rightColor
    ) {
        return create(
                graphics,
                x0, y0, x1, y1,
                leftColor, rightColor,
                leftColor, rightColor
        );
    }

    public static ColorGradientRenderState createVertical(
            class_332 graphics,
            int x0, int y0,
            int x1, int y1,
            int topColor, int bottomColor
    ) {
        return create(
                graphics,
                x0, y0, x1, y1,
                topColor, topColor,
                bottomColor, bottomColor
        );
    }
}
