package dev.isxander.yacl3.gui.render;

import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
//?}

public record BaseRenderState(
        //? if >=1.21.6 {
        /*RenderPipeline pipeline,
        TextureSetup textureSetup,
        Matrix3x2f pose,
        @Nullable ScreenRectangle bounds,
        @Nullable ScreenRectangle scissorArea
        *///?} else {
        net.minecraft.class_1921 renderType,
        Matrix4f pose
        //?}
) {
    public static BaseRenderState create(class_332 graphics, @Nullable class_2960 texture, int x0, int y0, int x1, int y1) {
        //? if >=1.21.6 {
        /*@Nullable ScreenRectangle scissorArea = GuiRenderStateSink.peekScissorStack(graphics);
        ScreenRectangle bounds = boundsFromMaxPoints(x0, y0, x1, y1, graphics.pose(), scissorArea);

        return new BaseRenderState(
                texture != null ? RenderPipelines.GUI_TEXTURED : RenderPipelines.GUI,
                textureSetup(texture),
                new Matrix3x2f(graphics.pose()),
                bounds, scissorArea
        );
        *///?} else {
        return create(graphics, texture);
        //?}
    }

    public static BaseRenderState create(class_332 graphics, @Nullable class_2960 texture) {
        //? if >=1.21.6 {
        /*return new BaseRenderState(
                texture != null ? RenderPipelines.GUI_TEXTURED : RenderPipelines.GUI,
                textureSetup(texture),
                new Matrix3x2f(graphics.pose()),
                null, GuiRenderStateSink.peekScissorStack(graphics)
        );
        *///?} else {
        return new BaseRenderState(
                texture != null ? GuiUtils.guiTextured(false).apply(texture) : class_1921.method_51784(),
                graphics.method_51448().method_23760().method_23761()
        );
        //?}
    }

    //? if >=1.21.6 {
    /*private static TextureSetup textureSetup(@Nullable ResourceLocation textureId) {
        if (textureId != null) {
            AbstractTexture texture = Minecraft.getInstance().getTextureManager().getTexture(textureId);
            return TextureSetup.singleTexture(texture.getTextureView() /^? if >=1.21.11 >>^//^,texture.getSampler()^/ );
        }
        return TextureSetup.noTexture();
    }

    private static ScreenRectangle boundsFromMaxPoints(int x0, int y0, int x1, int y1, Matrix3x2f pose, @Nullable ScreenRectangle scissorArea) {
        ScreenRectangle bounds = new ScreenRectangle(x0, y0, x1 - x0, y1 - y0).transformMaxBounds(pose);
        return scissorArea != null ? scissorArea.intersection(bounds) : bounds;
    }
    *///?}
}
