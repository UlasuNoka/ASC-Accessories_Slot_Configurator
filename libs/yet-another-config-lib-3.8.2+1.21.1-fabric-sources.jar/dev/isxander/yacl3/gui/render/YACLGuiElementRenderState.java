package dev.isxander.yacl3.gui.render;

import net.minecraft.class_332;
import net.minecraft.class_4588;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

//? if >=1.21.6 {
/*import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import com.mojang.blaze3d.pipeline.RenderPipeline;

*///?}

public interface YACLGuiElementRenderState /*? if >=1.21.6 {*//*extends GuiElementRenderState *//*?}*/ {

    BaseRenderState baseState();

    //? if >=1.21.9 {
    /*@Override
    default void buildVertices(VertexConsumer vertexConsumer) {
        this.buildVertices(vertexConsumer, 0);
    }

    // purely to ease development, we backport this method from <1.21.9 and have a placeholder Z
    void buildVertices(VertexConsumer vertexConsumer, float z);
    *///?}

    //? if >=1.21.6 {
    /*@Override
    default @NotNull RenderPipeline pipeline() {
        return baseState().pipeline();
    }

    @Override
    default @NotNull TextureSetup textureSetup() {
        return baseState().textureSetup();
    }

    @Override
    default @Nullable ScreenRectangle scissorArea() {
        return baseState().scissorArea();
    }

    @Override
    default @Nullable ScreenRectangle bounds() {
        return baseState().bounds();
    }
    *///?} else {
    void buildVertices(class_4588 vertexConsumer, float z);
    //?}

    default class_4588 add2DVertex(
            class_4588 vertexConsumer,
            float x, float y, float z
    ) {
        //? if >=1.21.6 {
        /*return vertexConsumer.addVertexWith2DPose(this.baseState().pose(), x, y /^? if <1.21.9 {^/ ,z /^?}^/ );
        *///?} else {
        return vertexConsumer.method_22918(this.baseState().pose(), x, y, z);
        //?}
    }

    default void submit(class_332 graphics) {
        //? if >=1.21.6 {
        /*GuiRenderStateSink.submit(graphics, this);
        *///?} else {
        // TODO: don't drawSpecial as it finishes the batch
        class_4588 vertexConsumer = GuiRenderStateSink.bufferSource(graphics).getBuffer(baseState().renderType());
        buildVertices(vertexConsumer, 0);
        //?}
    }


}
