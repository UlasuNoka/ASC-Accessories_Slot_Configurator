package dev.isxander.yacl3.gui.render;

import net.minecraft.class_332;
import net.minecraft.class_4597;

public interface GuiRenderStateSink {
    //? if >=1.21.6 {
    /*void yacl$submit(GuiElementRenderState renderState);

    static void submit(GuiGraphics graphics, GuiElementRenderState renderState) {
        ((GuiRenderStateSink) graphics).yacl$submit(renderState);
    }

    ScreenRectangle yacl$peekScissorStack();

    static ScreenRectangle peekScissorStack(GuiGraphics graphics) {
        return ((GuiRenderStateSink) graphics).yacl$peekScissorStack();
    }
    *///?} else {
    class_4597 yacl$bufferSource();

    static class_4597 bufferSource(class_332 graphics) {
        return ((GuiRenderStateSink) graphics).yacl$bufferSource();
    }
    //?}
}
