package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;

public class TextScaledButtonWidget extends TooltipButtonWidget {
    public float textScale;

    public TextScaledButtonWidget(class_437 screen, int x, int y, int width, int height, float textScale, class_2561 message, class_2561 tooltip, class_4241 onPress) {
        super(screen, x, y, width, height, message, tooltip, onPress);
        this.textScale = textScale;
    }

    public TextScaledButtonWidget(class_437 screen, int x, int y, int width, int height, float textScale, class_2561 message, class_4241 onPress) {
        this(screen, x, y, width, height, textScale, message, null, onPress);
    }

    // FIXME: i cannot figure out how to compensate a scale with a translation so for now the reset button is small fuck you
    //? if >=1.21.11 {
    /*@Override
    protected void renderDefaultLabel(@NotNull ActiveTextCollector activeTextCollector) {
        super.renderDefaultLabel(activeTextCollector);
    }
    *///?} else {
    @Override
    public void method_48589(class_332 graphics, class_327 textRenderer, int color) {
        class_327 font = class_310.method_1551().field_1772;

        GuiUtils.pushPose(graphics);
        GuiUtils.translate2D(graphics, ((this.method_46426() + this.field_22758 / 2f) - font.method_27525(method_25369()) * textScale / 2), (float)this.method_46427() + (this.field_22759 - 8 * textScale) / 2f / textScale);
        GuiUtils.scale2D(graphics, textScale, textScale);
        graphics.method_51439(font, method_25369(), 0, 0, color | class_3532.method_15386(this.field_22765 * 255.0F) << 24, true);
        GuiUtils.popPose(graphics);
    }
    //?}
}
