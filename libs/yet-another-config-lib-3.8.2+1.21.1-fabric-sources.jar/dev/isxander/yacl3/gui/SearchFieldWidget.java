package dev.isxander.yacl3.gui;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

public class SearchFieldWidget extends class_342 {
    private class_2561 emptyText;
    private final YACLScreen yaclScreen;
    private final class_327 font;
    private final Consumer<String> updateConsumer;

    private boolean isEmpty = true;

    public SearchFieldWidget(YACLScreen yaclScreen, class_327 font, int x, int y, int width, int height, class_2561 text, class_2561 emptyText, Consumer<String> updateConsumer) {
        super(font, x, y, width, height, text);
        method_1863(this::update);
        this.yaclScreen = yaclScreen;
        this.font = font;
        this.emptyText = emptyText;
        this.updateConsumer = updateConsumer;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float delta) {
        super.method_48579(graphics, mouseX, mouseY, delta);
        if (method_1885() && isEmpty()) {
            graphics.method_51439(font, emptyText, method_46426() + 4, this.method_46427() + (this.field_22759 - 8) / 2, 0x707070, true);
        }
    }

    private void update(String query) {
        boolean wasEmpty = isEmpty;
        isEmpty = query.isEmpty();

        if (isEmpty && wasEmpty)
            return;

        updateConsumer.accept(query);
    }

    public String getQuery() {
        return method_1882().toLowerCase();
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public class_2561 getEmptyText() {
        return emptyText;
    }

    public void setEmptyText(class_2561 emptyText) {
        this.emptyText = emptyText;
    }
}
