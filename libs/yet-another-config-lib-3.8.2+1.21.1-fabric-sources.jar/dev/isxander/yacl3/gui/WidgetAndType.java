package dev.isxander.yacl3.gui;

import net.minecraft.class_339;

public interface WidgetAndType<T> {
    T getType();

    class_339 getWidget();

    static <T extends class_339> WidgetAndType<T> ofWidget(T widget) {
        return new WidgetAndType<>() {
            @Override
            public T getType() {
                return widget;
            }

            @Override
            public class_339 getWidget() {
                return widget;
            }
        };
    }
}
