package dev.isxander.yacl3.gui;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.utils.WidgetUtils;
import dev.isxander.yacl3.impl.utils.YACLConstants;
import dev.isxander.yacl3.mixin.AbstractSelectionListAccessor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5489;
import net.minecraft.class_6379;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_8028;

public class OptionListWidget extends YACLSelectionList<OptionListWidget.Entry> {
    private final YACLScreen yaclScreen;
    private final ConfigCategory category;
    private String searchQuery = "";
    private final Consumer<DescriptionWithName> hoverEvent;
    private DescriptionWithName lastHoveredOption;

    public OptionListWidget(YACLScreen screen, ConfigCategory category, class_310 client, int x, int y, int width, int height, Consumer<DescriptionWithName> hoverEvent) {
        super(client, width, height, y);
        this.yaclScreen = screen;
        this.category = category;
        this.hoverEvent = hoverEvent;

        refreshOptions();

        for (OptionGroup group : category.groups()) {
            if (group instanceof ListOption<?> listOption) {
                listOption.addRefreshListener(() -> refreshListEntries(listOption, category));
            }
        }
    }

    public void refreshOptions() {
        method_25339();

        for (OptionGroup group : category.groups()) {
            GroupSeparatorEntry groupSeparatorEntry;
            if (!group.isRoot()) {
                groupSeparatorEntry = group instanceof ListOption<?> listOption
                        ? new ListGroupSeparatorEntry(listOption, yaclScreen)
                        : new GroupSeparatorEntry(group, yaclScreen);
                method_25321(groupSeparatorEntry);
            } else {
                groupSeparatorEntry = null;
            }

            List<dev.isxander.yacl3.gui.OptionListWidget.Entry> optionEntries = new ArrayList<>();

            // add empty entry to make sure users know it's empty not just bugging out
            if (groupSeparatorEntry instanceof ListGroupSeparatorEntry listGroupSeparatorEntry) {
                if (listGroupSeparatorEntry.listOption.options().isEmpty()) {
                    EmptyListLabel emptyListLabel = new EmptyListLabel(listGroupSeparatorEntry, category);
                    method_25321(emptyListLabel);
                    optionEntries.add(emptyListLabel);
                }
            }

            for (Option<?> option : group.options()) {
                OptionEntry entry = new OptionEntry(option, category, group, groupSeparatorEntry, option.controller().provideWidget(yaclScreen, getDefaultEntryDimension()));
                method_25321(entry);
                optionEntries.add(entry);
            }

            if (groupSeparatorEntry != null) {
                groupSeparatorEntry.setChildEntries(optionEntries);
            }
        }

        method_25307(0);
        repositionEntries();
    }

    //? if >=1.21.9 {
    /*@Override
    protected int addEntry(Entry entry) {
        // instead of using super.defaultEntryHeight, use the height the entry wants to be - our entries set their height in the constructor
        return this.addEntry(entry, entry.getHeight());
    }
    *///?}

    private void refreshListEntries(ListOption<?> listOption, ConfigCategory category) {
        // find group separator for group
        ListGroupSeparatorEntry groupSeparator = this.method_25396().stream().filter(e -> e instanceof ListGroupSeparatorEntry gs && gs.group == listOption).map(ListGroupSeparatorEntry.class::cast).findAny().orElse(null);

        if (groupSeparator == null) {
            YACLConstants.LOGGER.warn("Can't find group seperator to refresh list option entries for list option " + listOption.name());
            return;
        }

        for (dev.isxander.yacl3.gui.OptionListWidget.Entry entry : groupSeparator.childEntries)
            this.method_25330(entry);
        groupSeparator.childEntries.clear();

        // if no entries, below loop won't run where addEntryBelow() recaches viewable children
        if (listOption.options().isEmpty()) {
            EmptyListLabel emptyListLabel;
            addEntryBelow(groupSeparator, emptyListLabel = new EmptyListLabel(groupSeparator, category));
            groupSeparator.childEntries.add(emptyListLabel);
            return;
        }

        dev.isxander.yacl3.gui.OptionListWidget.Entry lastEntry = groupSeparator;
        for (ListOptionEntry<?> listOptionEntry : listOption.options()) {
            OptionEntry optionEntry = new OptionEntry(listOptionEntry, category, listOption, groupSeparator, listOptionEntry.controller().provideWidget(yaclScreen, getDefaultEntryDimension()));
            addEntryBelow(lastEntry, optionEntry);
            groupSeparator.childEntries.add(optionEntry);
            lastEntry = optionEntry;
        }
    }

    public Dimension<Integer> getDefaultEntryDimension() {
        return Dimension.ofInt(method_25342(), 0, method_25322(), 20);
    }

    public void expandAllGroups() {
        for (dev.isxander.yacl3.gui.OptionListWidget.Entry entry : super.method_25396()) {
            if (entry instanceof GroupSeparatorEntry groupSeparatorEntry) {
                groupSeparatorEntry.setExpanded(true);
            }
        }
    }

    @Override
    public int method_25342() {
        return super.method_25342() - field_45909;
    }

    @Override
    public int method_25322() {
        return method_25368() - field_45909 - 20; // 10 padding each side
    }

    public void updateSearchQuery(String query) {
        this.searchQuery = query;
        for (dev.isxander.yacl3.gui.OptionListWidget.Entry entry : this.method_25396()) {
            entry.updateSearchQuery(query);
        }
        expandAllGroups();
        repositionEntries();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        for (dev.isxander.yacl3.gui.OptionListWidget.Entry child : method_25396()) {
            if (child != method_25308(mouseX, mouseY) && child instanceof OptionEntry optionEntry)
                optionEntry.widget.unfocus();
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        super.method_25401(mouseX, mouseY, horizontal, vertical);

        for (dev.isxander.yacl3.gui.OptionListWidget.Entry child : method_25396()) {
            if (child.method_25401(mouseX, mouseY, horizontal, vertical))
                break;
        }

        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.method_25336() != null && this.method_25397() && method_53812(button)) {
            return WidgetUtils.mouseDragged(this.method_25336(), mouseX, mouseY, button, deltaX, deltaY);
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        for (dev.isxander.yacl3.gui.OptionListWidget.Entry child : method_25396()) {
            if (child.method_25404(keyCode, scanCode, modifiers))
                return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        for (dev.isxander.yacl3.gui.OptionListWidget.Entry child : method_25396()) {
            if (child.method_25400(chr, modifiers))
                return true;
        }

        return super.method_25400(chr, modifiers);
    }

    private List<dev.isxander.yacl3.gui.OptionListWidget.Entry> superModifiableChildren() {
        //? if >=1.21.9 {
        /*// noinspection unchecked
        return (List<Entry>) ((AbstractSelectionListAccessor) this).getChildren();
        *///?} else {
        return this.method_25396();
        //?}
    }

    public void addEntryAtIndex(int index, dev.isxander.yacl3.gui.OptionListWidget.Entry entry) {
        superModifiableChildren().add(index, entry);
        this.repositionEntries();
    }

    public void addEntryBelow(dev.isxander.yacl3.gui.OptionListWidget.Entry below, dev.isxander.yacl3.gui.OptionListWidget.Entry entry) {
        int idx = superModifiableChildren().indexOf(below) + 1;

        if (idx == 0)
            throw new IllegalStateException("The entry to insert below does not exist!");

        addEntryAtIndex(idx, entry);
    }

    public void addEntryBelowWithoutScroll(dev.isxander.yacl3.gui.OptionListWidget.Entry below, dev.isxander.yacl3.gui.OptionListWidget.Entry entry) {
        double d = (double)this.contentHeight() - this.scrollAmount();
        addEntryBelow(below, entry);
        method_25307(this.contentHeight() - d);
    }

    private void setHoverDescription(DescriptionWithName description) {
        if (description != lastHoveredOption) {
            lastHoveredOption = description;
            hoverEvent.accept(description);
        }
    }

    @Override
    protected void method_57715(class_332 guiGraphics) {
    }

    /*? if <1.21.4 {*/
    @Override
     /*?}*/
    protected boolean method_53812(int button) {
        return button == class_3675.field_32000 || button == class_3675.field_32002 || button == class_3675.field_32001;
    }

    @Override
    protected dev.isxander.yacl3.gui.OptionListWidget.Entry nextEntry(@NotNull class_8028 direction, @NotNull Predicate<dev.isxander.yacl3.gui.OptionListWidget.Entry> predicate, dev.isxander.yacl3.gui.OptionListWidget.Entry selected) {
        // ensure we don't focus unviewable entries
        return super.method_48199(direction, entry -> entry.isViewable() && predicate.test(entry), selected);
    }

    public abstract class Entry extends YACLSelectionList.Entry<dev.isxander.yacl3.gui.OptionListWidget.Entry> {
        protected boolean searchQueryMatches = true;

        public Entry() {
            super(OptionListWidget.this);
        }

        public boolean updateSearchQuery(String searchQuery) {
            boolean matches = searchQuery.isEmpty();
            if (this.searchQueryMatches != matches) {
                this.searchQueryMatches = matches;
                refreshVisibilityState();
            }
            return this.searchQueryMatches;
        }

        public boolean isViewable() {
            return this.searchQueryMatches;
        }

        @Override
        public int method_25364() {
            if (!isViewable()) {
                return 0;
            }
            return super.method_25364();
        }

        protected void refreshVisibilityState() {
            if (isViewable()) {
                onBecameViewable();
            } else {
                onBecameHidden();
            }
        }

        protected void onBecameViewable() {
        }

        protected void onBecameHidden() {
            this.setHeight(0);
        }
    }

    public class OptionEntry extends dev.isxander.yacl3.gui.OptionListWidget.Entry {
        public final Option<?> option;
        public final ConfigCategory category;
        public final OptionGroup group;

        public final @Nullable GroupSeparatorEntry groupSeparatorEntry;

        public final AbstractWidget widget;

        private final TextScaledButtonWidget resetButton;

        private final String categoryName;
        private final String groupName;

        public OptionEntry(Option<?> option, ConfigCategory category, OptionGroup group, @Nullable GroupSeparatorEntry groupSeparatorEntry, AbstractWidget widget) {
            this.option = option;
            this.category = category;
            this.group = group;
            this.groupSeparatorEntry = groupSeparatorEntry;
            this.widget = widget;
            this.categoryName = category.name().getString().toLowerCase();
            this.groupName = group.name().getString().toLowerCase();
            if (option.canResetToDefault() && this.widget.canReset()) {
                this.widget.setDimension(this.widget.getDimension().expanded(-20, 0));
                this.resetButton = new TextScaledButtonWidget(yaclScreen, widget.getDimension().xLimit(), -50, 20, 20, 2f, class_2561.method_43470("\u21BB"), button -> {
                    option.requestSetDefault();
                });
                option.addListener((opt, val) -> this.resetButton.field_22763 = !opt.isPendingValueDefault() && opt.available());
                this.resetButton.field_22763 = !option.isPendingValueDefault() && option.available();
            } else {
                this.resetButton = null;
            }
            this.updateHeight();
        }

        @Override
        public void renderContent(class_332 graphics, int mouseX, int mouseY, boolean hovered, float deltaTicks) {
            if (!this.isViewable()) {
                return;
            }

            this.updateHeight();

            widget.setDimension(widget.getDimension().withY(this.method_46427()));

            widget.method_25394(graphics, mouseX, mouseY, deltaTicks);

            if (resetButton != null) {
                resetButton.method_46419(this.method_46427());
                resetButton.method_25394(graphics, mouseX, mouseY, deltaTicks);
            }

            if (method_25405(mouseX, mouseY)) {
                setHoverDescription(DescriptionWithName.of(option.name(), option.description()));
            }
        }

        @Override
        public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
            return widget.method_25401(mouseX, mouseY, horizontal, vertical);
        }

        @Override
        public boolean method_25404(int keyCode, int scanCode, int modifiers) {
            return WidgetUtils.keyPressed(widget, keyCode, scanCode, modifiers);
        }

        @Override
        public boolean method_25400(char chr, int modifiers) {
            return WidgetUtils.charTyped(widget, chr, modifiers);
        }

        @Override
        public boolean updateSearchQuery(String searchQuery) {
            this.searchQueryMatches = searchQuery.isEmpty()
                    || groupName.contains(searchQuery)
                    || widget.matchesSearch(searchQuery);
            refreshVisibilityState();
            return this.searchQueryMatches;
        }

        @Override
        public boolean isViewable() {
            return super.isViewable()
                    && (groupSeparatorEntry == null || groupSeparatorEntry.isExpanded());
        }

        @Override
        protected void onBecameViewable() {
            super.onBecameViewable();
            updateHeight();
        }

        private void updateHeight() {
            this.setHeight(Math.max(widget.getDimension().height(), resetButton != null ? resetButton.method_25364() : 0) + 2);
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);
            if (focused)
                setHoverDescription(DescriptionWithName.of(option.name(), option.description()));
        }

        @Override
        public List<? extends class_6379> method_37025() {
            if (resetButton == null)
                return ImmutableList.of(widget);

            return ImmutableList.of(widget, resetButton);
        }

        @Override
        public List<? extends class_364> method_25396() {
            if (resetButton == null)
                return ImmutableList.of(widget);

            return ImmutableList.of(widget, resetButton);
        }
    }

    public class GroupSeparatorEntry extends dev.isxander.yacl3.gui.OptionListWidget.Entry {
        protected final OptionGroup group;
        protected final class_5489 wrappedName;
        protected final class_5489 wrappedTooltip;

        protected final LowProfileButtonWidget expandMinimizeButton;

        protected final class_437 screen;
        protected final class_327 font = class_310.method_1551().field_1772;

        protected boolean groupExpanded;

        protected List<dev.isxander.yacl3.gui.OptionListWidget.Entry> childEntries = new ArrayList<>();

        private GroupSeparatorEntry(OptionGroup group, class_437 screen) {
            this.group = group;
            this.screen = screen;
            this.wrappedName = class_5489.method_30890(font, group.name(), method_25322() - 45);
            this.wrappedTooltip = class_5489.method_30890(font, group.tooltip(), screen.field_22789 / 3 * 2 - 10);
            this.groupExpanded = !group.collapsed();
            this.expandMinimizeButton = new LowProfileButtonWidget(0, 0, 20, 20, class_2561.method_43473(), btn -> onExpandButtonPress());
            updateExpandMinimizeText();
            updateHeight();
        }

        @Override
        public void renderContent(class_332 graphics, int mouseX, int mouseY, boolean hovered, float deltaTicks) {
            if (!this.isViewable()) {
                return;
            }

            this.updateHeight();

            int buttonY = this.method_46427() + this.method_25364() / 2 - expandMinimizeButton.method_25364() / 2 + 1;

            expandMinimizeButton.method_46419(buttonY);
            expandMinimizeButton.method_46421(this.method_46426());
            expandMinimizeButton.method_25394(graphics, mouseX, mouseY, deltaTicks);

            //? if >=1.21.11 {
            /*wrappedName.visitLines(net.minecraft.client.gui.TextAlignment.CENTER, this.getX() + this.getWidth() / 2, this.getY() + getYPadding(), font.lineHeight, graphics.textRenderer());
            *///?} elif >=1.21.9 {
            /*wrappedName.render(graphics, MultiLineLabel.Align.CENTER, this.getX() + this.getWidth() / 2, this.getY() + getYPadding(), font.lineHeight, false, -1);
            *///?} else {
            wrappedName.method_30888(graphics, this.method_46426() + this.method_25368() / 2, this.method_46427() + getYPadding());
             //?}

            if (method_25405(mouseX, mouseY)) {
                setHoverDescription(DescriptionWithName.of(group.name(), group.description()));
            }
        }

        public boolean isExpanded() {
            return groupExpanded;
        }

        public void setExpanded(boolean expanded) {
            if (this.groupExpanded == expanded)
                return;

            this.groupExpanded = expanded;
            updateExpandMinimizeText();
            childEntries.forEach(dev.isxander.yacl3.gui.OptionListWidget.Entry::refreshVisibilityState);
            repositionEntries();
        }

        protected void onExpandButtonPress() {
            setExpanded(!isExpanded());
        }

        protected void updateExpandMinimizeText() {
            expandMinimizeButton.method_25355(class_2561.method_43470(isExpanded() ? "▼" : "▶"));
        }

        public void setChildEntries(List<? extends dev.isxander.yacl3.gui.OptionListWidget.Entry> childEntries) {
            this.childEntries.clear();
            this.childEntries.addAll(childEntries);
        }

        @Override
        public boolean updateSearchQuery(String searchQuery) {
            return this.searchQueryMatches = searchQuery.isEmpty() || childEntries.stream().anyMatch(e -> e.updateSearchQuery(searchQuery));
        }

        private int getYPadding() {
            return 6;
        }

        @Override
        public void method_25365(boolean focused) {
            super.method_25365(focused);
            if (focused)
                setHoverDescription(DescriptionWithName.of(group.name(), group.description()));
        }

        private void updateHeight() {
            this.setHeight(Math.max(wrappedName.method_30887(), 1) * font.field_2000 + getYPadding() * 2);
        }

        @Override
        public @NotNull List<? extends class_6379> method_37025() {
            return ImmutableList.of(new class_6379() {
                @Override
                public @NotNull class_6380 method_37018() {
                    return class_6380.field_33785;
                }

                @Override
                public void method_37020(class_6382 builder) {
                    builder.method_37034(class_6381.field_33788, group.name());
                    builder.method_37034(class_6381.field_33790, group.tooltip());
                }
            });
        }

        @Override
        public @NotNull List<? extends class_364> method_25396() {
            return ImmutableList.of(expandMinimizeButton);
        }
    }

    public class ListGroupSeparatorEntry extends GroupSeparatorEntry {
        private final ListOption<?> listOption;
        private final TextScaledButtonWidget resetListButton;
        private final TooltipButtonWidget addListButton;

        private ListGroupSeparatorEntry(ListOption<?> group, class_437 screen) {
            super(group, screen);
            this.listOption = group;

            this.resetListButton = new TextScaledButtonWidget(screen, method_31383() - 20, -50, 20, 20, 1f, class_2561.method_43470("\u21BB"), button -> {
                group.requestSetDefault();
            });
            group.addListener((opt, val) -> this.resetListButton.field_22763 = !opt.isPendingValueDefault() && opt.available());
            this.resetListButton.field_22763 = !group.isPendingValueDefault() && group.available();


            this.addListButton = new TooltipButtonWidget(yaclScreen, resetListButton.method_46426() - 20, -50, 20, 20, class_2561.method_43470("+"), class_2561.method_43471("yacl.list.add_top"), btn -> {
                group.insertNewEntry();
                setExpanded(true);
            });

            updateExpandMinimizeText();
            minimizeIfUnavailable();
        }

        @Override
        public void renderContent(class_332 graphics, int mouseX, int mouseY, boolean hovered, float deltaTicks) {
            if (!this.isViewable()) {
                return;
            }

            updateExpandMinimizeText(); // update every render because option could become available/unavailable at any time

            super.renderContent(graphics, mouseX, mouseY, hovered, deltaTicks);

            int buttonY = expandMinimizeButton.method_46427();

            resetListButton.method_46419(buttonY);
            addListButton.method_46419(buttonY);

            resetListButton.method_25394(graphics, mouseX, mouseY, deltaTicks);
            addListButton.method_25394(graphics, mouseX, mouseY, deltaTicks);
        }

        private void minimizeIfUnavailable() {
            if (!listOption.available() && isExpanded()) {
                setExpanded(false);
            }
        }

        @Override
        protected void updateExpandMinimizeText() {
            super.updateExpandMinimizeText();
            expandMinimizeButton.field_22763 = listOption == null || listOption.available();
            if (addListButton != null)
                addListButton.field_22763 = expandMinimizeButton.field_22763 && listOption.numberOfEntries() < listOption.maximumNumberOfEntries();
        }

        @Override
        public void setExpanded(boolean expanded) {
            super.setExpanded(listOption.available() && expanded);
        }

        @Override
        public @NotNull List<? extends class_364> method_25396() {
            return ImmutableList.of(expandMinimizeButton, addListButton, resetListButton);
        }
    }

    public class EmptyListLabel extends dev.isxander.yacl3.gui.OptionListWidget.Entry {
        private final ListGroupSeparatorEntry parent;
        private final String groupName;
        private final String categoryName;

        public EmptyListLabel(ListGroupSeparatorEntry parent, ConfigCategory category) {
            this.parent = parent;
            this.groupName = parent.group.name().getString().toLowerCase();
            this.categoryName = category.name().getString().toLowerCase();
            this.setHeight(11);
        }

        @Override
        public void renderContent(class_332 graphics, int mouseX, int mouseY, boolean hovered, float deltaTicks) {
            graphics.method_27534(class_310.method_1551().field_1772, class_2561.method_43471("yacl.list.empty").method_27695(class_124.field_1063, class_124.field_1056), this.method_46426() + this.method_25368() / 2, this.method_46427(), -1);
        }

        @Override
        public boolean updateSearchQuery(String searchQuery) {
            return this.searchQueryMatches = searchQuery.isEmpty() || groupName.contains(searchQuery);
        }

        @Override
        public boolean isViewable() {
            return parent.isExpanded() && super.isViewable();
        }

        @Override
        protected void onBecameHidden() {
            super.onBecameHidden();
            setHeight(0);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return ImmutableList.of();
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return ImmutableList.of();
        }
    }
}
