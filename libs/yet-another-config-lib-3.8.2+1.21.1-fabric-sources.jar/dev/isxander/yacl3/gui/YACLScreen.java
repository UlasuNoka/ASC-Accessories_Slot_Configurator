package dev.isxander.yacl3.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.api.utils.MutableDimension;
import dev.isxander.yacl3.api.utils.OptionUtils;
import dev.isxander.yacl3.gui.controllers.PopupControllerScreen;
import dev.isxander.yacl3.gui.controllers.ControllerPopupWidget;
import dev.isxander.yacl3.gui.tab.ScrollableNavigationBar;
import dev.isxander.yacl3.gui.tab.TabExt;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import dev.isxander.yacl3.impl.utils.YACLConstants;
import dev.isxander.yacl3.platform.YACLPlatform;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_525;
import net.minecraft.class_5489;
import net.minecraft.class_7919;
import net.minecraft.class_8002;
import net.minecraft.class_8030;
import net.minecraft.class_8088;

//? if >=1.21.9
//import net.minecraft.client.input.MouseButtonEvent;

public class YACLScreen extends class_437 {
    public final YetAnotherConfigLib config;

    private final class_437 parent;

    public final class_8088 tabManager = new class_8088(this::method_37063, this::method_37066);
    public ScrollableNavigationBar tabNavigationBar;
    public class_8030 tabArea;

    public class_2561 saveButtonMessage;
    public class_7919 saveButtonTooltipMessage;
    private int saveButtonMessageTime;

    private boolean pendingChanges;

    public ControllerPopupWidget<?> currentPopupController = null;
    public boolean popupControllerVisible = false;

    public YACLScreen(YetAnotherConfigLib config, class_437 parent) {
        super(config.title());
        this.config = config;
        this.parent = parent;

        OptionUtils.forEachOptions(config, option -> {
            option.addEventListener((opt, event) -> {
                if (event != OptionEventListener.Event.INITIAL) onOptionChanged(opt);
            });
        });
    }

    @Override
    protected void method_25426() {
        tabArea = new class_8030(0, 24 - 1, this.field_22789, this.field_22790 - 24 + 1);

        int currentTab = tabNavigationBar != null
                ? tabNavigationBar.getTabs().indexOf(tabManager.method_48614())
                : 0;
        if (currentTab == -1)
            currentTab = 0;

        tabNavigationBar = new ScrollableNavigationBar(this.field_22789, tabManager, config.categories()
                .stream()
                .map(category -> {
                    if (category instanceof CustomTabProvider tabProvider) {
                        return tabProvider.createTab(this, tabArea);
                    }
                    if (category instanceof PlaceholderCategory placeholder)
                        return new PlaceholderTab(placeholder, this);
                    return new CategoryTab(this, category, tabArea);
                }).toList());
        tabNavigationBar.method_48987(currentTab, false);
        tabNavigationBar.method_49613();
        tabManager.method_48616(tabArea);
        method_37063(tabNavigationBar);

        config.initConsumer().accept(this);
    }

    public void addPopupControllerWidget(ControllerPopupWidget<?> controllerPopupWidget) {

        //Safety check for the color picker
        if (currentPopupController != null) {
            clearPopupControllerWidget();
        }

        currentPopupController = controllerPopupWidget;
        popupControllerVisible = true;

        OptionListWidget optionListWidget = null;
        if(this.tabNavigationBar.getTabManager().method_48614() instanceof CategoryTab categoryTab) {
            optionListWidget = categoryTab.optionList.getType();
        }
        if(optionListWidget != null) {
            this.field_22787.method_1507(new PopupControllerScreen(this, controllerPopupWidget));
        }
    }

    public void clearPopupControllerWidget() {
        if(class_310.method_1551().field_1755 instanceof PopupControllerScreen popupControllerScreen) {
            popupControllerScreen.method_25419();
        }
        popupControllerVisible = false;
        currentPopupController = null;
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25420(guiGraphics, mouseX, mouseY, partialTick);

        if (tabManager.method_48614() instanceof TabExt tab) {
            tab.renderBackground(guiGraphics);
        }
    }

    public void finishOrSave() {
        saveButtonMessage = null;

        if (pendingChanges()) {
            Set<OptionFlag> flags = new HashSet<>();
            OptionUtils.forEachOptions(config, option -> {
                if (option.applyValue()) {
                    flags.addAll(option.flags());
                }
            });
            OptionUtils.forEachOptions(config, option -> {
                if (option.changed()) {
                    // if still changed after applying, reset to the current value from binding
                    // as something has gone wrong.
                    option.forgetPendingValue();
                    YACLConstants.LOGGER.error("Option '{}' value mismatch after applying! Reset to binding's getter.", option.name().getString());
                }
            });
            config.saveFunction().run();

            flags.forEach(flag -> flag.accept(field_22787));

            pendingChanges = false;
            if (tabManager.method_48614() instanceof CategoryTab categoryTab) {
                categoryTab.updateButtons();
            }
        } else method_25419();
    }

    public void cancelOrReset() {
        if (pendingChanges()) { // if pending changes, button acts as a cancel button
            OptionUtils.forEachOptions(config, Option::forgetPendingValue);
            method_25419();
        } else { // if not, button acts as a reset button
            OptionUtils.forEachOptions(config, Option::requestSetDefault);
        }
    }

    public void undo() {
        OptionUtils.forEachOptions(config, Option::forgetPendingValue);
    }

    @Override
    public void method_25393() {
        if (tabManager.method_48614() instanceof TabExt tabExt) {
            tabExt.tick();
        }

        if (tabManager.method_48614() instanceof CategoryTab categoryTab) {
            if (saveButtonMessage != null) {
                if (saveButtonMessageTime > 140) {
                    saveButtonMessage = null;
                    saveButtonTooltipMessage = null;
                    saveButtonMessageTime = 0;
                } else {
                    saveButtonMessageTime++;
                    categoryTab.saveFinishedButton.method_25355(saveButtonMessage);
                    if (saveButtonTooltipMessage != null) {
                        categoryTab.saveFinishedButton.method_47400(saveButtonTooltipMessage);
                    }
                }
            }
        }
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        if (super.mouseClicked(mouseButtonEvent, bl)) {
            this.setDragging(true);
            return true;
        }
        return false;
    }
    *///?} else {
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (super.method_25402(mouseX, mouseY, button)) {
            this.method_25398(true);
            return true;
        }
        return false;
    }
    //?}

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseDragged(MouseButtonEvent mouseButtonEvent, double d, double e) {
        return this.getFocused() != null
                && this.isDragging()
                && (mouseButtonEvent.button() == InputConstants.MOUSE_BUTTON_LEFT || mouseButtonEvent.button() == InputConstants.MOUSE_BUTTON_RIGHT)
                && this.getFocused().mouseDragged(mouseButtonEvent, d, e);
    }
    *///?} else {
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return this.method_25399() != null
                && this.method_25397()
                && (button == class_3675.field_32000 || button == class_3675.field_32002)
                && this.method_25399().method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }
    //?}

    public void setSaveButtonMessage(class_2561 message, class_2561 tooltip) {
        saveButtonMessage = message;
        saveButtonTooltipMessage = class_7919.method_47407(tooltip);
        saveButtonMessageTime = 0;
    }

    public boolean pendingChanges() {
        return pendingChanges;
    }

    private void onOptionChanged(Option<?> option) {
        pendingChanges = false;

        OptionUtils.consumeOptions(config, opt -> {
            pendingChanges |= opt.changed();
            return pendingChanges;
        });

        if (tabManager.method_48614() instanceof CategoryTab categoryTab) {
            categoryTab.updateButtons();
        }
    }

    @Override
    public boolean method_25422() {
        if (pendingChanges()) {
            setSaveButtonMessage(class_2561.method_43471("yacl.gui.save_before_exit").method_27692(class_124.field_1061), class_2561.method_43471("yacl.gui.save_before_exit.tooltip"));
            return false;
        }
        return true;
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    public static void renderMultilineTooltip(class_332 graphics, class_327 font, class_5489 text, int centerX, int yAbove, int yBelow, int screenWidth, int screenHeight) {
        if (text.method_30887() > 0) {
            int maxWidth = text.method_44048();
            int lineHeight = font.field_2000 + 1;
            int height = text.method_30887() * lineHeight - 1;

            int belowY = yBelow + 12;
            int aboveY = yAbove - height + 12;
            int maxBelow = screenHeight - (belowY + height);
            int minAbove = aboveY - height;
            int y = aboveY;
            if (minAbove < 8)
                y = maxBelow > minAbove ? belowY : aboveY;

            int x = Math.max(centerX - text.method_44048() / 2 - 12, -6);

            int drawX = x + 12;
            int drawY = y - 12;

            GuiUtils.pushPose(graphics);
            class_8002.method_47946(
                    graphics,
                    drawX,
                    drawY,
                    maxWidth,
                    height
                    //? if <1.21.6
                    ,400
                    //? if >=1.21.2
                    //,null
            );
            GuiUtils.translateZ(graphics, 400);

            //? if >=1.21.11 {
            /*text.visitLines(net.minecraft.client.gui.TextAlignment.LEFT, drawX, drawY, lineHeight, graphics.textRenderer());
            *///?} elif >=1.21.9 {
            /*text.render(graphics, MultiLineLabel.Align.LEFT, drawX, drawY, lineHeight, false, -1);
            *///?} else {
            text.method_30893(graphics, drawX, drawY, lineHeight, -1);
            //?}

            GuiUtils.popPose(graphics);
        }
    }

    public static class CategoryTab implements TabExt {
        private static final class_2960 DARKER_BG = YACLPlatform.mcRl("textures/gui/menu_list_background.png");

        private final YACLScreen screen;
        private final ConfigCategory category;
        private final class_7919 tooltip;

        private WidgetAndType<OptionListWidget> optionList;
        public final class_4185 saveFinishedButton;
        public final class_4185 cancelResetButton;
        public final class_4185 undoButton;
        private final SearchFieldWidget searchField;
        private OptionDescriptionWidget descriptionWidget;

        private final class_8030 rightPaneDim;

        public CategoryTab(YACLScreen screen, ConfigCategory category, class_8030 tabArea) {
            this.screen = screen;
            this.category = category;
            this.tooltip = class_7919.method_47407(category.tooltip());

            int columnWidth = screen.field_22789 / 3;
            int padding = columnWidth / 20;
            columnWidth = Math.min(columnWidth, 400);
            int paddedWidth = columnWidth - padding * 2;
            rightPaneDim = new class_8030(screen.field_22789 / 3 * 2, tabArea.method_49618() + 1, screen.field_22789 / 3, tabArea.comp_1197());
            MutableDimension<Integer> actionDim = Dimension.ofInt(screen.field_22789 / 3 * 2 + screen.field_22789 / 6, screen.field_22790 - padding - 20, paddedWidth, 20);

            saveFinishedButton = class_4185.method_46430(class_2561.method_43470("Done"), btn -> screen.finishOrSave())
                    .method_46433(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .method_46437(actionDim.width(), actionDim.height())
                    .method_46431();

            actionDim.expand(-actionDim.width() / 2 - 2, 0).move(-actionDim.width() / 2 - 2, -22);
            cancelResetButton = class_4185.method_46430(class_2561.method_43470("Cancel"), btn -> screen.cancelOrReset())
                    .method_46433(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .method_46437(actionDim.width(), actionDim.height())
                    .method_46431();

            actionDim.move(actionDim.width() + 4, 0);
            undoButton = class_4185.method_46430(class_2561.method_43471("yacl.gui.undo"), btn -> screen.undo())
                    .method_46433(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .method_46437(actionDim.width(), actionDim.height())
                    .method_46436(class_7919.method_47407(class_2561.method_43471("yacl.gui.undo.tooltip")))
                    .method_46431();

            this.searchField = new SearchFieldWidget(
                    screen,
                    screen.field_22793,
                    screen.field_22789 / 3 * 2 + screen.field_22789 / 6 - paddedWidth / 2 + 1,
                    undoButton.method_46427() - 22,
                    paddedWidth - 2, 18,
                    class_2561.method_43471("gui.recipebook.search_hint"),
                    class_2561.method_43471("gui.recipebook.search_hint"),
                    searchQuery -> optionList.getType().updateSearchQuery(searchQuery)
            );

            this.optionList = YACLSelectionList.asWidget(
                    new OptionListWidget(screen, category, screen.field_22787, 0, 0, screen.field_22789 / 3 * 2 + 1, screen.field_22790, desc -> {
                        descriptionWidget.setOptionDescription(desc);
                    })
            );

            this.descriptionWidget = new OptionDescriptionWidget(
                    () -> new class_8030(
                            screen.field_22789 / 3 * 2 + padding,
                            tabArea.method_49618() + padding,
                            paddedWidth,
                            searchField.method_46427() - 1 - tabArea.method_49618() - padding * 2
                    ),
                    null
            );

            updateButtons();
        }

        @Override
        public class_2561 method_48610() {
            return category.name();
        }

        @Override
        public void method_48612(Consumer<class_339> consumer) {
            consumer.accept(optionList.getWidget());
            consumer.accept(saveFinishedButton);
            consumer.accept(cancelResetButton);
            consumer.accept(undoButton);
            consumer.accept(searchField);
            consumer.accept(descriptionWidget);
        }

        @Override
        public void renderBackground(class_332 graphics) {
            // right pane darker bg
            // 1.21.1 did not use RenderType/RenderPipeline in blit so we need to enable blending manually
            //? if <1.21.2
            RenderSystem.enableBlend();
            GuiUtils.blitGuiTex(graphics, DARKER_BG, rightPaneDim.method_49620(), rightPaneDim.method_49618(), rightPaneDim.method_49621() + 2, rightPaneDim.method_49619() + 2, rightPaneDim.comp_1196() + 2, rightPaneDim.comp_1197() + 2, 32, 32);
            //? if <1.21.2
            RenderSystem.disableBlend();

            // top separator for right pane
            GuiUtils.pushPose(graphics);
            GuiUtils.translateZ(graphics, 10);
            GuiUtils.blitGuiTex(graphics, class_525.field_49895, rightPaneDim.method_49620() - 1, rightPaneDim.method_49618() - 2, 0.0F, 0.0F, rightPaneDim.comp_1196() + 1, 2, 32, 2);
            GuiUtils.popPose(graphics);

            // left separator for right pane
            GuiUtils.pushPose(graphics);
            GuiUtils.translate2D(graphics, rightPaneDim.method_49620(), rightPaneDim.method_49618() - 1);
            GuiUtils.rotate2D(graphics, 90);
            GuiUtils.blitGuiTex(graphics, class_525.field_49896, 0, 0, 0f, 0f, rightPaneDim.comp_1197() + 1, 2, 32, 2);
            GuiUtils.popPose(graphics);
        }

        @Override
        public void method_48611(class_8030 tabArea) {
            var rect = new class_8030(tabArea.comp_1195(), tabArea.comp_1196() / 3 * 2, tabArea.comp_1197());
            optionList.getType().method_46421(rect.method_49620());
            optionList.getType().method_46419(rect.method_49618());
            optionList.getType().method_25358(rect.comp_1196());
            optionList.getType().method_53533(rect.comp_1197());
        }

        @Override
        public void tick() {
            descriptionWidget.tick();
        }

        @Nullable
        @Override
        public class_7919 getTooltip() {
            return tooltip;
        }

        public void updateButtons() {
            boolean pendingChanges = screen.pendingChanges();

            undoButton.field_22763 = pendingChanges;
            saveFinishedButton.method_25355(pendingChanges ? class_2561.method_43471("yacl.gui.save") : GuiUtils.translatableFallback("yacl.gui.done", class_5244.field_24334));
            saveFinishedButton.method_47400(class_7919.method_47407(pendingChanges ? class_2561.method_43471("yacl.gui.save.tooltip") : class_2561.method_43471("yacl.gui.finished.tooltip")));
            cancelResetButton.method_25355(pendingChanges ? GuiUtils.translatableFallback("yacl.gui.cancel", class_5244.field_24335) : class_2561.method_43471("controls.reset"));
            cancelResetButton.method_47400(class_7919.method_47407(pendingChanges ? class_2561.method_43471("yacl.gui.cancel.tooltip") : class_2561.method_43471("yacl.gui.reset.tooltip")));
        }
    }

    public static class PlaceholderTab implements TabExt {
        private final YACLScreen screen;
        private final PlaceholderCategory category;
        private final class_7919 tooltip;

        public PlaceholderTab(PlaceholderCategory category, YACLScreen screen) {
            this.screen = screen;
            this.category = category;
            this.tooltip = class_7919.method_47407(category.tooltip());
        }

        @Override
        public class_2561 method_48610() {
            return category.name();
        }

        @Override
        public void method_48612(Consumer<class_339> consumer) {

        }

        @Override
        public void method_48611(class_8030 screenRectangle) {
            screen.field_22787.method_1507(category.screen().apply(screen.field_22787, screen));
        }

        @Override
        public @Nullable class_7919 getTooltip() {
            return this.tooltip;
        }
    }
}
