package dev.isxander.yacl3.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_4069;
import net.minecraft.class_8027;
import net.minecraft.class_8028;
import net.minecraft.class_8089;

@Mixin(class_4069.class)
public interface ContainerEventHandlerMixin {
     // This mixin is used to prevent the tab bar from being focused when navigating left or right
     // through the YACL options screen. This can also apply to vanilla as navigating left or right
     // should never result in focusing the always-at-the-top tab bar.
     // Without this, navigating right from the option list focuses the tab bar, not the action buttons/description.
    @Redirect(
            method = {"nextFocusPathVaguelyInDirection", "nextFocusPathInDirection"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/events/ContainerEventHandler;children()Ljava/util/List;"
            )
    )
    default List<?> modifyFocusCandidates(class_4069 instance, @Local(argsOnly = true) class_8028 direction) {
        if (direction.method_48237() == class_8027.field_41822)
            return instance.method_25396().stream().filter(child -> !(child instanceof class_8089)).toList();
        return instance.method_25396();
    }
}
/*?} else {*/
/*@Mixin(ContainerEventHandler.class)
public class ContainerEventHandlerMixin {

}
*//*?}*/
