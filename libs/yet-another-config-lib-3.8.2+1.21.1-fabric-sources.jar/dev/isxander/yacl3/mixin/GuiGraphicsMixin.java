package dev.isxander.yacl3.mixin;

import dev.isxander.yacl3.gui.render.GuiRenderStateSink;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_332.class)
public class GuiGraphicsMixin implements GuiRenderStateSink {

    //? if >=1.21.6 {
    /*@Shadow @Final private GuiRenderState guiRenderState;

    @Override
    public void yacl$submit(GuiElementRenderState renderState) {
        this.guiRenderState.submitGuiElement(renderState);
    }


    @Shadow @Final private GuiGraphics.ScissorStack scissorStack;

    @Override
    public ScreenRectangle yacl$peekScissorStack() {
        return this.scissorStack.peek();
    }
    *///?} else {
    @Shadow
    @Final
    private class_4597.class_4598 bufferSource;

    @Override
    public class_4597 yacl$bufferSource() {
        return this.bufferSource;
    }
    //?}
}
