package dev.isxander.yacl3.mixin;

import net.minecraft.class_7172;
import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@ApiStatus.Internal
@Mixin(class_7172.class)
public interface OptionInstanceAccessor<T> {
    @Accessor
    T getInitialValue();
}
