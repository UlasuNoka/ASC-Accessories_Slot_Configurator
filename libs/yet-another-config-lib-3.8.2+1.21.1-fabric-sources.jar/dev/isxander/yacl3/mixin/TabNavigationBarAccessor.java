package dev.isxander.yacl3.mixin;

import com.google.common.collect.ImmutableList;
import net.minecraft.class_8087;
import net.minecraft.class_8088;
import net.minecraft.class_8089;
import net.minecraft.class_8209;
import net.minecraft.class_8667;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8089.class)
public interface TabNavigationBarAccessor {
    @Accessor("layout")
    class_8667 yacl$getLayout();

    @Accessor("width")
    int yacl$getWidth();

    @Accessor("tabManager")
    class_8088 yacl$getTabManager();

    @Accessor("tabs")
    ImmutableList<class_8087> yacl$getTabs();

    @Accessor("tabButtons")
    ImmutableList<class_8209> yacl$getTabButtons();

}
