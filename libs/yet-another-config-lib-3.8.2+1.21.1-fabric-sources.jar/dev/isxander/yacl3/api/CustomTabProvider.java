package dev.isxander.yacl3.api;

import dev.isxander.yacl3.gui.YACLScreen;
import net.minecraft.class_8030;
import net.minecraft.class_8087;

/**
 * Allows categories to provide custom tab windows that replaces the
 * regular YACL options screen. The tabs at the top will remain visible,
 * but you can now provide custom tab content for richer configurations.
 * <p>
 * Part of the GUI API: could change with minecraft updates and is not stable
 */
public interface CustomTabProvider {
    class_8087 createTab(YACLScreen screen, class_8030 tabArea);
}
