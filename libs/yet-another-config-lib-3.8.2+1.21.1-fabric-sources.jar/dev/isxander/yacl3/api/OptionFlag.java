package dev.isxander.yacl3.api;

import dev.isxander.yacl3.gui.RequireRestartScreen;
import java.util.function.Consumer;
import net.minecraft.class_310;

/**
 * Code that is executed upon certain options being applied.
 * Each flag is executed only once per save, no matter the amount of options with the flag.
 */
@FunctionalInterface
public interface OptionFlag extends Consumer<class_310> {
    /** Warns the user that a game restart is required for the changes to take effect */
    OptionFlag GAME_RESTART = client -> client.method_1507(new RequireRestartScreen(client.field_1755));

    /** Reloads chunks upon applying (F3+A) */
    OptionFlag RELOAD_CHUNKS = client -> client.field_1769.method_3279();

    OptionFlag WORLD_RENDER_UPDATE = client -> client.field_1769.method_3292();

    OptionFlag ASSET_RELOAD = class_310::method_1513;
}
