package dev.isxander.yacl3.api;

import net.minecraft.class_2561;

/**
 * Used for the default value formatter of {@link dev.isxander.yacl3.gui.controllers.cycling.EnumController} and {@link dev.isxander.yacl3.gui.controllers.dropdown.EnumDropdownController}
 */
public interface NameableEnum {
    class_2561 getDisplayName();
}
