package dev.isxander.yacl3.api.controller;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.impl.controller.ItemControllerBuilderImpl;
import net.minecraft.class_1792;

public interface ItemControllerBuilder extends ControllerBuilder<class_1792> {
	static ItemControllerBuilder create(Option<class_1792> option) {
		return new ItemControllerBuilderImpl(option);
	}
}
