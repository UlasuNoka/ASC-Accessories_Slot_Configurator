package dev.isxander.yacl3.api.controller;

import java.util.function.Function;
import net.minecraft.class_2561;

public interface ValueFormattableController<T, B extends ValueFormattableController<T, B>> extends ControllerBuilder<T> {
    B formatValue(ValueFormatter<T> formatter);

    @Deprecated
    default B valueFormatter(Function<T, class_2561> formatter) {
        return formatValue(formatter::apply);
    }
}
