package dev.isxander.yacl3.impl.controller;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ItemControllerBuilder;
import dev.isxander.yacl3.gui.controllers.dropdown.ItemController;
import net.minecraft.class_1792;

public class ItemControllerBuilderImpl extends AbstractControllerBuilderImpl<class_1792> implements ItemControllerBuilder {
	public ItemControllerBuilderImpl(Option<class_1792> option) {
		super(option);
	}

	@Override
	public Controller<class_1792> build() {
		return new ItemController(option);
	}
}
