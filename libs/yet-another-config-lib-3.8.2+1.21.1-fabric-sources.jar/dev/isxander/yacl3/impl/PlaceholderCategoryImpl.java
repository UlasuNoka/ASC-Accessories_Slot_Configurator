package dev.isxander.yacl3.impl;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.api.OptionGroup;
import dev.isxander.yacl3.api.PlaceholderCategory;
import dev.isxander.yacl3.gui.YACLScreen;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5250;

@ApiStatus.Internal
public final class PlaceholderCategoryImpl implements PlaceholderCategory {
    private final class_2561 name;
    private final BiFunction<class_310, YACLScreen, class_437> screen;
    private final class_2561 tooltip;

    public PlaceholderCategoryImpl(class_2561 name, BiFunction<class_310, YACLScreen, class_437> screen, class_2561 tooltip) {
        this.name = name;
        this.screen = screen;
        this.tooltip = tooltip;
    }

    @Override
    public @NotNull ImmutableList<OptionGroup> groups() {
        return ImmutableList.of();
    }

    @Override
    public @NotNull class_2561 name() {
        return name;
    }

    @Override
    public BiFunction<class_310, YACLScreen, class_437> screen() {
        return screen;
    }

    @Override
    public @NotNull class_2561 tooltip() {
        return tooltip;
    }

    @ApiStatus.Internal
    public static final class BuilderImpl implements dev.isxander.yacl3.api.PlaceholderCategory.Builder {
        private class_2561 name;

        private final List<class_2561> tooltipLines = new ArrayList<>();

        private BiFunction<class_310, YACLScreen, class_437> screenFunction;

        @Override
        public dev.isxander.yacl3.api.PlaceholderCategory.Builder name(@NotNull class_2561 name) {
            Validate.notNull(name, "`name` cannot be null");

            this.name = name;
            return this;
        }

        @Override
        public dev.isxander.yacl3.api.PlaceholderCategory.Builder tooltip(@NotNull class_2561... tooltips) {
            Validate.notEmpty(tooltips, "`tooltips` cannot be empty");

            tooltipLines.addAll(List.of(tooltips));
            return this;
        }

        @Override
        public dev.isxander.yacl3.api.PlaceholderCategory.Builder screen(@NotNull BiFunction<class_310, YACLScreen, class_437> screenFunction) {
            Validate.notNull(screenFunction, "`screenFunction` cannot be null");

            this.screenFunction = screenFunction;
            return this;
        }

        @Override
        public PlaceholderCategory build() {
            Validate.notNull(name, "`name` must not be null to build `ConfigCategory`");

            class_5250 concatenatedTooltip = class_2561.method_43473();
            boolean first = true;
            for (class_2561 line : tooltipLines) {
                if (!first) concatenatedTooltip.method_27693("\n");
                first = false;

                concatenatedTooltip.method_10852(line);
            }

            return new PlaceholderCategoryImpl(name, screenFunction, concatenatedTooltip);
        }
    }
}
