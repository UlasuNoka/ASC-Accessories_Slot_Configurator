package dev.isxander.yacl3.impl;

import com.google.common.collect.ImmutableSet;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.gui.controllers.LabelController;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class LabelOptionImpl extends OptionImpl<class_2561> implements LabelOption {
    public LabelOptionImpl(
            @NotNull StateManager<class_2561> stateManager,
            @NotNull Collection<OptionEventListener<class_2561>> optionEventListeners
    ) {
        super(
                class_2561.method_43470("Label Option"),
                OptionDescription::of,
                LabelController::new,
                stateManager,
                true,
                ImmutableSet.of(),
                optionEventListeners
        );
    }

    public LabelOptionImpl(class_2561 label) {
        this(
                StateManager.createImmutable(label),
                ImmutableSet.of()
        );
    }

    @Override
    public @NotNull class_2561 label() {
        return stateManager().get();
    }

    @Override
    public void setAvailable(boolean available) {
        throw new UnsupportedOperationException("Cannot change availability of label option");
    }

    @ApiStatus.Internal
    public static final class BuilderImpl implements LabelOption.Builder {
        private StateManager<class_2561> stateManager;
        private final List<class_2561> lines = new ArrayList<>();

        @Override
        public LabelOption.Builder state(@NotNull StateManager<class_2561> stateManager) {
            Validate.notNull(stateManager, "`stateManager` must not be null");
            Validate.isTrue(this.lines.isEmpty(), "Cannot set state manager if lines have already been defined");

            this.stateManager = stateManager;
            return this;
        }

        @Override
        public LabelOption.Builder line(@NotNull class_2561 line) {
            Validate.isTrue(stateManager == null, ".line() is a helper to create a state manager for you at build. If you have defined a custom state manager, do not use .line()");
            Validate.notNull(line, "`line` must not be null");

            this.lines.add(line);
            return this;
        }

        @Override
        public LabelOption.Builder lines(@NotNull Collection<? extends class_2561> lines) {
            Validate.isTrue(stateManager == null, ".lines() is a helper to create a state manager for you at build. If you have defined a custom state manager, do not use .lines()");

            this.lines.addAll(lines);
            return this;
        }

        @Override
        public LabelOption build() {
            Validate.isTrue(stateManager != null || !lines.isEmpty(), "Cannot build label option without a state manager or lines");

            if (!lines.isEmpty()) {
                class_5250 text = class_2561.method_43473();
                Iterator<class_2561> iterator = lines.iterator();
                while (iterator.hasNext()) {
                    text.method_10852(iterator.next());

                    if (iterator.hasNext())
                        text.method_27693("\n");
                }
                this.stateManager = StateManager.createSimple(new SelfContainedBinding<>(text));
            }

            return new LabelOptionImpl(this.stateManager, ImmutableSet.of());
        }
    }
}
