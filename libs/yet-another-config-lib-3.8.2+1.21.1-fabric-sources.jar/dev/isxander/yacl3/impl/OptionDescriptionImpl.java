package dev.isxander.yacl3.impl;

import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.debug.DebugProperties;
import dev.isxander.yacl3.gui.image.ImageRenderer;
import dev.isxander.yacl3.gui.image.ImageRendererManager;
import dev.isxander.yacl3.gui.image.impl.AnimatedDynamicTextureImage;
import dev.isxander.yacl3.gui.image.impl.DynamicTextureImage;
import dev.isxander.yacl3.gui.image.impl.ResourceTextureImage;
import org.apache.commons.lang3.Validate;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

public record OptionDescriptionImpl(class_2561 text, CompletableFuture<Optional<ImageRenderer>> image) implements OptionDescription {
    public static class BuilderImpl implements Builder {
        private final List<class_2561> descriptionLines = new ArrayList<>();
        private CompletableFuture<Optional<ImageRenderer>> image = CompletableFuture.completedFuture(Optional.empty());
        private boolean imageUnset = true;

        @Override
        public Builder text(class_2561... description) {
            this.descriptionLines.addAll(Arrays.asList(description));
            return this;
        }

        @Override
        public Builder text(Collection<? extends class_2561> lines) {
            this.descriptionLines.addAll(lines);
            return this;
        }

        @Override
        public Builder image(class_2960 image, int width, int height) {
            Validate.isTrue(imageUnset, "Image already set!");
            Validate.isTrue(width > 0, "Width must be greater than 0!");
            Validate.isTrue(height > 0, "Height must be greater than 0!");

            this.image = ImageRendererManager.registerOrGetImage(image, () -> ResourceTextureImage.createFactory(image, 0, 0, width, height, width, height)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder image(class_2960 image, float u, float v, int width, int height, int textureWidth, int textureHeight) {
            Validate.isTrue(imageUnset, "Image already set!");
            Validate.isTrue(width > 0, "Width must be greater than 0!");
            Validate.isTrue(height > 0, "Height must be greater than 0!");

            this.image = ImageRendererManager.registerOrGetImage(image, () -> ResourceTextureImage.createFactory(image, u, v, width, height, textureWidth, textureHeight)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder image(Path path, class_2960 uniqueLocation) {
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = ImageRendererManager.registerOrGetImage(uniqueLocation, () -> DynamicTextureImage.fromPath(path, uniqueLocation, DebugProperties.IMAGE_FILTERING)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder gifImage(class_2960 image) {
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = ImageRendererManager.registerOrGetImage(image, () -> AnimatedDynamicTextureImage.createGIFFromTexture(image)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder gifImage(Path path, class_2960 uniqueLocation) {
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = ImageRendererManager.registerOrGetImage(uniqueLocation, () -> AnimatedDynamicTextureImage.createGIFFromPath(path, uniqueLocation)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder webpImage(class_2960 image) {
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = ImageRendererManager.registerOrGetImage(image, () -> AnimatedDynamicTextureImage.createWEBPFromTexture(image)).thenApply(Optional::of);

            imageUnset = false;
            return this;
        }

        @Override
        public Builder webpImage(Path path, class_2960 uniqueLocation) {
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = ImageRendererManager.registerOrGetImage(uniqueLocation, () -> AnimatedDynamicTextureImage.createWEBPFromPath(path, uniqueLocation)).thenApply(Optional::of);
            imageUnset = false;
            return this;
        }

        @Override
        public Builder customImage(CompletableFuture<Optional<ImageRenderer>> image) {
            Validate.notNull(image, "Image cannot be null!");
            Validate.isTrue(imageUnset, "Image already set!");

            this.image = image;
            this.imageUnset = false;
            return this;
        }

        @Override
        public OptionDescription build() {
            class_5250 concatenatedDescription = class_2561.method_43473();
            Iterator<class_2561> iter = descriptionLines.iterator();
            while (iter.hasNext()) {
                concatenatedDescription.method_10852(iter.next());
                if (iter.hasNext()) concatenatedDescription.method_27693("\n");
            }

            return new OptionDescriptionImpl(concatenatedDescription, image);
        }
    }
}
