package dev.isxander.yacl3.impl;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.impl.utils.YACLConstants;
import org.apache.commons.lang3.Validate;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_5244;
import net.minecraft.class_5250;

@ApiStatus.Internal
public final class ConfigCategoryImpl implements ConfigCategory {
    private final class_2561 name;
    private final ImmutableList<OptionGroup> groups;
    private final class_2561 tooltip;

    public ConfigCategoryImpl(class_2561 name, ImmutableList<OptionGroup> groups, class_2561 tooltip) {
        this.name = name;
        this.groups = groups;
        this.tooltip = tooltip;
    }

    @Override
    public @NotNull class_2561 name() {
        return name;
    }

    @Override
    public @NotNull ImmutableList<OptionGroup> groups() {
        return groups;
    }

    @Override
    public @NotNull class_2561 tooltip() {
        return tooltip;
    }

    @ApiStatus.Internal
    public static final class BuilderImpl implements Builder {
        private class_2561 name;

        private final List<Option<?>> rootOptions = new ArrayList<>();
        private final RootGroupBuilder rootGroupBuilder = new RootGroupBuilder();

        private final List<OptionGroup> groups = new ArrayList<>();

        private final List<class_2561> tooltipLines = new ArrayList<>();

        @Override
        public Builder name(@NotNull class_2561 name) {
            Validate.notNull(name, "`name` cannot be null");

            this.name = name;
            return this;
        }

        @Override
        public Builder option(@NotNull Option<?> option) {
            Validate.notNull(option, "`option` must not be null");

            if (option instanceof ListOption<?> listOption) {
                YACLConstants.LOGGER.warn("Adding list option as an option is not supported! Rerouting to group!");
                return group(listOption);
            }

            this.rootOptions.add(option);
            return this;
        }

        @Override
        public Builder options(@NotNull Collection<? extends Option<?>> options) {
            Validate.notNull(options, "`options` must not be null");

            if (options.stream().anyMatch(ListOption.class::isInstance))
                throw new UnsupportedOperationException("List options must not be added as an option but a group!");

            this.rootOptions.addAll(options);
            return this;
        }

        @Override
        public Builder group(@NotNull OptionGroup group) {
            Validate.notNull(group, "`group` must not be null");

            this.groups.add(group);
            return this;
        }

        @Override
        public Builder groups(@NotNull Collection<OptionGroup> groups) {
            Validate.notEmpty(groups, "`groups` must not be empty");

            this.groups.addAll(groups);
            return this;
        }

        @Override
        public Builder tooltip(@NotNull class_2561... tooltips) {
            Validate.notEmpty(tooltips, "`tooltips` cannot be empty");

            tooltipLines.addAll(List.of(tooltips));
            return this;
        }

        @Override
        public OptionGroup.Builder rootGroupBuilder() {
            return rootGroupBuilder;
        }

        @Override
        public ConfigCategory build() {
            Validate.notNull(name, "`name` must not be null to build `ConfigCategory`");

            List<OptionGroup> combinedGroups = new ArrayList<>();
            combinedGroups.add(new OptionGroupImpl(class_5244.field_39003, OptionDescription.EMPTY, ImmutableList.copyOf(rootOptions), false, true));
            combinedGroups.addAll(groups);

            Validate.notEmpty(combinedGroups, "at least one option must be added to build `ConfigCategory`");

            class_5250 concatenatedTooltip = class_2561.method_43473();
            boolean first = true;
            for (class_2561 line : tooltipLines) {
                if (line.method_10851() == class_5244.field_39003.method_10851())
                    continue;

                if (!first) concatenatedTooltip.method_27693("\n");
                first = false;

                concatenatedTooltip.method_10852(line);
            }

            return new ConfigCategoryImpl(name, ImmutableList.copyOf(combinedGroups), concatenatedTooltip);
        }

        private class RootGroupBuilder implements OptionGroup.Builder {
            @Override
            public OptionGroup.Builder name(@NotNull class_2561 name) {
                throw new UnsupportedOperationException("Cannot set name of root group!");
            }

            @Override
            public OptionGroup.Builder description(@NotNull OptionDescription description) {
                throw new UnsupportedOperationException("Cannot set name of root group!");
            }

            @Override
            public OptionGroup.Builder option(@NotNull Option<?> option) {
                ConfigCategoryImpl.BuilderImpl.this.option(option);
                return this;
            }

            @Override
            public OptionGroup.Builder options(@NotNull Collection<? extends Option<?>> options) {
                ConfigCategoryImpl.BuilderImpl.this.options(options);
                return this;
            }

            @Override
            public OptionGroup.Builder collapsed(boolean collapsible) {
                throw new UnsupportedOperationException("Cannot set collapsible of root group!");
            }

            @Override
            public OptionGroup build() {
                throw new UnsupportedOperationException("Cannot build root group!");
            }
        }
    }
}
