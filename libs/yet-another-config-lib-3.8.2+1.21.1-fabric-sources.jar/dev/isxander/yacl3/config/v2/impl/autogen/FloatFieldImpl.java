package dev.isxander.yacl3.config.v2.impl.autogen;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ControllerBuilder;
import dev.isxander.yacl3.api.controller.FloatFieldControllerBuilder;
import dev.isxander.yacl3.config.v2.api.ConfigField;
import dev.isxander.yacl3.config.v2.api.autogen.FloatField;
import dev.isxander.yacl3.config.v2.api.autogen.OptionAccess;
import dev.isxander.yacl3.config.v2.api.autogen.SimpleOptionFactory;
import net.minecraft.class_2477;
import net.minecraft.class_2561;

public class FloatFieldImpl extends SimpleOptionFactory<FloatField, Float> {
    @Override
    protected ControllerBuilder<Float> createController(FloatField annotation, ConfigField<Float> field, OptionAccess storage, Option<Float> option) {
        return FloatFieldControllerBuilder.create(option)
                .formatValue(v -> {
                    String key = null;
                    if (v == annotation.min())
                        key = getTranslationKey(field, "fmt.min");
                    else if (v == annotation.max())
                        key = getTranslationKey(field, "fmt.max");
                    if (key != null && class_2477.method_10517().method_4678(key))
                        return class_2561.method_43471(key);
                    key = getTranslationKey(field, "fmt");
                    if (class_2477.method_10517().method_4678(key))
                        return class_2561.method_43469(key, v);
                    return class_2561.method_43471(String.format(annotation.format(), v));
                })
                .range(annotation.min(), annotation.max());
    }
}
