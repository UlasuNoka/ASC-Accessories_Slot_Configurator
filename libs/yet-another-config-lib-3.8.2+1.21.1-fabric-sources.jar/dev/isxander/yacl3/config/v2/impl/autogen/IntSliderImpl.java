package dev.isxander.yacl3.config.v2.impl.autogen;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ControllerBuilder;
import dev.isxander.yacl3.api.controller.IntegerSliderControllerBuilder;
import dev.isxander.yacl3.config.v2.api.ConfigField;
import dev.isxander.yacl3.config.v2.api.autogen.SimpleOptionFactory;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import dev.isxander.yacl3.config.v2.api.autogen.IntSlider;
import dev.isxander.yacl3.config.v2.api.autogen.OptionAccess;

public class IntSliderImpl extends SimpleOptionFactory<IntSlider, Integer> {
    @Override
    protected ControllerBuilder<Integer> createController(IntSlider annotation, ConfigField<Integer> field, OptionAccess storage, Option<Integer> option) {
        return IntegerSliderControllerBuilder.create(option)
                .formatValue(v -> {
                    String key = getTranslationKey(field, "fmt." + v);
                    if (class_2477.method_10517().method_4678(key))
                        return class_2561.method_43471(key);
                    key = getTranslationKey(field, "fmt");
                    if (class_2477.method_10517().method_4678(key))
                        return class_2561.method_43469(key, v);
                    return class_2561.method_43470(Integer.toString(v));
                })
                .range(annotation.min(), annotation.max())
                .step(annotation.step());
    }
}
