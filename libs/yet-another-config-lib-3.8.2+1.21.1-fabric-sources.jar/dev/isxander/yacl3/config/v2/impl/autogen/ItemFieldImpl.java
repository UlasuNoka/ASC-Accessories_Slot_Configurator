package dev.isxander.yacl3.config.v2.impl.autogen;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ControllerBuilder;
import dev.isxander.yacl3.api.controller.ItemControllerBuilder;
import dev.isxander.yacl3.config.v2.api.ConfigField;
import dev.isxander.yacl3.config.v2.api.autogen.ItemField;
import dev.isxander.yacl3.config.v2.api.autogen.OptionAccess;
import dev.isxander.yacl3.config.v2.api.autogen.SimpleOptionFactory;
import net.minecraft.class_1792;

public class ItemFieldImpl extends SimpleOptionFactory<ItemField, class_1792> {
	@Override
	protected ControllerBuilder<class_1792> createController(ItemField annotation, ConfigField<class_1792> field, OptionAccess storage, Option<class_1792> option) {
		return ItemControllerBuilder.create(option);
	}
}
