package io.wispforest.accessories.commands;

import I;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.LiteralMessage;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.client.rendering.CustomDataRenderer;
import io.wispforest.accessories.api.components.*;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.data.CustomRendererLoader;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2178;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2287;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7157;
import net.minecraft.class_9334;

public class AccessoriesCommands {

    public static final SimpleCommandExceptionType NON_LIVING_ENTITY_TARGET = new SimpleCommandExceptionType(class_2561.method_43471("argument.livingEntities.nonLiving"));

    public static final SimpleCommandExceptionType INVALID_SLOT_TYPE = new SimpleCommandExceptionType(new LiteralMessage("Invalid Slot Type"));

    public static final Logger LOGGER = LogUtils.getLogger();

    public static void registerCommandArgTypes() {
        AccessoriesInternals.registerCommandArgumentType(Accessories.of("slot_type"), SlotArgumentType.class, RecordArgumentTypeInfo.of(ctx -> SlotArgumentType.INSTANCE));
        AccessoriesInternals.registerCommandArgumentType(Accessories.of("resource"), ResourceExtendedArgument.class, RecordArgumentTypeInfo.of(ResourceExtendedArgument::attributes));
    }

    public static class_1309 getOrThrowLivingEntity(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        var entity = class_2186.method_9313(ctx, "entity");

        if(!(entity instanceof class_1309 livingEntity)) {
            throw NON_LIVING_ENTITY_TARGET.create();
        }

        return livingEntity;
    }

    //accessories edit {}
    public static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        var base = class_2170.method_9247("accessories")
                .requires(commandSourceStack -> commandSourceStack.method_9259(class_2170.field_31839));

        if (Accessories.DEBUG) {
            base.then(
                    class_2170.method_9247("create-renderer-stack")
                            .then(
                                    class_2170.method_9244("custom_name", class_2178.method_9281(context))
                                            .then(
                                                    class_2170.method_9244("renderer_id", class_2232.method_9441())
                                                            .then(
                                                                    class_2170.method_9244("item_model_id", class_2232.method_9441())
                                                                            .then(
                                                                                    class_2170.method_9244("is_bundle", BoolArgumentType.bool())
                                                                                            .executes(AccessoriesCommands::createRenderStack)
                                                                            )
                                                                            .executes(AccessoriesCommands::createRenderStack)
                                                            )
                                            )
                            )
            ).then(
                    class_2170.method_9247("listen-to-renderer")
                            .then(
                                    class_2170.method_9244("id", class_2232.method_9441())
                                            .executes(ctx -> {
                                                var id = ctx.getArgument("id", class_2960.class);

                                                CustomRendererLoader.constantFileResolving(ctx.getSource().method_9211(), id);

                                                return 1;
                                            })
                            )
                            .executes(ctx -> {
                                CustomRendererLoader.constantFileResolving(ctx.getSource().method_9211(), null);

                                return 1;
                            })

            );
        }

        dispatcher.register(
                base
                        .then(
                                class_2170.method_9247("edit")
                                        .then(
                                                class_2170.method_9244("entity", class_2186.method_9309())
                                                        .executes((ctx) -> {
                                                            Accessories.askPlayerForVariant(ctx.getSource().method_9207(), getOrThrowLivingEntity(ctx));

                                                            return 1;
                                                        })
                                        )
                                        .executes(ctx -> {
                                            Accessories.askPlayerForVariant(ctx.getSource().method_9207());


                                            return 1;
                                        })
                        )
                        .then(
                                class_2170.method_9247("nest")
                                        .then(
                                                class_2170.method_9244("item", class_2287.method_9776(context))
                                                        .executes((ctx) -> {
                                                            var player = ctx.getSource().method_9207();

                                                            var stack = player.method_6047();

                                                            var innerStack = class_2287.method_9777(ctx, "item").method_9781(1, false);

                                                            stack.method_57368(
                                                                    AccessoriesDataComponents.NESTED_ACCESSORIES,
                                                                    AccessoryNestContainerContents.EMPTY,
                                                                    data -> data.addStack(innerStack));

                                                            return 1;
                                                        })
                                        )
                        )
                        .then(
                                class_2170.method_9247("slot")
                                        .then(
                                                class_2170.method_9247("add")
                                                        .then(
                                                                class_2170.method_9247("valid")
                                                                        .then(class_2170.method_9244("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(0, ctx.getSource().method_9207(), ctx))
                                                                        ))
                                                        .then(
                                                                class_2170.method_9247("invalid")
                                                                        .then(class_2170.method_9244("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(1, ctx.getSource().method_9207(), ctx))
                                                                        ))

                                        ).then(
                                                class_2170.method_9247("remove")
                                                        .then(
                                                                class_2170.method_9247("valid")
                                                                        .then(class_2170.method_9244("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(2, ctx.getSource().method_9207(), ctx))
                                                                        ))
                                                        .then(
                                                                class_2170.method_9247("invalid")
                                                                        .then(class_2170.method_9244("slot", SlotArgumentType.INSTANCE)
                                                                                .executes(ctx -> adjustSlotValidationOnStack(3, ctx.getSource().method_9207(), ctx))
                                                                        ))
                                        )
                        )
                        .then(
                                class_2170.method_9247("stack-sizing")
                                        .then(
                                                class_2170.method_9247("useStackSize")
                                                        .then(
                                                                class_2170.method_9244("value", BoolArgumentType.bool())
                                                                        .executes(ctx -> {
                                                                            var player = ctx.getSource().method_9207();

                                                                            var bl = ctx.getArgument("value", Boolean.class);

                                                                            player.method_6047().method_57368(AccessoriesDataComponents.STACK_SIZE,
                                                                                    AccessoryStackSizeComponent.DEFAULT,
                                                                                    component -> component.useStackSize(bl));

                                                                            return 1;
                                                                        })
                                                        )
                                        ).then(
                                                class_2170.method_9244("value", IntegerArgumentType.integer())
                                                        .executes(ctx -> {
                                                            var player = ctx.getSource().method_9207();

                                                            var size = ctx.getArgument("value", Integer.class);

                                                            player.method_6047().method_57368(AccessoriesDataComponents.STACK_SIZE,
                                                                    AccessoryStackSizeComponent.DEFAULT,
                                                                    component -> component.sizeOverride(size));

                                                            return 1;
                                                        })
                                        )
                        )
                        .then(
                                class_2170.method_9247("attribute")
                                        .then(
                                                class_2170.method_9247("modifier")
                                                        .then(
                                                                class_2170.method_9247("add")
                                                                        .then(
                                                                                class_2170.method_9244("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                class_2170.method_9244("id", class_2232.method_9441())
                                                                                                        .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg())
                                                                                                                        .then(createAddLiteral("add_value"))
                                                                                                                        .then(createAddLiteral("add_multiplied_base"))
                                                                                                                        .then(createAddLiteral("add_multiplied_total"))
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                                        .then(
                                                                class_2170.method_9247("remove")
                                                                        .then(
                                                                                class_2170.method_9244("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                class_2170.method_9244("id", class_2232.method_9441())
                                                                                                        .executes(
                                                                                                                ctx -> removeModifier(
                                                                                                                        ctx.getSource(),
                                                                                                                        ctx.getSource().method_9207(),
                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                        class_2232.method_9443(ctx, "id")
                                                                                                                )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                                        .then(
                                                                class_2170.method_9247("get")
                                                                        .then(
                                                                                class_2170.method_9244("attribute", ResourceExtendedArgument.attributes(context))
                                                                                        .then(
                                                                                                class_2170.method_9244("id", class_2232.method_9441())
                                                                                                        .executes(
                                                                                                                ctx -> getAttributeModifier(
                                                                                                                        ctx.getSource(),
                                                                                                                        ctx.getSource().method_9207(),
                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                        class_2232.method_9443(ctx, "id"),
                                                                                                                        1.0
                                                                                                                )
                                                                                                        )
                                                                                                        .then(
                                                                                                                class_2170.method_9244("scale", DoubleArgumentType.doubleArg())
                                                                                                                        .executes(
                                                                                                                                ctx -> getAttributeModifier(
                                                                                                                                        ctx.getSource(),
                                                                                                                                        ctx.getSource().method_9207(),
                                                                                                                                        ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                                                                                        class_2232.method_9443(ctx, "id"),
                                                                                                                                        DoubleArgumentType.getDouble(ctx, "scale")
                                                                                                                                )
                                                                                                                        )
                                                                                                        )
                                                                                        )
                                                                        )
                                                        )
                                        )
                        ).then(
                                class_2170.method_9247("log")
                                        .then(
                                                class_2170.method_9247("slots")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Slots registered:");

                                                            for (var slotType : SlotTypeLoader.getSlotTypes(ctx.getSource().method_9225()).values()) {
                                                                LOGGER.info(slotType.toString());
                                                            }

                                                            return 1;
                                                        })
                                        )
                                        .then(
                                                class_2170.method_9247("groups")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Slot Groups registered:");

                                                            for (var group : SlotGroupLoader.getGroups(ctx.getSource().method_9225())) {
                                                                LOGGER.info(group.toString());
                                                            }

                                                            return 1;
                                                        })
                                        )
                                        .then(
                                                class_2170.method_9247("entity_bindings")
                                                        .executes(ctx -> {
                                                            LOGGER.info("All given Entity Bindings registered:");

                                                            EntitySlotLoader.INSTANCE.getEntitySlotData(false).forEach((type, slots) -> {
                                                                LOGGER.info("[{}]: {}", type, slots.keySet());
                                                            });

                                                            return 1;
                                                        })
                                        )
                        )
        );
    }

    private static LiteralArgumentBuilder<class_2168> createAddLiteral(String literal) {
        var selectedValue = Arrays.stream(class_1322.class_1323.values())
                .filter(value -> value.method_15434().equals(literal))
                .findFirst()
                .orElse(null);

        if(selectedValue == null) throw new IllegalStateException("Unable to handle the given literal as its not a valid AttributeModifier Operation! [Literal: " + literal + "]");

        return class_2170.method_9247(literal)
                .then(
                        class_2170.method_9244("slot", SlotArgumentType.INSTANCE)
                                .then(
                                        class_2170.method_9244("isStackable", BoolArgumentType.bool())
                                                .executes(
                                                        ctx -> addModifier(
                                                                ctx.getSource(),
                                                                ctx.getSource().method_9207(),
                                                                ResourceExtendedArgument.getAttribute(ctx, "attribute"),
                                                                class_2232.method_9443(ctx, "id"),
                                                                DoubleArgumentType.getDouble(ctx, "value"),
                                                                selectedValue,
                                                                SlotArgumentType.getSlot(ctx, "slot"),
                                                                BoolArgumentType.getBool(ctx, "isStackable")
                                                        )
                                                )
                                )
                );
    }

    private static int getAttributeModifier(class_2168 commandSourceStack, class_1309 livingEntity, class_6880<class_1320> holder, class_2960 resourceLocation, double d) throws CommandSyntaxException {
        var stack = livingEntity.method_6047();

        var component = stack.method_57825(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY);

        var modifier = component.getModifier(holder, resourceLocation);

        if (modifier == null) {
            throw ERROR_NO_SUCH_MODIFIER.create(stack.method_7954(), getAttributeDescription(holder), resourceLocation);
        }

        double e = modifier.comp_2449();

        commandSourceStack.method_9226(
                () -> class_2561.method_43469(
                        "commands.attribute.modifier.value.get.success_itemstack", class_2561.method_54154(resourceLocation), getAttributeDescription(holder), stack.method_7954(), e
                ),
                false
        );

        return (int)(e * d);
    }

    private static final Dynamic3CommandExceptionType ERROR_MODIFIER_ALREADY_PRESENT = new Dynamic3CommandExceptionType(
            (var1, var2, var3) -> class_2561.method_54159("commands.attribute.failed.modifier_already_present_itemstack", var1, var2, var3)
    );

    private static int addModifier(class_2168 commandSourceStack, class_1309 livingEntity, class_6880<class_1320> holder, class_2960 resourceLocation, double d, class_1322.class_1323 operation, String slotName, boolean isStackable) throws CommandSyntaxException {
        var stack = livingEntity.method_6047();

        var component = stack.method_57825(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY);

        if (component.hasModifier(holder, resourceLocation)) {
            throw ERROR_MODIFIER_ALREADY_PRESENT.create(resourceLocation, getAttributeDescription(holder), stack.method_7954());
        }

        stack.method_57379(AccessoriesDataComponents.ATTRIBUTES, component.withModifierAdded(holder, new class_1322(resourceLocation, d, operation), slotName, isStackable));

        commandSourceStack.method_9226(
                () -> class_2561.method_43469(
                        "commands.attribute.modifier.add.success_itemstack", class_2561.method_54154(resourceLocation), getAttributeDescription(holder), stack.method_7954()
                ),
                false
        );

        return 1;
    }

    private static final Dynamic3CommandExceptionType ERROR_NO_SUCH_MODIFIER = new Dynamic3CommandExceptionType(
            (var1, var2, var3) -> class_2561.method_54159("commands.attribute.failed.no_modifier_itemstack", var1, var2, var3)
    );

    private static int removeModifier(class_2168 commandSourceStack, class_1309 livingEntity, class_6880<class_1320> holder, class_2960 location) throws CommandSyntaxException {
        MutableBoolean removedModifier = new MutableBoolean(false);

        var stack = livingEntity.method_6047();

        stack.method_57368(AccessoriesDataComponents.ATTRIBUTES, AccessoryItemAttributeModifiers.EMPTY, component -> {
            var size = component.modifiers().size();

            component = component.withoutModifier(holder, location);

            if(size != component.modifiers().size()) removedModifier.setTrue();

            return component;
        });

        if(!removedModifier.getValue()) {
            throw ERROR_NO_SUCH_MODIFIER.create(location, getAttributeDescription(holder), stack.method_7954());
        }

        commandSourceStack.method_9226(
                () -> class_2561.method_43469(
                        "commands.attribute.modifier.remove.success_itemstack", class_2561.method_54154(location), getAttributeDescription(holder), stack.method_7954()
                ),
                false
        );

        return 1;
    }

    private static class_2561 getAttributeDescription(class_6880<class_1320> attribute) {
        return class_2561.method_43471(attribute.comp_349().method_26830());
    }

    private static int adjustSlotValidationOnStack(int operation, class_1309 player, CommandContext<class_2168> ctx) {
        var slotName = SlotArgumentType.getSlot(ctx, "slot");

        player.method_6047().method_57368(AccessoriesDataComponents.SLOT_VALIDATION, AccessorySlotValidationComponent.EMPTY, component -> {
            return switch (operation) {
                case 0 -> component.addValidSlot(slotName);
                case 1 -> component.addInvalidSlot(slotName);
                case 2 -> component.removeValidSlot(slotName);
                case 3 -> component.removeInvalidSlot(slotName);
                default -> throw new IllegalStateException("Unexpected value: " + operation);
            };
        });

        return 1;
    }

    private static int createRenderStack(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        var rendererId = ctx.getArgument("renderer_id", class_2960.class);
        var modelId = ctx.getArgument("item_model_id", class_2960.class);
        var component = class_2178.method_9280(ctx, "custom_name");

        class_1792 item = class_1802.field_8600;

        try {
            if (ctx.getArgument("is_bundle", Boolean.class)) item = class_1802.field_27023;
        } catch (Throwable ignored) {}

        var itemStack = item.method_7854();

        itemStack.method_57379(class_9334.field_50239, component);

        itemStack.method_57379(
                AccessoriesDataComponents.CUSTOM_RENDERER,
                new AccessoryCustomRendererComponent(List.of(
                        new CustomDataRenderer(rendererId, Map.of(), List.of(), null)))
        );

        itemStack.method_57379(
                AccessoriesDataComponents.ITEM_MODEL_OVERRIDE,
                new AccessoryItemCosmeticOverride(modelId)
        );

        itemStack.method_57379(
                AccessoriesDataComponents.SLOT_VALIDATION,
                new AccessorySlotValidationComponent(Set.of("any"), Set.of())
        );

        ctx.getSource().method_9207()
                .method_7270(itemStack);

        return 1;
    }

}
