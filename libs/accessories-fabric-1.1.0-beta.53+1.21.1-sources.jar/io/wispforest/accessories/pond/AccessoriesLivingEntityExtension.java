package io.wispforest.accessories.pond;

import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.class_1799;

public interface AccessoriesLivingEntityExtension {
    void onEquipItem(SlotReference slotReference, class_1799 oldItem, class_1799 newItem);
}
