package io.wispforest.accessories.pond;

import net.minecraft.class_630;
import org.jetbrains.annotations.Nullable;

public interface ModelPartLoadingHelper {
    default void accessories$pushRoot(class_630 root) {
        throw new IllegalStateException("Interface Method not overridden!");
    }

    @Nullable
    default class_630 accessories$pollRoot() {
        throw new IllegalStateException("Interface Method not overridden!");
    }

    default void accessories$clearQueue() {
        throw new IllegalStateException("Interface Method not overridden!");
    }
}
