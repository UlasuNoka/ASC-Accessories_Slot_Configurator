package io.wispforest.accessories.pond;

import io.wispforest.accessories.menu.ArmorSlotTypes;
import java.util.function.Consumer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface CosmeticArmorLookupTogglable {
    default void setLookupToggle(boolean value) {
        throw new IllegalStateException("Interface injected method not implemented!");
    }

    default boolean getLookupToggle() {
        throw new IllegalStateException("Interface injected method not implemented!");
    }

    static void getAlternativeStack(class_1309 livingEntity, class_1304 equipmentSlot, Consumer<class_1799> consumer) {
        if(!((CosmeticArmorLookupTogglable)livingEntity).getLookupToggle()) return;

        var cosmetic = ArmorSlotTypes.getAlternativeStack(livingEntity, equipmentSlot);

        if(cosmetic == null) return;

        consumer.accept(cosmetic);
    }
}
