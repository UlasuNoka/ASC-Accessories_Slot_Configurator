package io.wispforest.accessories.pond;

import io.wispforest.accessories.mixin.client.ModelPartAccessor;
import org.jetbrains.annotations.Nullable;
import java.util.Map.Entry;
import java.util.Optional;
import net.minecraft.class_630;

public interface ModelRootAccess {
    @Nullable
    default class_630 accessories$rootPart(){
        throw new IllegalStateException("Interface Method not overridden!");
    }

    default Optional<class_630> accessories$getAnyDescendantWithName(String name) {
        var root = accessories$rootPart();

        if (root == null) return Optional.empty();
        if (name.equals("root")) return Optional.of(root);

        return accessories$getAnyDescendantWithName(root, name);
    }

    private static Optional<class_630> accessories$getAnyDescendantWithName(class_630 part, String name) {
        for (var entry : ((ModelPartAccessor) (Object) part).getChildren().entrySet()) {
            var childName = entry.getKey();
            var childPart = entry.getValue();

            if (childName.equals(name)) return Optional.of(childPart);

            var result = accessories$getAnyDescendantWithName(childPart, name);

            if (result.isPresent()) return result;
        }

        return Optional.empty();
    }
}
