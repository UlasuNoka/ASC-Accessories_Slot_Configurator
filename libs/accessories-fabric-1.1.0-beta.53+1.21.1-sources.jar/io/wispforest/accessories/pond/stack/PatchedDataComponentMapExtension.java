package io.wispforest.accessories.pond.stack;

import io.wispforest.accessories.utils.ItemStackMutation;
import io.wispforest.owo.util.EventStream;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_1799;

public interface PatchedDataComponentMapExtension {
    boolean accessories$hasChanged();

    EventStream<ItemStackMutation> accessories$getMutationEvent(class_1799 stack);
}
