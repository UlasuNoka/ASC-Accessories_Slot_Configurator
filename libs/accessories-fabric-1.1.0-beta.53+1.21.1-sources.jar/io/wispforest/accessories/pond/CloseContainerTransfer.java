package io.wispforest.accessories.pond;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public interface CloseContainerTransfer {
    void accessories$setScreenTransfer(class_437 screen);
}
