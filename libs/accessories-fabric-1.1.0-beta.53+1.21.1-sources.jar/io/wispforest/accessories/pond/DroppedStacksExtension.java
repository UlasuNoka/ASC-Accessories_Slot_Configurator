package io.wispforest.accessories.pond;

import java.util.Collection;
import net.minecraft.class_1799;

public interface DroppedStacksExtension {
    void addToBeDroppedStacks(Collection<class_1799> list);

    Collection<class_1799> toBeDroppedStacks();
}
