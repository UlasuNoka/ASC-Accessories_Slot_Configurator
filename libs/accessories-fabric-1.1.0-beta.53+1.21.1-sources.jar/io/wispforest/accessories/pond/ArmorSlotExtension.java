package io.wispforest.accessories.pond;

import net.minecraft.class_2960;
import net.minecraft.class_9692;
import org.jetbrains.annotations.Nullable;

public interface ArmorSlotExtension {

    default class_9692 setAtlasLocation(class_2960 atlasLocation) {
        throw new IllegalStateException("Extension method not implemented!");
    }

    @Nullable
    default class_2960 getAtlasLocation(){
        throw new IllegalStateException("Extension method not implemented!");
    }
}
