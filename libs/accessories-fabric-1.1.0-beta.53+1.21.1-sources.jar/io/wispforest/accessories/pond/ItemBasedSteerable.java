package io.wispforest.accessories.pond;

import net.minecraft.class_4980;
import net.minecraft.class_5146;

public interface ItemBasedSteerable extends class_5146 {
    class_4980 getInstance();
}
