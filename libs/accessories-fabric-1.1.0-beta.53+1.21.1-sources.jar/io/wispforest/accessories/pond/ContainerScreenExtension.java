package io.wispforest.accessories.pond;

import net.minecraft.class_1735;
import net.minecraft.class_332;
import org.jetbrains.annotations.Nullable;

public interface ContainerScreenExtension {

    @Nullable
    default Boolean isHovering_Logical(class_1735 slot, double mouseX, double mouseY) {
        return null;
    }

    @Nullable
    default Boolean isHovering_Rendering(class_1735 slot, double mouseX, double mouseY) {
        return null;
    }

    @Nullable
    default Boolean shouldRenderSlot(class_1735 slot) {
        return null;
    }

    default void forceRenderSlot(class_332 context, class_1735 slot) {
        throw new IllegalStateException("Interface injected method not implemented!");
    }

    default int hoverStackOffset() {
        return 0;
    }
}
