package io.wispforest.accessories.networking.holder;

import io.wispforest.accessories.client.gui.AccessoriesScreenBase;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.endec.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import java.util.function.Function;

public record SyncHolderChange(HolderProperty<?> property, Object data) {

    public static final StructEndec<SyncHolderChange> ENDEC = new StructEndec<>() {
        @Override
        public void encodeStruct(SerializationContext ctx, Serializer<?> serializer, Serializer.Struct struct, SyncHolderChange value) {
            struct.field("property", ctx, HolderProperty.ENDEC, value.property());
            struct.field("value", ctx, (Endec) value.property().endec(), value.data());
        }

        @Override
        public SyncHolderChange decodeStruct(SerializationContext ctx, Deserializer<?> deserializer, Deserializer.Struct struct) {
            var prop = struct.field("property", ctx, HolderProperty.ENDEC);

            return new SyncHolderChange(prop, struct.field("value", ctx, prop.endec()));
        }
    };

    public static <T> SyncHolderChange of(HolderProperty<T> property, T data) {
        return new SyncHolderChange(property, data);
    }

    public static <T> SyncHolderChange of(HolderProperty<T> property, class_1657 player, Function<T, T> operation) {
        return new SyncHolderChange(property, operation.apply(property.getter().apply(player.accessoriesHolder())));
    }

    public static void handlePacket(SyncHolderChange packet, class_1657 player) {
        packet.property().setData(player, packet.data());

        if(player.method_37908().method_8608()) {
            handleClient(packet, player);
        } else {
            AccessoriesNetworking.sendToPlayer((class_3222) player, SyncHolderChange.of((HolderProperty<Object>) packet.property(), (Object) packet.property().getter().apply(player.accessoriesHolder())));
        }
    }

    @Environment(EnvType.CLIENT)
    public static void handleClient(SyncHolderChange packet, class_1657 player) {
        if(class_310.method_1551().field_1755 instanceof AccessoriesScreenBase accessoriesScreen) {
            accessoriesScreen.onHolderChange(packet.property().name());
        }
    }
}