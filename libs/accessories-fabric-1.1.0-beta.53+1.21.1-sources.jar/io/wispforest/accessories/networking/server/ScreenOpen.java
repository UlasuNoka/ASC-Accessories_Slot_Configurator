package io.wispforest.accessories.networking.server;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public record ScreenOpen(int entityId, boolean targetLookEntity, AccessoriesMenuVariant variant) {

    public static final StructEndec<ScreenOpen> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.fieldOf("entityId", ScreenOpen::entityId),
            Endec.BOOLEAN.fieldOf("targetLookEntity", ScreenOpen::targetLookEntity),
            Endec.forEnum(AccessoriesMenuVariant.class).fieldOf("screenType", ScreenOpen::variant),
            ScreenOpen::new
    );

    public static ScreenOpen of(@Nullable class_1309 livingEntity, AccessoriesMenuVariant variant){
        return new ScreenOpen(livingEntity != null ? livingEntity.method_5628() : -1, false, variant);
    }

    public static ScreenOpen of(boolean targetLookEntity, AccessoriesMenuVariant variant){
        return new ScreenOpen(-1, targetLookEntity, variant);
    }

    public static void handlePacket(ScreenOpen packet, class_1657 player) {
        class_1309 livingEntity = null;

        if(packet.entityId() != -1) {
            var entity = player.method_37908().method_8469(packet.entityId());

            if(entity instanceof class_1309 living) livingEntity = living;
        } else if(packet.targetLookEntity()) {
            Accessories.attemptOpenScreenPlayer((class_3222) player, packet.variant());

            return;
        }

        class_1799 carriedStack = null;

        if(player.field_7512 instanceof class_1703 oldMenu) {
            var currentCarriedStack = oldMenu.method_34255();

            if(!currentCarriedStack.method_7960()) {
                carriedStack = currentCarriedStack;

                oldMenu.method_34254(class_1799.field_8037);
            }
        }

        Accessories.openAccessoriesMenu(player, packet.variant(), livingEntity, carriedStack);
    }
}