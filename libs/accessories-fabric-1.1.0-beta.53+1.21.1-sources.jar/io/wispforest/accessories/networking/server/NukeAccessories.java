package io.wispforest.accessories.networking.server;

import com.mojang.logging.LogUtils;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.endec.StructEndec;
import net.minecraft.class_1657;
import org.slf4j.Logger;

public record NukeAccessories() {

    public static final StructEndec<NukeAccessories> ENDEC = StructEndec.unit(new NukeAccessories());

    private static final Logger LOGGER = LogUtils.getLogger();

    public static void handlePacket(NukeAccessories packet, class_1657 player) {
        // Only players in creative should be able to nuke their accessories
        if (!player.method_31549().field_7477) {
            LOGGER.info("A given player sent a NukeAccessories packet not as a Creative Player: [Player: {}]", player.method_5477());

            return;
        }

        var cap = player.accessoriesCapability();

        if (cap != null) {
            cap.reset(false);

            player.field_7512.method_7623();
        }
    }
}