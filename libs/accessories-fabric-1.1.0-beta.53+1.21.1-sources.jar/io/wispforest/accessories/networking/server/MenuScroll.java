package io.wispforest.accessories.networking.server;

import io.wispforest.accessories.menu.variants.AccessoriesMenu;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

public record MenuScroll(int index, boolean smooth) {

    public static final StructEndec<MenuScroll> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.fieldOf("index", MenuScroll::index),
            Endec.BOOLEAN.fieldOf("smooth", MenuScroll::smooth),
            MenuScroll::new
    );

    public static void handlePacket(MenuScroll packet, class_1657 player) {
        if(player.field_7512 instanceof AccessoriesMenu menu && menu.scrollTo(packet.index(), packet.smooth()) && player instanceof class_3222 serverPlayer){
            AccessoriesNetworking.sendToPlayer(serverPlayer, new MenuScroll(packet.index(), packet.smooth()));
        }
    }
}
