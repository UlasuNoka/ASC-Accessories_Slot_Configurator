package io.wispforest.accessories.networking.client;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.client.gui.ScreenVariantSelectionScreen;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.ScreenOpen;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;

public record ScreenVariantPing(int entityId, boolean targetLookEntity) {

    public static final StructEndec<ScreenVariantPing> ENDEC = StructEndecBuilder.of(
            Endec.VAR_INT.fieldOf("entityId", ScreenVariantPing::entityId),
            Endec.BOOLEAN.fieldOf("targetLookEntity", ScreenVariantPing::targetLookEntity),
            ScreenVariantPing::new
    );

    public static ScreenVariantPing of(@Nullable class_1309 livingEntity){
        return new ScreenVariantPing(livingEntity != null ? livingEntity.method_5628() : -1, false);
    }

    public static ScreenVariantPing of(boolean targetLookEntity){
        return new ScreenVariantPing(-1, targetLookEntity);
    }

    @Environment(EnvType.CLIENT)
    public static void handlePacket(ScreenVariantPing packet, class_1657 player) {
        var selectedVariant = AccessoriesMenuVariant.getVariant(Accessories.config().screenOptions.selectedScreenType());

        Function<AccessoriesMenuVariant, ScreenOpen> packetBuilder = (menuVariant) -> {
            return new ScreenOpen(packet.targetLookEntity() ? -1 : packet.entityId(), packet.targetLookEntity(), menuVariant);
        };

        if(selectedVariant != null) {
            AccessoriesNetworking.sendToServer(packetBuilder.apply(selectedVariant));
        } else {
            class_310.method_1551().method_1507(new ScreenVariantSelectionScreen(variant -> {
                AccessoriesNetworking.sendToServer(packetBuilder.apply(variant));
            }));
        }
    }
}
