package io.wispforest.accessories.utils;

import io.wispforest.accessories.mixin.ItemStackAccessor;
import io.wispforest.accessories.pond.stack.PatchedDataComponentMapExtension;
import io.wispforest.owo.util.EventStream;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_1799;
import net.minecraft.class_9331;
import java.util.List;

public interface ItemStackMutation {

    static EventStream<ItemStackMutation> getEvent(class_1799 stack) {
        return ((PatchedDataComponentMapExtension) (Object) ((ItemStackAccessor) (Object) stack).accessories$components()).accessories$getMutationEvent(stack);
    }

    // TODO: MAYBE JUST MAKE THIS A SET?
    void onMutation(class_1799 stack, List<class_9331<?>> types);
}
