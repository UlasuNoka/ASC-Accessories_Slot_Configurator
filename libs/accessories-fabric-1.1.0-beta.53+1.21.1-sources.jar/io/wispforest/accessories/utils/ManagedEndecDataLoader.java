package io.wispforest.accessories.utils;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.gson.JsonElement;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.mixin.ConfigurableRegistryLookupAccessor;
import io.wispforest.endec.Endec;
import io.wispforest.endec.SerializationContext;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import io.wispforest.owo.network.ClientAccess;
import io.wispforest.owo.network.OwoNetChannel;
import io.wispforest.owo.serialization.RegistriesAttribute;
import io.wispforest.owo.serialization.endec.MinecraftEndecs;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5350;
import net.minecraft.class_5455;
import net.minecraft.class_7225;

public class ManagedEndecDataLoader<T> extends EndecDataLoader<T>  {

    private static final Map<class_2960, ManagedEndecDataLoader<?>> ALL_DATA_LOADERS = new LinkedHashMap<>();

    private final BiMap<class_2960, T> server = HashBiMap.create();
    private final BiMap<class_2960, T> client = HashBiMap.create();

    private final Endec<BiMap<class_2960, T>> mapEndec;

    private BiConsumer<class_2960, T> handleEntry = (location, t) -> {};

    protected ManagedEndecDataLoader(class_2960 id, String type, Endec<T> endec) {
        super(SerializationContext.empty(), id, type, endec);

        this.mapEndec = biMapEndec(class_2960::toString, class_2960::method_12829, endec);

        ALL_DATA_LOADERS.put(id, this);

        AccessoriesInternals.registerLoader(this, this::setupOps);
    }

    public static <T> ManagedEndecDataLoader<T> of(class_2960 id, String type, Endec<T> endec) {
        return of(id, type, endec);
    }

    public ManagedEndecDataLoader<T> onEntryAdd(BiConsumer<class_2960, T> value) {
        this.handleEntry = value;

        return this;
    }

    @Nullable
    public static <T> ManagedEndecDataLoader<T> getLoader(class_2960 id) {
        return (ManagedEndecDataLoader<T>) ALL_DATA_LOADERS.get(id);
    }

    @Override
    protected void handleRawEntry(class_2960 id, T t) {
        handleEntry.accept(id, t);

        server.put(id, t);
    }

    public Endec<BiMap<class_2960, T>> mapEndec() {
        return this.mapEndec;
    }

    private void handleUnsafeSync(BiMap<class_2960, ?> map) {
        this.client.clear();
        this.client.putAll((Map<? extends class_2960, ? extends T>) map);

        this.onSync();
    }

    protected void onSync() {}

    public Map<class_2960, T> getEntries(class_1937 level) {
        return getEntries(level.method_8608());
    }

    public Map<class_2960, T> getEntries(boolean isClientSide) {
        return Collections.unmodifiableMap(isClientSide ? client : server);
    }

    @Nullable
    public T getEntry(class_2960 id, class_1937 level) {
        return getEntry(id, level.method_8608());
    }

    @Nullable
    public T getEntry(class_2960 id, boolean isClientSide) {
        return (isClientSide ? client : server).get(id);
    }

    public class_2960 getId(T t, class_1937 level) {
        return getId(t, level.method_8608());
    }

    public class_2960 getId(T t, boolean isClientSide) {
        return (isClientSide ? client : server).inverse().get(t);
    }

    //--


    @Override
    protected void apply(Map<class_2960, JsonElement> loadedObjects, class_3300 resourceManager, class_3695 profiler) {
        this.server.clear();

        super.apply(loadedObjects, resourceManager, profiler);
    }

    @ApiStatus.Internal
    private ManagedEndecDataLoader<T> setupOps(class_7225.class_7874 registries) {
        if (registries instanceof class_5350.class_9180 lookup) {
            this.context = context.withAttributes(RegistriesAttribute.of(((ConfigurableRegistryLookupAccessor) lookup).getRegistryAccess()));
        } else {
            this.context = context.withAttributes(RegistriesAttribute.of((class_5455) registries));
        }

        return this;
    }

    @Override
    @ApiStatus.Internal
    protected Map<class_2960, JsonElement> method_20731(class_3300 resourceManager, class_3695 profiler) {
        if (!this.context.hasAttribute(RegistriesAttribute.REGISTRIES)) {
            throw new IllegalStateException("Unable to prepare files as the given Registry access has not been setup on the server! [Id: " + this.getLoaderId() + "]");
        }

        return super.method_20731(resourceManager, profiler);
    }

    @ApiStatus.Internal
    private static <K, V> Endec<BiMap<K, V>> biMapEndec(Function<K, String> keyToString, Function<String, K> stringToKey, Endec<V> valueEndec) {
        return Endec.of((ctx, serializer, map) -> {
            try (var mapState = serializer.map(ctx, valueEndec, map.size())) {
                map.forEach((k, v) -> mapState.entry(keyToString.apply(k), v));
            }
        }, (ctx, deserializer) -> {
            var mapState = deserializer.map(ctx, valueEndec);

            var map = HashBiMap.<K, V>create(mapState.estimatedSize());
            mapState.forEachRemaining(entry -> map.put(stringToKey.apply(entry.getKey()), entry.getValue()));

            return map;
        });
    }

    @ApiStatus.Internal
    public static void init(OwoNetChannel channel, Consumer<Consumer<class_1657>> hookRegistration) {
        channel.registerClientboundDeferred(SyncAllLoaderDataPacket.class, SyncAllLoaderDataPacket.ENDEC);

        hookRegistration.accept(player -> {
            var packets = ALL_DATA_LOADERS.values().stream()
                    .map(dataLoader -> new SyncLoaderDataPacket(dataLoader.id, (BiMap<class_2960, Object>) dataLoader.server))
                    .toList();

            channel.serverHandle(player).send(new SyncAllLoaderDataPacket(packets));
        });
    }

    @ApiStatus.Internal
    public static void initClient(OwoNetChannel channel) {
        channel.registerClientbound(SyncAllLoaderDataPacket.class, SyncAllLoaderDataPacket.ENDEC, SyncAllLoaderDataPacket::handle);
    }

    @ApiStatus.Internal
    private record SyncAllLoaderDataPacket(List<SyncLoaderDataPacket> packets) {
        private static final StructEndec<SyncAllLoaderDataPacket> ENDEC = StructEndecBuilder.of(
                SyncLoaderDataPacket.ENDEC.listOf().fieldOf("packets", SyncAllLoaderDataPacket::packets),
                SyncAllLoaderDataPacket::new
        );

        private static void handle(SyncAllLoaderDataPacket packet, ClientAccess access) {
            for (var innerPacket : packet.packets()) {
                SyncLoaderDataPacket.handle(innerPacket, access);
            }
        }
    }

    @ApiStatus.Internal
    private record SyncLoaderDataPacket(class_2960 id, BiMap<class_2960, Object> data) {
        private static final Map<class_2960, StructEndec<SyncLoaderDataPacket>> CACHED_ENDECS = new HashMap<>();

        private static final StructEndec<SyncLoaderDataPacket> ENDEC = (StructEndec<SyncLoaderDataPacket>) Endec.dispatched(
                id -> {
                    var loader = getLoader(id);

                    if (loader == null) {
                        throw new IllegalStateException("Unable to get following Data Loader to handle the given sync packet: " + id);
                    }

                    return CACHED_ENDECS.computeIfAbsent(id, identifier -> {
                        return StructEndecBuilder.of(
                                MinecraftEndecs.IDENTIFIER.fieldOf("id", SyncLoaderDataPacket::id),
                                loader.mapEndec.fieldOf("data", SyncLoaderDataPacket::data),
                                SyncLoaderDataPacket::new
                        );
                    });
                },
                SyncLoaderDataPacket::id,
                MinecraftEndecs.IDENTIFIER);

        private static void handle(SyncLoaderDataPacket packet, ClientAccess access) {
            getLoader(packet.id()).handleUnsafeSync(packet.data());
        }
    }
}
