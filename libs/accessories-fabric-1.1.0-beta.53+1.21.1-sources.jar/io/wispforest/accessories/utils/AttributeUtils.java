package io.wispforest.accessories.utils;

import com.mojang.logging.LogUtils;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.attributes.AccessoryAttributeBuilder;
import io.wispforest.owo.serialization.endec.MinecraftEndecs;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.StructEndecBuilder;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_5131;

public class AttributeUtils {
    public static final Logger LOGGER = LogUtils.getLogger();

    public static void addTransientAttributeModifiers(class_1309 livingEntity, AccessoryAttributeBuilder attributes) {
        if(attributes.isEmpty()) return;

        var attributeMap = livingEntity.method_6127();
        var capability = livingEntity.accessoriesCapability();

        if (capability == null) return;

        var containers = capability.getContainers();

        for (var entry : attributes.getSlotModifiers().asMap().entrySet()) {
            var container = containers.get(entry.getKey());

            if (container == null) continue;

            for (var modifier :  entry.getValue()) {
                if (!container.hasModifier(modifier.comp_2447())) container.addTransientModifier(modifier);
            }
        }

        for (var entry : attributes.getAttributeModifiers(true).asMap().entrySet()) {
            var instance = attributeMap.method_45329(entry.getKey());

            if (instance == null) continue;

            for (var modifier : entry.getValue()) {
                if (!instance.method_6196(modifier.comp_2447())) instance.method_26835(modifier);
            }
        }
    }

    public static void removeTransientAttributeModifiers(class_1309 livingEntity, AccessoryAttributeBuilder attributes) {
        if(attributes.isEmpty()) return;

        var attributeMap = livingEntity.method_6127();
        var capability = livingEntity.accessoriesCapability();

        var containers = capability.getContainers();

        for (var entry : attributes.getSlotModifiers().asMap().entrySet()) {
            var container = containers.get(entry.getKey());

            if (container == null) continue;

            for (var attributeModifier : entry.getValue()) container.removeModifier(attributeModifier.comp_2447());
        }

        for (var entry : attributes.getAttributeModifiers(true).asMap().entrySet()) {
            var instance = attributeMap.method_45329(entry.getKey());

            if (instance == null) continue;

            for (var attributeModifier : entry.getValue()) instance.method_6200(attributeModifier.comp_2447());
        }
    }

    public static final StructEndec<class_1322> ATTRIBUTE_MODIFIER_ENDEC = StructEndecBuilder.of(
            MinecraftEndecs.IDENTIFIER.fieldOf("id", class_1322::comp_2447),
            Endec.DOUBLE.fieldOf("amount", class_1322::comp_2449),
            EndecUtils.forEnumStringRepresentable(class_1322.class_1323.class).fieldOf("operation", class_1322::comp_2450),
            class_1322::new
    );
}
