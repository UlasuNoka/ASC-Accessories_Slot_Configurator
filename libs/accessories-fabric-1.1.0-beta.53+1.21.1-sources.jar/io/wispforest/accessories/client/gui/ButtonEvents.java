package io.wispforest.accessories.client.gui;

import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;

public class ButtonEvents {

    public static <B extends class_4264> B adjustRendering(B button, AdjustRendering event){
        ((AbstractButtonExtension) button).getRenderingEvent().register(event);

        return button;
    }

    public interface AdjustRendering {
        boolean render(class_4264 button, class_332 instance, class_2960 sprite, int x, int y, int width, int height);
    }
}
