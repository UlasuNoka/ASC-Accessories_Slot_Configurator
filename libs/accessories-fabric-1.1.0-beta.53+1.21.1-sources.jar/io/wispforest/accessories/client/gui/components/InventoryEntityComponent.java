package io.wispforest.accessories.client.gui.components;

import F;
import I;
import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.systems.RenderSystem;
import io.wispforest.owo.ui.component.EntityComponent;
import io.wispforest.owo.ui.core.Color;
import io.wispforest.owo.ui.core.Component;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.ui.core.Sizing;
import io.wispforest.owo.util.pond.OwoEntityRenderDispatcherExtension;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_308;
import net.minecraft.class_4587;
import net.minecraft.class_765;
import net.minecraft.class_7833;

public class InventoryEntityComponent<E extends class_1297> extends EntityComponent<E> {

    private float startingRotation = -45;

    private float lastBbWidth = 0.0f;
    private float lastBbHeight = 0.0f;

    private ScaleFitType type = ScaleFitType.NONE;

    public InventoryEntityComponent(Sizing sizing, E entity) {
        super(sizing, entity);

        this.lastBbWidth = entity.method_17681();
        this.lastBbHeight = entity.method_17682();
    }

    public InventoryEntityComponent(Sizing sizing, class_1299<E> type, @Nullable class_2487 nbt) {
        super(sizing, type, nbt);
    }

    public static <E extends class_1297> InventoryEntityComponent<E> of(Sizing verticalSizing, Sizing horizontalSizing, E entity) {
        var component = new InventoryEntityComponent<E>(verticalSizing, entity);

        component.horizontalSizing(horizontalSizing);

        return component;
    }

    private float getEntityScale() {
        return (entity instanceof class_1309 living) ? living.method_55693() : 1.0f;
    }

    public float xOffset = 0.0f;
    public float yOffset = 0.0f;

    private TriConsumer<OwoUIDrawContext, Component, Runnable> renderWrapping = (ctx, component, runnable) -> runnable.run();

    public InventoryEntityComponent<E> renderWrapping(TriConsumer<OwoUIDrawContext, Component, Runnable> renderWrapping) {
        this.renderWrapping = renderWrapping;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFit(boolean scaleToFit) {
        if(scaleToFit) {
            var componentHeight = (float) this.verticalSizing().get().value;
            var componentWidth = (float) this.horizontalSizing().get().value - 40;

            var entityHeight = entity.method_17682() * (Math.min(componentWidth, componentHeight) / Math.max(componentWidth, componentHeight));
            var entityWidth = entity.method_17681()* (Math.max(componentWidth, componentHeight) / Math.min(componentWidth, componentHeight));

            var length = Math.max(entityHeight, entityWidth);

            float baseScale = (.35f / length);

            this.scale(baseScale);

            type = ScaleFitType.BOTH;
        } else {
            this.scale(1);

            type = ScaleFitType.NONE;
        }

        return this;
    }

    public InventoryEntityComponent<E> startingRotation(float value) {
        this.startingRotation = value;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFitVertically(boolean scaleToFit) {
        this.scale(scaleToFit ? (.5f / entity.method_17682()) : 1);

        type = scaleToFit ? ScaleFitType.VERTICAL : ScaleFitType.NONE;

        return this;
    }

    public InventoryEntityComponent<E> scaleToFitHorizontally(boolean scaleToFit) {
        this.scale(scaleToFit ? (.5f / entity.method_17681()) : 1);

        type = scaleToFit ? ScaleFitType.HORIZONTAL : ScaleFitType.NONE;

        return this;
    }

    @Override
    public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
        if(!(entity instanceof class_1309 living)) {
            super.draw(context, mouseX, mouseY, partialTicks, delta);

            return;
        }

        if (this.lastBbWidth != entity.method_17681() || this.lastBbHeight != entity.method_17682()) {
            switch (type) {
                case VERTICAL -> this.scaleToFitVertically(true);
                case HORIZONTAL -> this.scaleToFitHorizontally(true);
                case BOTH -> this.scaleToFit(true);
                case NONE -> {}
            }

            this.lastBbWidth = entity.method_17681();
            this.lastBbHeight = entity.method_17682();
        }

//        var GL_ZERO     = 0x0000;
//        var GL_KEEP     = 0x1E00;
//        var GL_REPLACE  = 0x1E01;
//        var GL_INCR     = 0x1E02;
//        var GL_DECR     = 0x1E03;
//        var GL_INVERT   = 0x150A;
//        var GL_NOTEQUAL = 0x0205;
//        var GL_ALWAYS   = 0x0207;
//
//        var GL_STENCIL_BUFFER_BIT = 0x00000400;
//
//        var GL_STENCIL_TEST = 0x0B90;
//
//        context.flush();
//
//        RenderSystem.enableDepthTest();
//        GL11.glEnable(GL11.GL_STENCIL_TEST);
//
//        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clear(GL11.GL_STENCIL_BUFFER_BIT, Minecraft.ON_OSX);
//        RenderSystem.clearStencil(0);
//
//        RenderSystem.stencilMask(0xFF);
//        RenderSystem.stencilFunc(GL11.GL_EQUAL, 1, 0xFF);
//        RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_REPLACE);
//
//        context.fill(0, 0, Minecraft.getInstance().getWindow().getGuiScaledWidth(), Minecraft.getInstance().getWindow().getGuiScaledHeight(), Color.BLUE.argb());
//        context.fill(this.x, this.y, this.x + 50, this.y + 50, Color.WHITE.argb());
//
//        context.flush();
//
//        //RenderSystem.stencilMask(0x00);
//        RenderSystem.stencilFunc(GL11.GL_NOTEQUAL, 1, 0xFF);

        var matrices = context.method_51448();
        matrices.method_22903();

        var maxLength = Math.max(this.width, this.height);

        matrices.method_46416(x + this.width / 2f, y + this.height / 2f, 60);
        matrices.method_22905(75 * this.scale * maxLength / 64f, -75 * this.scale * maxLength / 64f, 75 * this.scale);

        matrices.method_46416(0, entity.method_17682() / -2f, 0);

        matrices.method_46416(this.xOffset, this.yOffset, 0);

        this.transform.accept(matrices);

        float prevYBodyRot0 = living.field_6220;
        float prevYBodyRot = living.field_6283;
        float prevYRot = living.method_36454();
        float prevYRot0 = living.field_5982;
        float prevXRot = living.method_36455();
        float prevXRot0 = living.field_6004;
        float prevYHeadRot0 = living.field_6259;
        float prevYHeadRot = living.field_6241;

        var dispatcher = (OwoEntityRenderDispatcherExtension) this.dispatcher;

        if (this.lookAtCursor) {
            float xRotation = (float) Math.toDegrees(Math.atan((mouseY - this.y - this.height / 2f) / 40f));
            float yRotation = (float) Math.toDegrees(Math.atan((mouseX - this.x - this.width / 2f) / 40f));

            living.field_6259 = -yRotation;

            this.entity.field_5982 = -yRotation;
            this.entity.field_6004 = xRotation * .65f;

            // We make sure the xRotation never becomes 0, as the lighting otherwise becomes very unhappy
            if (xRotation == 0) xRotation = .1f;
            matrices.method_22907(class_7833.field_40714.rotationDegrees(xRotation * .35f));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(yRotation * .555f));
        } else {
            float xRotation = (float) Math.toDegrees(Math.atan((mouseY - this.y - this.height / 2f) / 40f));

            this.entity.field_6004 = xRotation * .35f;

            if (xRotation == 0) xRotation = .1f;
            matrices.method_22907(class_7833.field_40714.rotationDegrees(xRotation * .15f));

            matrices.method_22907(class_7833.field_40714.rotationDegrees(15));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(startingRotation + this.mouseRotation));
        }

        {
            dispatcher.owo$setCounterRotate(true);
            dispatcher.owo$setShowNametag(this.showNametag);

            class_308.method_34742();

            this.dispatcher.method_3948(false);

            living.field_6220 = 0;
            living.field_6283 = 0;
            living.method_36456(0);
            living.field_6241 = living.field_6283;
            living.field_6259 = living.field_6220;

            RenderSystem.disableDepthTest();

            this.renderWrapping.accept(context,this,
                    () -> this.dispatcher.method_3954(this.entity, 0, 0, 0, 0, 0, matrices, this.entityBuffers, class_765.field_32767)
            );

//            this.entityBuffers.endBatch();
//
//            RenderSystem.stencilMask(0xFF);
//            RenderSystem.stencilFunc(GL11.GL_ALWAYS, 1, 0xFF);
//            RenderSystem.enableDepthTest();
//
//            GL11.glDisable(GL_STENCIL_TEST);

            this.dispatcher.method_3948(true);
        }

        living.field_6220 = prevYBodyRot0;
        living.field_6283 = prevYBodyRot;
        living.method_36456(prevYRot);
        living.field_5982 = prevYRot0;
        living.method_36457(prevXRot);
        living.field_6004 = prevXRot0;
        living.field_6259 = prevYHeadRot0;
        living.field_6241 = prevYHeadRot;

        this.dispatcher.method_3948(true);
        this.entityBuffers.method_22993();
        class_308.method_24211();

        matrices.method_22909();

        dispatcher.owo$setCounterRotate(false);
        dispatcher.owo$setShowNametag(true);
    }

    @Override
    public boolean onMouseScroll(double mouseX, double mouseY, double amount) {
        this.scale += (float) (amount * this.scale * 0.1f);

        return true;
    }

    @Override
    public boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
        if(keyCode == GLFW.GLFW_KEY_LEFT) {
            this.xOffset -= 0.05f;
        } else if(keyCode == GLFW.GLFW_KEY_RIGHT) {
            this.xOffset += 0.05f;
        }

        if(keyCode == GLFW.GLFW_KEY_UP) {
            this.yOffset += 0.05f;
        } else if(keyCode == GLFW.GLFW_KEY_DOWN) {
            this.yOffset -= 0.05f;
        }

        return super.onKeyPress(keyCode, scanCode, modifiers);
    }

    public enum ScaleFitType {
        VERTICAL,
        HORIZONTAL,
        BOTH,
        NONE;
    }
}
