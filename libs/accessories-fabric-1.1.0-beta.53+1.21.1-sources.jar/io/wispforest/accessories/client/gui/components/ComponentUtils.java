package io.wispforest.accessories.client.gui.components;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.client.GuiGraphicsUtils;
import io.wispforest.accessories.client.gui.AccessoriesExperimentalScreen;
import io.wispforest.accessories.menu.SlotTypeAccessible;
import io.wispforest.accessories.menu.variants.AccessoriesExperimentalMenu;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.SyncCosmeticToggle;
import io.wispforest.accessories.pond.owo.ComponentExtension;
import io.wispforest.accessories.pond.owo.MutableBoundingArea;
import io.wispforest.owo.ui.base.BaseOwoHandledScreen;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.container.Containers;
import io.wispforest.owo.ui.container.FlowLayout;
import io.wispforest.owo.ui.container.ScrollContainer;
import io.wispforest.owo.ui.core.*;
import io.wispforest.owo.ui.util.NinePatchTexture;
import io.wispforest.owo.ui.util.ScissorStack;
import it.unimi.dsi.fastutil.Pair;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_1058;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1735;
import net.minecraft.class_1761;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class ComponentUtils {

    private static final class_2960 SLOT = class_2960.method_60656("textures/gui/sprites/container/slot.png");
    private static final class_2960 DARK_SLOT = Accessories.of("textures/gui/theme/dark/slot.png");

    public static final Surface BACKGROUND_SLOT_RENDERING_SURFACE = (context, component) -> {
        var slotComponents = new ArrayList<AccessoriesExperimentalScreen.ExtendedSlotComponent>();

        recursiveSearch(component, AccessoriesExperimentalScreen.ExtendedSlotComponent.class, slotComponents::add);

        context.push();
        context.translate(component.x(), component.y(), 0);

        GuiGraphicsUtils.batched(context, getSlotTexture(), slotComponents, (bufferBuilder, poseStack, slotComponent) -> {
            GuiGraphicsUtils.blit(bufferBuilder, poseStack, slotComponent.x() - component.x() - 1, slotComponent.y() - component.y() - 1, 18);
        });

        context.pop();
    };

    public static final ScrollContainer.Scrollbar VANILLA = (context, x, y, width, height, trackX, trackY, trackWidth, trackHeight, lastInteractTime, direction, active) -> {
        NinePatchTexture.draw(Accessories.of(("theme/" + checkMode("light", "dark") + "/scrollbar/track")), context, trackX, trackY, trackWidth, trackHeight);
        NinePatchTexture.draw(getScrollabarTexture(direction, active), context, x + 1, y + 1, width - 2, height - 2);
    };

    public static class_2960 getScrollabarTexture(ScrollContainer.ScrollDirection direction, boolean active) {
        var scrollBarType = (direction == ScrollContainer.ScrollDirection.VERTICAL ? "vertical" : "horizontal") + (active ? "" : "_disabled");
        var themeType = checkMode("light", "dark");

        return Accessories.of("theme/" + themeType + "/scrollbar/vanilla_" + scrollBarType);
    }

    public static final Surface PANEL_INSET = (context, component) -> {
        NinePatchTexture.draw(Accessories.of(("theme/" + checkMode("light", "dark") + "/inset")), context, component);
    };

    public static final Surface PANEL = (context, component) -> {
        NinePatchTexture.draw(Accessories.of(("theme/" + checkMode("light", "dark") + "/panel")), context, component);
    };

    private static final ButtonComponent.Renderer BUTTON_RENDERER = (context, button, delta) -> {
        RenderSystem.enableDepthTest();

        NinePatchTexture.draw(getBtnTexture(button), context, button.method_46426(), button.method_46427(), button.width(), button.height());
    };

    private static class_2960 getBtnTexture(ButtonComponent btn) {
        var btnType = (btn.method_37303() ? (btn.method_49606() ? "hovered" : "active") : "disabled");
        var themeType = checkMode("light", "dark");

        return Accessories.of("theme/" + themeType + "/button/" + btnType);
    }

    public static <T> T checkMode(T lightMode, T darkMode) {
        return Accessories.config().screenOptions.isDarkMode() ? darkMode : lightMode;
    }

    public static class_2960 getSlotTexture() {
        return checkMode(SLOT, DARK_SLOT);
    }

    public static Surface getPanelSurface() {
        return PANEL;
    }

    public static Surface getInsetPanelSurface() {
        return PANEL_INSET;
    }

    public static Surface getPanelWithInset(int insetWidth) {
        return (context, component) -> {
            var location = Accessories.of(("theme/" + checkMode("light", "dark") + "/inset"));

            NinePatchTexture.draw(location, context, component.x() + insetWidth, component.y() + insetWidth, component.width() - insetWidth * 2, component.height() - insetWidth * 2);
        };
    }

    public static ButtonComponent.Renderer getButtonRenderer() {
        return BUTTON_RENDERER;
    }

    public static ScrollContainer.Scrollbar getScrollbarRenderer() {
        return VANILLA;
    }

    public static <C extends io.wispforest.owo.ui.core.Component> void recursiveSearch(ParentComponent parentComponent, Class<C> target, Consumer<C> action) {
        if(parentComponent == null) return;

        for (var child : parentComponent.children()) {
            if(target.isInstance(child)) action.accept((C) child);
            if(child instanceof ParentComponent childParent) recursiveSearch(childParent, target, action);
        }
    }

    public static <S extends class_1735 & SlotTypeAccessible> Pair<io.wispforest.owo.ui.core.Component, PositionedRectangle> slotAndToggle(S slot, Function<Integer, AccessoriesExperimentalScreen.ExtendedSlotComponent> slotBuilder) {
        return slotAndToggle(slot, true, slotBuilder);
    }

    public static <S extends class_1735 & SlotTypeAccessible> Pair<io.wispforest.owo.ui.core.Component, PositionedRectangle> slotAndToggle(S slot, boolean isBatched, Function<Integer, AccessoriesExperimentalScreen.ExtendedSlotComponent> slotBuilder) {
        var btnPosition = Positioning.absolute(14, -1); //15, -1

        var toggleBtn = ComponentUtils.slotToggleBtn(slot)
                .configure(component -> {
                    component.zIndex(360)
                            .sizing(Sizing.fixed(5))
                            .positioning(btnPosition);
                });

        ((ComponentExtension)(toggleBtn)).allowIndividualOverdraw(true);

        var combinedLayout = Containers.verticalFlow(Sizing.fixed(18), Sizing.fixed(18))
                .child(
                        slotBuilder.apply(slot.field_7874)
                                .isBatched(isBatched)
                                .margins(Insets.of(1))
                ).child(toggleBtn);

        var combinedArea = ((MutableBoundingArea) combinedLayout);

        //combinedArea.addInclusionZone(toggleBtn);
        //combinedArea.deepRecursiveChecking(true);

        return Pair.of(
                combinedLayout,
                toggleBtn
        );
    }

    public static <S extends class_1735 & SlotTypeAccessible> ButtonComponent slotToggleBtn(S slot) {
        return toggleBtn(class_2561.method_43470(""),
                () -> slot.getContainer().shouldRender(slot.method_34266()),
                (btn) -> {
                    var entity = slot.getContainer().capability().entity();

                    AccessoriesNetworking
                            .sendToServer(SyncCosmeticToggle.of(entity.equals(class_310.method_1551().field_1724) ? null : entity, slot.slotType(), slot.method_34266()));
                });
    }

    public static ButtonComponent groupToggleBtn(AccessoriesExperimentalScreen screen, SlotGroup group) {
        var btn = toggleBtn(
                class_2561.method_43473(),
                () -> {
                    var menu = screen.method_17577();

                    return menu.isGroupSelected(group);
                },
                buttonComponent -> {
                    var menu = screen.method_17577();

                    if(menu.isGroupSelected(group)) {
                        menu.removeSelectedGroup(group);
                    } else {
                        menu.addSelectedGroup(group);
                    }

                    screen.rebuildAccessoriesComponent();
                },
                (context, button, delta) -> {
                    var textureAtlasSprite = class_310.method_1551()
                            .method_1549(class_2960.method_60656("textures/atlas/gui.png"))
                            .apply(group.icon());

                    var color = Color.WHITE;

                    RenderSystem.depthMask(false);
                    RenderSystem.setShaderColor(color.red(), color.green(), color.blue(), 1f);
                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE);

                    context.method_48465(button.x() + 3, button.y() + 3, 2, 8, 8, textureAtlasSprite, color.red(), color.green(), color.blue(), 1f);

                    RenderSystem.depthMask(true);
                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                    RenderSystem.disableBlend();
                    RenderSystem.defaultBlendFunc();
                });

        var tooltipData = new ArrayList<class_2561>();

        tooltipData.add(class_2561.method_43471(group.translation()));
        if (UniqueSlotHandling.isUniqueGroup(group.name(), true)) tooltipData.add(class_2561.method_43470(group.name()).method_27695(class_124.field_1078, class_124.field_1056));

        btn.sizing(Sizing.fixed(14))
                .tooltip(tooltipData);

        return btn;
    }

    public static ButtonComponent toggleBtn(net.minecraft.class_2561 message, Supplier<Boolean> stateSupplier, Consumer<ButtonComponent> onToggle) {
        return toggleBtn(message, stateSupplier, onToggle, (context, button, delta) -> {});
    }

    public static ButtonComponent toggleBtn(net.minecraft.class_2561 message, Supplier<Boolean> stateSupplier, Consumer<ButtonComponent> onToggle, ButtonComponent.Renderer extraRendering) {
        ButtonComponent.Renderer texturedRenderer = (context, btn, delta) -> {
            RenderSystem.enableDepthTest();
            var state = stateSupplier.get();

            class_2960 texture = getToggleBtnTexture(btn, state);

            context.push();

            Runnable drawCall = () -> {
                NinePatchTexture.draw(texture, context, btn.method_46426(), btn.method_46427(), btn.width(), btn.height());
                extraRendering.draw(context, btn, delta);
            };

            if(btn instanceof ComponentExtension<?> extension && extension.allowIndividualOverdraw()) {
                ScissorStack.popFramesAndDraw(7, drawCall);
            } else {
                drawCall.run();
            }

            context.pop();
        };

        return Components.button(message, onToggle)
                .renderer(texturedRenderer);
    }

    private static class_2960 getToggleBtnTexture(ButtonComponent btn, Boolean state) {
        var btnType = (state ? "enabled" : "disabled") + (btn.method_49606() ? "_hovered" : "");
        var themeType = checkMode("light", "dark");

        return Accessories.of("theme/" + themeType + "/button/toggle/rounded/" + btnType);
    }

    public static <C extends BaseOwoHandledScreen.SlotComponent> io.wispforest.owo.ui.core.Component createCraftingComponent(int start, int end, Function<Integer, C> componentFactory, Consumer<Integer> slotEnabler, boolean isVertical) {
        var craftingLayout = isVertical ? Containers.verticalFlow(Sizing.fixed(18 * 2), Sizing.content()) : Containers.horizontalFlow(Sizing.content(), Sizing.fixed(18 * 2));

        slotEnabler.accept(0);
        slotEnabler.accept(1);
        slotEnabler.accept(2);
        slotEnabler.accept(3);
        slotEnabler.accept(4);

        craftingLayout.configure((FlowLayout layout) -> {
            layout/*.surface(BACKGROUND_SLOT_RENDERING_SURFACE)*/
                    .allowOverflow(true);
        });

        var childrenList = new ArrayList<io.wispforest.owo.ui.core.Component>();

        childrenList.add(
                (!isVertical ? Containers.verticalFlow(Sizing.content(), Sizing.content()) : Containers.horizontalFlow(Sizing.content(), Sizing.content()))
                        .child(componentFactory.apply(start + 1).margins(Insets.of(1)))
                        .child(componentFactory.apply(start + 2).margins(Insets.of(1)))
        );
        childrenList.add(
                (!isVertical ? Containers.verticalFlow(Sizing.content(), Sizing.content()) : Containers.horizontalFlow(Sizing.content(), Sizing.content()))
                        .child(componentFactory.apply(start + 3).margins(Insets.of(1)))
                        .child(componentFactory.apply(start + 4).margins(Insets.of(1)))
        );
        childrenList.add(
                new ArrowComponent((isVertical) ? ArrowComponent.Direction.DOWN : ArrowComponent.Direction.RIGHT)
                        .centered(true)
                        .margins(Insets.of(3, 3, 1, 1))
                        .id("crafting_arrow")
                //Components.spacer().sizing(Sizing.fixed(4))
        );
        childrenList.add(
                (!isVertical ? Containers.verticalFlow(Sizing.content(), Sizing.expand()) : Containers.horizontalFlow(Sizing.expand(), Sizing.content()))
                        .child(componentFactory.apply(start).margins(Insets.of(1)))
                        .horizontalAlignment(HorizontalAlignment.CENTER)
                        .verticalAlignment(VerticalAlignment.CENTER)
        );

        craftingLayout.children(childrenList).horizontalAlignment(HorizontalAlignment.CENTER)
                .verticalAlignment(VerticalAlignment.CENTER);

        return craftingLayout;
    }

    public static <C extends BaseOwoHandledScreen.SlotComponent> io.wispforest.owo.ui.core.Component createPlayerInv(int start, int end, Function<Integer, C> componentFactory, Consumer<Integer> slotEnabler) {
        var playerLayout = Containers.verticalFlow(Sizing.content(), Sizing.content());

        int row = 0;

        var rowLayout = Containers.horizontalFlow(Sizing.content(), Sizing.content())
                .configure((FlowLayout layout) -> {
                    layout/*.surface(BACKGROUND_SLOT_RENDERING_SURFACE)*/
                            .allowOverflow(true);
                });

        int rowCount = 0;

        for (int i = start; i < end; i++) {
            var slotComponent = componentFactory.apply(i);

            slotEnabler.accept(i);

            rowLayout.child(slotComponent.margins(Insets.of(1)));

            if(row >= 8) {
                playerLayout.child(rowLayout);

                rowLayout = Containers.horizontalFlow(Sizing.content(), Sizing.content())
                        .configure((FlowLayout layout) -> {
                            layout/*.surface(BACKGROUND_SLOT_RENDERING_SURFACE)*/
                                    .allowOverflow(true);
                        });

                rowCount++;

                if(rowCount == 3) rowLayout.margins(Insets.top(4));

                row = 0;
            } else {
                row++;
            }
        }

        return playerLayout.allowOverflow(true);
    }

    public interface CreativeScreenExtension {
        Event<OnCreativeTabChange> getEvent();

        class_1761 getTab();
    }

    public interface OnCreativeTabChange {
        void onTabChange(class_1761 tab);
    }
}
