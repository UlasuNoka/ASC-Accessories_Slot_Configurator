package io.wispforest.accessories.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import io.wispforest.owo.ui.base.BaseComponent;
import io.wispforest.owo.ui.core.OwoUIDrawContext;
import io.wispforest.owo.ui.core.Sizing;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.joml.Matrix4f;

public class PixelPerfectTextureComponent extends BaseComponent {

    private final class_2960 texture;

    private final int textureWidth;
    private final int textureHeight;

    public PixelPerfectTextureComponent(class_2960 texture, int textureWidth, int textureHeight, Sizing horizontalSizing, Sizing verticalSizing) {
        super();

        this.texture = texture;

        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;

        if(horizontalSizing.isContent()) throw new IllegalStateException("HorizontalSizing of PixelPerfectTextureComponent was found to be Content Sizing, which is not allowed!");
        if(verticalSizing.isContent()) throw new IllegalStateException("VerticalSizing of PixelPerfectTextureComponent was found to be Content Sizing, which is not allowed!");

        this.horizontalSizing(horizontalSizing);
        this.verticalSizing(verticalSizing);
    }

    @Override
    public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
        drawPixelPerfectTextureQuad(context, texture, textureWidth, textureHeight, this.x(), this.y(), 0, this.width(), this.height());
    }

    public static void drawPixelPerfectTextureQuad(OwoUIDrawContext context, class_2960 texture, int textureWidth, int textureHeight, int x1, int y1, float z, int width, int height) {
        int x2 = x1 + width;
        int y2 = y1 + height;

        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);

        Matrix4f matrix4f = context.method_51448().method_23760().method_23761();

        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);

        bufferBuilder.method_22918(matrix4f, x1, y1, z)
                .method_22913(0, 0);

        bufferBuilder.method_22918(matrix4f, x1, y2, z)
                .method_22913(0, 1);

        bufferBuilder.method_22918(matrix4f, x2, y2, z)
                .method_22913(1, 1);

        bufferBuilder.method_22918(matrix4f, x2, y1, z)
                .method_22913(1, 0);

        class_286.method_43433(bufferBuilder.method_60800());
    }
}
