package io.wispforest.accessories.client.gui;

import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_4264;

public interface AbstractButtonExtension {
    Event<ButtonEvents.AdjustRendering> getRenderingEvent();

    default <B extends class_4264> B adjustRendering(ButtonEvents.AdjustRendering event) {
        this.getRenderingEvent().register(event);

        return (B) this;
    }
}
