package io.wispforest.accessories.client.gui;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.menu.AccessoriesBasedSlot;
import io.wispforest.accessories.api.slot.ExtraSlotTypeProperties;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.client.AccessoriesClient;
import io.wispforest.accessories.client.GuiGraphicsUtils;
import io.wispforest.accessories.client.gui.components.*;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.data.SlotTypeLoader;
import io.wispforest.accessories.menu.AccessoriesInternalSlot;
import io.wispforest.accessories.menu.ArmorSlotTypes;
import io.wispforest.accessories.menu.SlotTypeAccessible;
import io.wispforest.accessories.menu.networking.ToggledSlots;
import io.wispforest.accessories.menu.variants.AccessoriesExperimentalMenu;
import io.wispforest.accessories.mixin.client.AbstractContainerScreenAccessor;
import io.wispforest.accessories.mixin.client.owo.DiscreteSliderComponentAccessor;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.holder.HolderProperty;
import io.wispforest.accessories.networking.holder.SyncHolderChange;
import io.wispforest.accessories.pond.ContainerScreenExtension;
import io.wispforest.owo.mixin.ui.SlotAccessor;
import io.wispforest.owo.ui.base.BaseOwoHandledScreen;
import io.wispforest.owo.ui.component.ButtonComponent;
import io.wispforest.owo.ui.component.Components;
import io.wispforest.owo.ui.component.DiscreteSliderComponent;
import io.wispforest.owo.ui.container.*;
import io.wispforest.owo.ui.core.*;
import io.wispforest.owo.util.pond.OwoSlotExtension;
import it.unimi.dsi.fastutil.Pair;
import net.minecraft.class_1058;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_421;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_8658;
import net.minecraft.class_9692;
import net.minecraft.world.inventory.*;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL;
import org.slf4j.Logger;
import oshi.util.tuples.Triplet;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.wispforest.accessories.client.gui.components.ComponentUtils.BACKGROUND_SLOT_RENDERING_SURFACE;

import D;
import I;
import Z;

public class AccessoriesExperimentalScreen extends BaseOwoHandledScreen<FlowLayout, AccessoriesExperimentalMenu> implements AccessoriesScreenBase<AccessoriesExperimentalMenu>, ContainerScreenExtension {

    private static final Logger LOGGER = LogUtils.getLogger();

    public AccessoriesExperimentalScreen(AccessoriesExperimentalMenu handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);

        this.field_25269 = 42069;
    }

    @Override
    protected void method_25426() {
        if (!field_2797.isValidMenu()) {
            class_310.method_1551().method_1507(
                    new class_421(
                            class_2561.method_43470("Accessories Screen Opening Error!"),
                            class_2561.method_43470("Unable to open Accessories Screen due to desync with the Server!")
                    ));

            return;
        }

        super.method_25426();
    }

    //--

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (AccessoriesClient.OPEN_SCREEN.method_1417(keyCode, scanCode)) {
            this.method_25419();
            return true;
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    protected @NotNull OwoUIAdapter<FlowLayout> createAdapter() {
        return OwoUIAdapter.create(this, Containers::verticalFlow);
    }

    @Override
    public Stream<io.wispforest.owo.ui.core.Component> componentsForExclusionAreas() {
        return this.uiAdapter.rootComponent.children().stream();
    }

    @Override
    public <C extends io.wispforest.owo.ui.core.Component> C component(Class<C> expectedClass, String id) {
        return super.component(expectedClass, id);
    }

    private final Map<Integer, Boolean> changedSlots = new HashMap<>();

    @Override
    protected void method_37432() {
        super.method_37432();

        if (this.changedSlots.isEmpty()) return;

        var slots = this.method_17577().field_7761;

        var changes = this.changedSlots.entrySet().stream()
                .filter(entry -> entry.getKey() < slots.size())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        this.method_17577().sendMessage(new ToggledSlots(changes));

        this.changedSlots.clear();
    }

    public void hideSlot(int index) {
        hideSlot(this.field_2797.field_7761.get(index));
    }

    public void hideSlot(class_1735 slot) {
        ((SlotAccessor) slot).owo$setX(-300);
        ((SlotAccessor) slot).owo$setY(-300);
    }

    @Override
    public void disableSlot(class_1735 slot) {
        super.disableSlot(slot);

        var index = slot.field_7874;

        var state = this.changedSlots.getOrDefault(index, null);

        if (state != null && state) return;

        hideSlot(index);

        this.changedSlots.put(index, true);
    }

    public void disableSlots(int ...index) {
        for (int i : index) disableSlot(i);
    }

    @Override
    public void enableSlot(class_1735 slot) {
        super.enableSlot(slot);

        var index = slot.field_7874;

        var state = this.changedSlots.getOrDefault(index, null);

        if (state != null && !state) return;

        this.changedSlots.put(index, false);
    }

    //--

    @Override
    public final class_1309 targetEntityDefaulted() {
        var targetEntity = this.field_2797.targetEntity();

        return (targetEntity != null) ? targetEntity : this.field_22787.field_1724;
    }

    @Override
    public class_1735 getHoveredSlot() {
        return this.field_2787;
    }

    @Override
    @Nullable
    public Boolean isHovering_Logical(class_1735 slot, double mouseX, double mouseY) {
        var accessories = this.topComponent;

        return (accessories != null) ? accessories.isHovering_Logical(slot, mouseX, mouseY) : null;
    }

    @Override
    @Nullable
    public Boolean isHovering_Rendering(class_1735 slot, double mouseX, double mouseY) {
        return (slot instanceof SlotTypeAccessible) ? Boolean.FALSE : null;
    }

    @Override
    public @Nullable Boolean shouldRenderSlot(class_1735 slot) {
        return (slot instanceof SlotTypeAccessible) ? Boolean.FALSE : null;
    }

    @Override
    public int hoverStackOffset() {
        return 160;
    }

    @Override
    public void method_25419() {
        var selectedGroups = this.method_17577().selectedGroups().stream()
                .map(SlotGroup::name)
                .collect(Collectors.toSet());

        AccessoriesNetworking
                .sendToServer(SyncHolderChange.of(HolderProperty.FILTERED_GROUPS, selectedGroups));

        super.method_25419();
    }

    //--

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        if(this.field_2787 != null) {
            if (this.field_2787 instanceof AccessoriesInternalSlot accessoriesInternalSlot) {
                if (!ArmorSlotTypes.isArmorType(accessoriesInternalSlot.slotName())) {
                    AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(this.mainWidgetPosition());
                }
            } else if (this.field_2787 instanceof class_9692) {
                AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(true);
            } else if (this.field_2787.field_7871 instanceof class_1715 || this.field_2787 instanceof class_1734) {
                if (!this.showGroupFilters()) {
                    AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(!this.mainWidgetPosition());
                }
            }
        }

        guiGraphics.push()
                .translate(0,0,300);

        super.method_2380(guiGraphics, x, y);

        guiGraphics.pop();

        AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(false);
    }

    protected List<class_2561> method_51454(class_1799 itemStack) {
        var tooltipData = method_25408(this.field_22787, itemStack);

        if (Accessories.config().screenOptions.showEquippedStackSlotType()
                && this.field_2797.method_34255().method_7960()
                && this.field_2787 != null
                && this.field_2787.method_7681()
                && this.field_2787 instanceof AccessoriesBasedSlot slot && ExtraSlotTypeProperties.getProperty(slot.slotName(), true).allowTooltipInfo()) {
            var hoveredStack = this.field_2787.method_7677();

            if (itemStack == hoveredStack) {
                tooltipData.add(class_2561.method_43473());
                tooltipData.add(
                        class_2561.method_43471(Accessories.translationKey("tooltip.currently_equipped_in"))
                                .method_27692(class_124.field_1080)
                                .method_10852(
                                        class_2561.method_43471(slot.slotType().translation())
                                                .method_27692(class_124.field_1078)
                                )
                );
            }
        }

        return tooltipData;
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.method_2389(guiGraphics, partialTick, mouseX, mouseY);

        //--

        if (getHoveredSlot() != null && getHoveredSlot() instanceof AccessoriesInternalSlot slot && slot.method_7682() && !slot.method_7677().method_7960()) {
            if (NOT_VERY_NICE_POSITIONS.containsKey(slot.accessoriesContainer.getSlotName() + slot.method_34266())) {
                ACCESSORY_POSITIONS.add(NOT_VERY_NICE_POSITIONS.get(slot.accessoriesContainer.getSlotName() + slot.method_34266()));

                var positionKey = slot.accessoriesContainer.getSlotName() + slot.method_34266();
                var vec = NOT_VERY_NICE_POSITIONS.getOrDefault(positionKey, null);

                if (!slot.isCosmetic && vec != null && (Accessories.config().screenOptions.hoveredOptions.line())) {
                    var start = new Vector3d(slot.field_7873 + this.field_2776 + 17, slot.field_7872 + this.field_2800 + 9, 5000);
                    var vec3 = vec.add(0, 0, 5000);

                    ACCESSORY_LINES.add(Pair.of(start, vec3));}
            }
        }
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.method_2389(guiGraphics, partialTick, mouseX, mouseY);

        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

        if (Accessories.config().screenOptions.hoveredOptions.clickbait()) {
            ACCESSORY_POSITIONS.forEach(pos -> guiGraphics.method_52707(Accessories.of("highlight/clickbait"), (int) pos.x - 128, (int) pos.y - 128, 450, 256, 256));
            ACCESSORY_POSITIONS.clear();
        }

        if (!ACCESSORY_LINES.isEmpty() || Accessories.config().screenOptions.hoveredOptions.line()) {
            var buf = guiGraphics.method_51450().getBuffer(class_1921.field_21695);
            var lastPose = guiGraphics.method_51448().method_23760();

            for (Pair<Vector3d, Vector3d> line : ACCESSORY_LINES) {
                var endPoint = line.second();

                if (endPoint.x == 0 || endPoint.y == 0) continue;

                var normalVec = endPoint.sub(line.first(), new Vector3d()).normalize().get(new Vector3f());

                double segments = Math.max(10, ((int) (line.first().distance(line.second()) * 10)) / 100);
                segments *= 2;

                var movement = (System.currentTimeMillis() / (segments * 1000) % 1);
                var delta = movement % (2 / (segments)) % segments;

                var firstVec = line.first().get(new Vector3f());

                if (delta > 0.05) {
                    buf.method_60830(firstVec)
                            .method_1336(255, 255, 255, 255)
                            .method_22922(class_4608.field_21444)
                            .method_60831(lastPose, normalVec.x, normalVec.y, normalVec.z);

                    var pos = new Vector3d(
                            class_3532.method_16436(delta - 0.05, line.first().x, line.second().x),
                            class_3532.method_16436(delta - 0.05, line.first().y, line.second().y),
                            class_3532.method_16436(delta - 0.05, line.first().z, line.second().z)
                    ).get(new Vector3f());

                    buf.method_60830(pos)
                            .method_1336(255, 255, 255, 255)
                            .method_22922(class_4608.field_21444)
                            .method_60831(lastPose, normalVec.x, normalVec.y, normalVec.z);
                }

                for (int i = 0; i < segments / 2; i++) {
                    var delta1 = ((i * 2) / segments + movement) % 1;
                    var delta2 = ((i * 2 + 1) / segments + movement) % 1;

                    var pos1 = new Vector3d(
                            class_3532.method_16436(delta1, line.first().x, line.second().x),
                            class_3532.method_16436(delta1, line.first().y, line.second().y),
                            class_3532.method_16436(delta1, line.first().z, line.second().z)
                    ).get(new Vector3f());
                    var pos2 = (delta2 > delta1 ? new Vector3d(
                            class_3532.method_16436(delta2, line.first().x, line.second().x),
                            class_3532.method_16436(delta2, line.first().y, line.second().y),
                            class_3532.method_16436(delta2, line.first().z, line.second().z)
                    ) : line.second()).get(new Vector3f());

                    buf.method_60830(pos1)
                            .method_1336(255, 255, 255, 255)
                            .method_22922(class_4608.field_21444)
                            .method_60831(lastPose, normalVec.x, normalVec.y, normalVec.z);

                    buf.method_60830(pos2)
                            .method_1336(255, 255, 255, 255)
                            .method_22922(class_4608.field_21444)
                            .method_60831(lastPose, normalVec.x, normalVec.y, normalVec.z);
                }
            }

            field_22787.method_22940().method_23000().method_22994(class_1921.field_21695);

            ACCESSORY_LINES.clear();
        }
    }

    //--

    private boolean showCosmeticState = false;

    public void showCosmeticState(boolean value) {
        this.showCosmeticState = value;
    }

    public boolean showCosmeticState() {
        return showCosmeticState;
    }

    @Override
    protected void build(FlowLayout rootComponent) {
        this.changedSlots.clear();

        this.method_17577().field_7761.forEach(this::disableSlot);

        //--

        rootComponent.allowOverflow(true)
                .horizontalAlignment(HorizontalAlignment.CENTER)
                .verticalAlignment(VerticalAlignment.CENTER)
                .surface(Surface.VANILLA_TRANSLUCENT);

        var baseChildren = new ArrayList<io.wispforest.owo.ui.core.Component>();

        var accessoriesComponent = createAccessoriesComponent();

        //--

        var menu = this.method_17577();

        SlotGroupLoader.getValidGroups(this.method_17577().targetEntityDefaulted()).keySet().stream()
                .filter(group -> this.getHolderValue(AccessoriesHolder::filteredGroups, Set.of(), "filteredGroups").contains(group.name()))
                .forEach(menu::addSelectedGroup);

        //--

        var playerInv = ComponentUtils.createPlayerInv(5, menu.startingAccessoriesSlot(), this::slotAsComponent, this::enableSlot);

        this.showAdvancedOptions(false);

        var offHandIndex = this.method_17577().startingAccessoriesSlot() - (this.method_17577().includeSaddle() ? 2 : 1);

        this.enableSlot(offHandIndex);

        baseChildren.add(
                Containers.horizontalFlow(Sizing.content(), Sizing.content())//Sizing.fixed(195 + 39), Sizing.fixed(88) : [39, 60]
                        .child(
                                Containers.verticalFlow(Sizing.fixed(162), Sizing.fixed(76))
                                        .child(playerInv)
                                        .margins(Insets.right(3))
                                        .id("bottom_component_holder")
                        ).child(
                                Containers.verticalFlow(Sizing.content(), Sizing.content()) // Sizing.expand()
                                        .child(
                                                Components.button(createToggleTooltip("advanced_options", false, this.showAdvancedOptions()), btn -> {
                                                            this.showAdvancedOptions(!this.showAdvancedOptions());

                                                            btn.method_25355(createToggleTooltip("advanced_options", false, this.showAdvancedOptions()));
                                                            btn.tooltip(createToggleTooltip("advanced_options", true, this.showAdvancedOptions()));

                                                            this.swapBottomComponentHolder();
                                                        })
                                                        .renderer(ComponentUtils.getButtonRenderer())
                                                        .tooltip(createToggleTooltip("advanced_options", true, this.showAdvancedOptions()))
                                                        .sizing(Sizing.fixed(16))
                                                        .margins(Insets.of(1))
                                        )
                                        .child(
                                                Components.button(createToggleTooltip("crafting_grid", false, this.showCraftingGrid()), btn -> {
                                                            AccessoriesNetworking
                                                                    .sendToServer(SyncHolderChange.of(HolderProperty.CRAFTING_GRID_PROP, this.field_2797.owner(), bl -> !bl));

                                                            this.showCraftingGrid(!this.showCraftingGrid());

                                                            btn.method_25355(createToggleTooltip("crafting_grid", false, this.showCraftingGrid()));
                                                            btn.tooltip(createToggleTooltip("crafting_grid", true, this.showCraftingGrid()));

                                                            this.toggleCraftingGrid();
                                                        })
                                                        .renderer(ComponentUtils.getButtonRenderer())
                                                        .tooltip(createToggleTooltip("crafting_grid", true, this.showCraftingGrid()))
                                                        .sizing(Sizing.fixed(16))
                                                        .margins(Insets.of(1))
                                                        .id("crafting_grid_button")
                                        )
                                        .child(Components.spacer().sizing(Sizing.fixed(18)))
                                        .child(Components.spacer().sizing(Sizing.fixed(4)))
                                        .child(Containers.verticalFlow(Sizing.content(), Sizing.content())
                                                        .child(
                                                                Containers.verticalFlow(Sizing.content(), Sizing.content())
                                                                        .child(this.slotAsComponent(offHandIndex).margins(Insets.of(1)))
                                                        )
                                                        .zIndex(10)
                                        )
                        )
                        .child(
                                Containers.verticalFlow(Sizing.content(), Sizing.content())
                                        .configure((FlowLayout component) -> {
                                            if (!this.sideBarCraftingSpot() && this.showCraftingGrid()) {
                                                component.margins(Insets.left(3));
                                                component.child(createCraftingGrid());
                                            }
                                        })
                                        .id("crafting_grid_layout")
                        )
                        .padding(Insets.of(6))
                        .surface((ctx, component) -> {
                            var showCraftingGrid = !this.sideBarCraftingSpot() && this.showCraftingGrid();

                            var width = showCraftingGrid ? 234 : 195;

                            ctx.method_25293(
                                    Accessories.of("textures/gui/theme/" + ComponentUtils.checkMode("light", "dark") + "/player_inv/" + (showCraftingGrid ? "with" : "without") + "_crafting.png"),
                                    component.x(),
                                    component.y(),
                                    component.width(),
                                    component.height(),
                                    0,
                                    0,
                                    width,
                                    88,
                                    width,
                                    88
                            );
                        })
                        .id("bottom_inventory_section")
        );


        //--

        var armorAndEntityLayout = (FlowLayout) Containers.horizontalFlow(Sizing.content(), Sizing.fixed(138))
                .gap(2)
                .horizontalAlignment(HorizontalAlignment.CENTER)
                .id("armor_entity_layout");

        {
            var armorSlotsLayout = Containers.verticalFlow(Sizing.content(), Sizing.content())
                    .configure((FlowLayout layout) -> layout.allowOverflow(true));

            var outerLeftArmorLayout = Containers.horizontalFlow(Sizing.content(), Sizing.content())
                    .child(armorSlotsLayout);

            var cosmeticArmorSlotsLayout = Containers.verticalFlow(Sizing.content(), Sizing.content())
                            .configure((FlowLayout layout) -> layout.allowOverflow(true));

            var outerRightArmorLayout = Containers.horizontalFlow(Sizing.content(), Sizing.content())
                    .child(cosmeticArmorSlotsLayout);

            for (int i = 0; i < menu.addedArmorSlots() / 2; i++) {
                var armor = menu.startingAccessoriesSlot() + (i * 2);
                var cosmeticArmor = armor + 1;

                this.enableSlot(armor);
                this.enableSlot(cosmeticArmor);

                armorSlotsLayout.child(this.slotAsComponent(armor).margins(Insets.of(1)));
                cosmeticArmorSlotsLayout.child(ComponentUtils.slotAndToggle((AccessoriesBasedSlot) this.field_2797.field_7761.get(cosmeticArmor), false, this::slotAsComponent).left());
            }

            //--

            var entityComponentSize = 126;

            var entityContainer = Containers.stack(Sizing.content(), Sizing.fixed(entityComponentSize + 12))
                    .child(
                            Containers.verticalFlow(Sizing.content(), Sizing.content())
                                    .child(
                                            InventoryEntityComponent.of(Sizing.fixed(entityComponentSize), Sizing.fixed(108), this.method_17577().targetEntityDefaulted())
                                                    .renderWrapping((ctx, component, renderCall) -> {
                                                        AccessoriesScreenBase.SCISSOR_BOX.set(component.x(), component.y(), component.x() + component.width(), component.y() + component.height());

                                                        AccessoriesScreenBase.togglePositionCollection();

                                                        AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.setValue(true);
                                                        AccessoriesScreenBase.IS_RENDERING_LINE_TARGET.setValue(true);

                                                        renderCall.run();

                                                        AccessoriesScreenBase.IS_RENDERING_LINE_TARGET.setValue(false);
                                                        AccessoriesScreenBase.IS_RENDERING_UI_ENTITY.setValue(false);

                                                        AccessoriesScreenBase.COLLECT_ACCESSORY_POSITIONS.setValue(false);

                                                        //AccessoriesScreenBase.SCISSOR_BOX.set(0, 0, 0, 0);
                                                    })
                                                    .startingRotation(this.mainWidgetPosition() ? -45 : 45)
                                                    .scaleToFit(true)
                                                    .allowMouseRotation(true)
                                                    .lookAtCursor(Accessories.config().screenOptions.entityLooksAtMouseCursor())
                                                    .id("entity_rendering_component")
                                    )
                    )
                    .child(
                            outerLeftArmorLayout
                                    .configure((FlowLayout component) -> component.mouseScroll().subscribe((mouseX, mouseY, amount) -> true))
                                    .padding(Insets.of(6))
                                    .margins(Insets.left(-6))
                                    .positioning(Positioning.relative(0, 40))
                                    .zIndex(200) // 140
                    )
                    .child(
                            outerRightArmorLayout
                                    .configure((FlowLayout component) -> component.mouseScroll().subscribe((mouseX, mouseY, amount) -> true))
                                    .padding(Insets.of(6))
                                    .margins(Insets.right(-6))
                                    .positioning(Positioning.relative(100, 40))
                                    .zIndex(200) // 140
                    )
                    .child(
                            Components.button(class_2561.method_43470(""), (btn) -> this.switchToBaseInventory())
                                    .renderer((context, btn, delta) -> {
                                        ComponentUtils.getButtonRenderer().draw(context, btn, delta);

                                        context.push();

                                        var BACK_ICON = Accessories.config().screenOptions.isDarkMode()
                                                ? Accessories.of("widget/back_dark")
                                                : Accessories.of("widget/back");

                                        var sprites = field_22787.method_52699();

                                        class_1058 textureAtlasSprite = sprites.method_18667(BACK_ICON);

                                        var width = Math.min(textureAtlasSprite.method_45851().method_45807(), 8);
                                        var height = Math.min(textureAtlasSprite.method_45851().method_45815(), 8);

                                        context.method_52706(BACK_ICON, btn.x() + 1, btn.y() + 1, width, height);

                                        context.pop();
                                    })
                                    .tooltip(class_2561.method_43471(Accessories.translationKey("back.screen")))
                                    .positioning(Positioning.relative(100, 0))
                                    .margins(Insets.of(1, 0, 0, 1))
                                    .sizing(Sizing.fixed(10))
                    )
                    .padding(Insets.of(6))
                    .surface((ctx, component) -> {
                        var surfaceType = this.getMenu().addedArmorSlots() > 4 ? "full_armor" : "single_armor" + (this.getMenu().includeSaddle() ? "_saddled" : "");

                        ctx.blit(
                                Accessories.of("textures/gui/theme/" + ComponentUtils.checkMode("light", "dark") + "/entity_view/" + surfaceType + ".png"),
                                component.x(),
                                component.y(),
                                component.width(),
                                component.height(),
                                0,
                                0,
                                120,
                                138,
                                120,
                                138
                                );
                    });

            if(this.method_17577().includeSaddle()) {
                var saddleIndex = this.method_17577().startingAccessoriesSlot() - 1;

                this.enableSlot(saddleIndex);

                ((StackLayout) entityContainer).child(
                        Containers.verticalFlow(Sizing.content(), Sizing.content())
                                .child(
                                        Containers.verticalFlow(Sizing.content(), Sizing.content())
                                                .child(
                                                        this.slotAsComponent(saddleIndex)
                                                                .margins(Insets.of(1))
                                                )
                                )
                                .padding(Insets.of(6))
                                .positioning(Positioning.relative(0, 100))
                                .margins(Insets.of(0, -6, -6, 0))
                                .zIndex(10)
                        );
            }

            armorAndEntityLayout.child(entityContainer);
        }

        baseChildren.add(armorAndEntityLayout);

        if(accessoriesComponent != null) {
            armorAndEntityLayout.child((this.mainWidgetPosition() ? 0 : 1), accessoriesComponent); //1,
        }

        if(accessoriesComponent != null || !this.method_17577().selectedGroups().isEmpty()) {
            var sideBarHolder = createSideBarOptions();

            if (this.sideWidgetPosition() == this.mainWidgetPosition()) {
                armorAndEntityLayout.child(0, sideBarHolder);
            } else {
                armorAndEntityLayout.child(sideBarHolder);
            }
        }

        //--

        var baseLayout = Containers.verticalFlow(Sizing.content(), Sizing.content())
                .gap(2)
                .children(baseChildren.reversed());

        baseLayout.horizontalAlignment(HorizontalAlignment.CENTER)
                .verticalAlignment(VerticalAlignment.CENTER)
                .positioning(Positioning.relative(50, 50));

        //--

        rootComponent.child(baseLayout);
    }

    @Nullable
    private AccessoriesContainingComponent topComponent = null;

    public void rebuildAccessoriesComponent() {
        var columnAmountSlider = this.uiAdapter.rootComponent.childById(DiscreteSliderComponent.class, "column_amount_slider");

        if(columnAmountSlider != null) {
            var previousValue = columnAmountSlider.discreteValue();

            var newMinimum = getMinimumColumnAmount();

            ((DiscreteSliderComponentAccessor) columnAmountSlider).accessories$setMin(newMinimum);

            var newValue = Math.max((int) Math.round(previousValue), newMinimum);

            columnAmountSlider.setFromDiscreteValue(newValue);

            ((DiscreteSliderComponentAccessor) columnAmountSlider).accessories$updateMessage();

            this.columnAmount(newValue);
        }

        this.method_17577().getAccessoriesSlots().forEach(this::disableSlot);

        //--

        var armorAndEntityComp = this.uiAdapter.rootComponent.childById(FlowLayout.class, "armor_entity_layout");

        for (var child : List.copyOf(armorAndEntityComp.children())) {
            if (AccessoriesContainingComponent.defaultID().equals(child.id()) && child instanceof AccessoriesContainingComponent accessories) {
                var parent = accessories.parent();

                if (parent != null) {
                    ComponentUtils.recursiveSearch(parent, ExtendedSlotComponent.class, slotComponent -> this.hideSlot(slotComponent.slot()));

                    parent.removeChild(accessories);
                }
            }
        }

        var accessoriesComp = createAccessoriesComponent();

        if (accessoriesComp != null) {
            if(this.mainWidgetPosition()) {
                armorAndEntityComp.child(0, accessoriesComp);
            } else {
                armorAndEntityComp.child(accessoriesComp);
            }

            swapOrCreateSideBarComponent();
        } else {
            if(this.method_17577().selectedGroups().isEmpty()) {
                var sideBarOptionsComponent = armorAndEntityComp.childById(io.wispforest.owo.ui.core.Component.class, "accessories_toggle_panel");

                if (sideBarOptionsComponent != null) {
                    var parent = sideBarOptionsComponent.parent();

                    if (parent != null) parent.removeChild(sideBarOptionsComponent);
                }
            } else {
                swapOrCreateSideBarComponent();
            }
        }

        toggleCraftingGrid();
    }

    public void swapOrCreateSideBarComponent() {
        if (this.topComponent == null && this.method_17577().selectedGroups().isEmpty()) return;

        var armorAndEntityComp = this.uiAdapter.rootComponent.childById(FlowLayout.class, "armor_entity_layout");

        var sideBarHolder = armorAndEntityComp.childById(FlowLayout.class, "side_bar_holder");

        armorAndEntityComp.removeChild(sideBarHolder);

        sideBarHolder = createSideBarOptions();

        if (this.sideWidgetPosition() == this.mainWidgetPosition()) {
            armorAndEntityComp.child(0, sideBarHolder);
        } else {
            armorAndEntityComp.child(sideBarHolder);
        }
    }

    private int getMinimumColumnAmount() {
        return (this.widgetType() == 2) ? 1 : 3;
    }

    @Nullable
    private AccessoriesContainingComponent createAccessoriesComponent() {
        this.topComponent = (this.widgetType() == 2)
                ? ScrollableAccessoriesComponent.createOrNull(this)
                : GriddedAccessoriesComponent.createOrNull(this);

        return this.topComponent;
    }

    private FlowLayout createSideBarOptions() {
        var cosmeticToggleButton = Components.button(class_2561.method_43470(""), btn -> {
                    showCosmeticState(!showCosmeticState());

                    btn.tooltip(createToggleTooltip("slot_cosmetics", false, showCosmeticState()));

                    var component = this.uiAdapter.rootComponent.childById(AccessoriesContainingComponent.class, AccessoriesContainingComponent.defaultID());

                    if(component != null) component.onCosmeticToggle(showCosmeticState());
                }).renderer((context, button, delta) -> {
                    ComponentUtils.getButtonRenderer().draw(context, button, delta);

                    var texture = !showCosmeticState()
                            ? Accessories.of("textures/gui/theme/cosmetic_rainbow_icon.png")
                            : Accessories.of("textures/gui/theme/" + (Accessories.config().screenOptions.isDarkMode() ? "dark" : "light") + "/charm_icon.png");

                    context.method_25293(texture, button.x() + 2, button.y() + 2, 16, 16, 0, 0, 32, 32, 32, 32);
                }).sizing(Sizing.fixed(20))
                .tooltip(createToggleTooltip("slot_cosmetics", false, showCosmeticState()));

        var accessoriesTogglePanel = (FlowLayout) Containers.verticalFlow(Sizing.content(), Sizing.content())
                .child(cosmeticToggleButton.margins(Insets.of(2, 2, 2, 2)))
                .gap(1)
                .padding(Insets.of(6))
                .surface((ctx, component) -> {
                    if(component.children().size() > 1) {
                        ComponentUtils.getPanelSurface().and(ComponentUtils.getPanelWithInset(6))
                                .draw(ctx, component);
                    } else {
                        ctx.method_25293(
                                Accessories.of("textures/gui/theme/" + ComponentUtils.checkMode("light", "dark") + "/toggle_background.png"),
                                component.x(),
                                component.y(),
                                component.width(),
                                component.height(),
                                0,
                                0,
                                36,
                                36,
                                36,
                                36
                        );
                    }
                })
                .horizontalAlignment(HorizontalAlignment.CENTER)
                .id("accessories_toggle_panel");

        var groupFilterComponent = createGroupFilters();

        if(groupFilterComponent != null) accessoriesTogglePanel.child(groupFilterComponent);

        return (FlowLayout) Containers.verticalFlow(Sizing.content(), Sizing.content())
                .child(accessoriesTogglePanel)
                .configure((FlowLayout component) -> {
                    if (this.sideBarCraftingSpot() && this.showCraftingGrid()) {
                        component.child(createCraftingGrid());
                    }
                })
                .horizontalAlignment(this.mainWidgetPosition() ? HorizontalAlignment.LEFT : HorizontalAlignment.RIGHT)
                .id("side_bar_holder");
    }

    @Nullable
    private io.wispforest.owo.ui.core.Component baseFilterLayout = null;

    @Nullable
    private io.wispforest.owo.ui.core.Component createGroupFilters() {
        if (!this.showGroupFilters()) return null;

        var groups = new ArrayList<>(SlotGroupLoader.getValidGroups(this.method_17577().targetEntityDefaulted()).keySet());

        var usedSlots = this.method_17577().getUsedSlots();

        if (groups.isEmpty()) return null;

        var groupButtons = groups.stream()
                .map(group -> {
                    var groupSlots = group.slots()
                            .stream()
                            .filter(slotName -> !UniqueSlotHandling.isUniqueSlot(slotName))
                            .map(slotName -> SlotTypeLoader.getSlotType(this.targetEntityDefaulted(), slotName))
                            .filter(Objects::nonNull)
                            .filter(slotType -> {
                                var capability = this.targetEntityDefaulted().accessoriesCapability();

                                if (capability == null) return false;

                                var container = capability.getContainer(slotType);

                                if (container == null) return false;

                                return container.getSize() > 0;
                            })
                            .collect(Collectors.toSet());

                    if (groupSlots.isEmpty() || (usedSlots != null && groupSlots.stream().noneMatch(usedSlots::contains))) return null;

                    return ComponentUtils.groupToggleBtn(this, group);
                })
                .filter(Objects::nonNull)
                .toList();

        if (groupButtons.isEmpty()) return null;

        var baseButtonLayout = (ParentComponent) Containers.verticalFlow(Sizing.content(), Sizing.content())
                .children(groupButtons)
                .gap(1);

        if(groupButtons.size() > 5) {
            baseButtonLayout = new ExtendedScrollContainer<>(
                    ScrollContainer.ScrollDirection.VERTICAL,
                    Sizing.fixed(18 + 6),
                    Sizing.fixed((5 * 14) + (5) + (2 * 2) - 1),
                    baseButtonLayout.padding(!this.mainWidgetPosition() ? Insets.of(2, 2, 1, 1) : Insets.of(2, 2, 2, 0))
            ).oppositeScrollbar(this.sideWidgetPosition() == this.mainWidgetPosition())
                    .customClippingInsets(Insets.of(1))
                    .scrollToAfterLayout((this.baseFilterLayout instanceof ExtendedScrollContainer<?> prevContainer) ? prevContainer.getProgress() : 0.0f)
                    .scrollbarThiccness(7)
                    .scrollbar(ComponentUtils.getScrollbarRenderer())
                    .fixedScrollbarLength(16);
        } else {
            baseButtonLayout.margins(Insets.bottom(2));
        }

        this.baseFilterLayout = baseButtonLayout;

        return new ExtendedCollapsibleContainer(Sizing.content(), Sizing.content(), this.isGroupFiltersOpen())
                .configure((ExtendedCollapsibleContainer component) -> {
                    component.onToggled().subscribe(b -> {
                        AccessoriesNetworking
                                .sendToServer(SyncHolderChange.of(HolderProperty.GROUP_FILTER_OPEN_PROP, b));

                        this.isGroupFiltersOpen(b);
                    });
                })
                .child(
                        Components.button(class_2561.method_43473(), btn -> {
                                    this.method_17577().selectedGroups().clear();
                                    this.rebuildAccessoriesComponent();
                                }).renderer((context, button, delta) -> {
                                    ComponentUtils.getButtonRenderer().draw(context, button, delta);

                                    RenderSystem.depthMask(false);

                                    var color = Color.WHITE;

                                    RenderSystem.setShaderColor(color.red(), color.green(), color.blue(), 1f);
                                    RenderSystem.enableBlend();
                                    RenderSystem.blendFunc(GlStateManager.class_4535.ONE, GlStateManager.class_4534.ONE);

                                    context.method_25291(Accessories.of("textures/gui/reset_icon.png"), button.x() + 3 + 3, button.y() + 3, 0, 0, 0, 8, 8, 8, 8);

                                    RenderSystem.depthMask(true);
                                    RenderSystem.disableBlend();
                                }).sizing(Sizing.fixed(14))
                                .horizontalSizing(Sizing.fixed(20))
                                .margins(Insets.bottom(1))
                                .tooltip(class_2561.method_43471(Accessories.translationKey("reset.group_filter")))
                )
                .child(baseButtonLayout)
                .id("group_filter_component");
    }

    private void swapBottomComponentHolder() {
        var holder = this.uiAdapter.rootComponent.childById(FlowLayout.class, "bottom_component_holder");

        holder.clearChildren();

        if(this.showAdvancedOptions()) {
            for (int i = 0; i < field_2797.startingAccessoriesSlot() - (this.method_17577().includeSaddle() ? 2 : 1); i++) this.disableSlot(i);

            holder.child(createOptionsComponent());
        } else {
            holder.child(ComponentUtils.createPlayerInv(5, field_2797.startingAccessoriesSlot(), this::slotAsComponent, this::enableSlot));
        }
    }

    private void toggleCraftingGrid() {
        this.removeCraftingGrid();

        if (!this.showCraftingGrid()) return;

        var bottom_holder = this.uiAdapter.rootComponent.childById(FlowLayout.class, "crafting_grid_layout");//side_bar_holder
        var side_holder = this.uiAdapter.rootComponent.childById(FlowLayout.class, "side_bar_holder");

        if (sideBarCraftingSpot()) {
            side_holder.child(createCraftingGrid());
        } else {
            bottom_holder.margins(Insets.left(3));

            bottom_holder.child(createCraftingGrid());
        }
    }

    private void removeCraftingGrid() {
        var bottom_holder = this.uiAdapter.rootComponent.childById(FlowLayout.class, "crafting_grid_layout");//side_bar_holder
        var side_holder = this.uiAdapter.rootComponent.childById(FlowLayout.class, "side_bar_holder");

        if (bottom_holder != null) {
            bottom_holder.clearChildren();
        }

        if (side_holder != null) {
            var craftingComponent = side_holder.childById(io.wispforest.owo.ui.core.Component.class, "crafting_component");

            if(craftingComponent != null) side_holder.removeChild(craftingComponent);
        }

        if (!this.showCraftingGrid()) {
            bottom_holder.margins(Insets.of(0));

            this.disableSlots(0, 1, 2, 3, 4);
        }
    }

    private boolean sideBarCraftingSpot() {
        return !this.showGroupFilters() && Accessories.config().screenOptions.allowSideBarCraftingGrid() && this.topComponent != null;
    }

    private io.wispforest.owo.ui.core.Component createCraftingGrid() {
        var component = ComponentUtils.createCraftingComponent(0, 4, this::slotAsComponent, this::enableSlot, true);

        if (sideBarCraftingSpot()) {
            component = Containers.verticalFlow(Sizing.content(), Sizing.expand())
                    .child(Containers.verticalFlow(Sizing.content(), Sizing.expand()))
                    .child(
                            Containers.verticalFlow(Sizing.content(), Sizing.content())
                                    .child(component)
                                    .surface(
                                            (ctx, component1) -> {
                                                ctx.method_25293(
                                                        Accessories.of("textures/gui/theme/" + ComponentUtils.checkMode("light", "dark") + "/crafting_grid.png"),
                                                        component1.x(),
                                                        component1.y(),
                                                        component1.width(),
                                                        component1.height(),
                                                        0,
                                                        0,
                                                        44,
                                                        88,
                                                        44,
                                                        88
                                                );
                                            }
                                    )
                                    .padding(Insets.of(6))
                    );
        }

        return component.id("crafting_component");
    }

    private io.wispforest.owo.ui.core.Component createOptionsComponent() {
        var baseOptionPanel = Containers.grid(Sizing.fixed(162), Sizing.content(), 5, 2)
                .configure((GridLayout component) -> {
                    component.surface(ComponentUtils.getInsetPanelSurface())
                            .verticalAlignment(VerticalAlignment.CENTER)
                            .horizontalAlignment(HorizontalAlignment.CENTER)
                            .padding(Insets.of(3));
                });

        //--

        baseOptionPanel.child(
                createConfigComponent("unused_slots",
                        this::showUnusedSlots,
                        bl -> AccessoriesNetworking.sendToServer(SyncHolderChange.of(HolderProperty.UNUSED_PROP, bl))
                ).margins(Insets.bottom(3)),
                0, 0);

        baseOptionPanel.child(
                Containers.verticalFlow(Sizing.content(), Sizing.content())
                        .child(Components.label(Accessories.translation("column_amount_slider.label")))
                        .child(Components.discreteSlider(Sizing.fixed(45), getMinimumColumnAmount(), 18)
                                .configure((DiscreteSliderComponent slider) -> {
                                    slider.onChanged().subscribe(value -> {
                                        AccessoriesNetworking
                                                .sendToServer(SyncHolderChange.of(HolderProperty.COLUMN_AMOUNT_PROP, (int) value));

                                        this.columnAmount((int) value);

                                        rebuildAccessoriesComponent();
                                    });
                                })
                                .snap(true)
                                .setFromDiscreteValue(this.columnAmount())
                                .scrollStep(1f / (18 - getMinimumColumnAmount()))
                                .tooltip(Accessories.translation("column_amount_slider.tooltip"))
                                .id("column_amount_slider")
                                .horizontalSizing(Sizing.fixed(74))
                        )
                        .margins(Insets.bottom(3)),
                0, 1);

        baseOptionPanel.child(
                Containers.verticalFlow(Sizing.content(), Sizing.content())
                        .child(Components.label(Accessories.translation("widget_type.label")))
                        .child(
                                Components.button(
                                        widgetTypeToggleMessage(this.widgetType(), false),
                                        btn -> {
                                            var newWidget = this.widgetType() + 1;

                                            if(newWidget > 2) newWidget = 1;

                                            AccessoriesNetworking
                                                    .sendToServer(SyncHolderChange.of(HolderProperty.WIDGET_TYPE_PROP, newWidget));

                                            this.widgetType(newWidget);

                                            updateWidgetTypeToggleButton();
                                        })
                                        .renderer(ComponentUtils.getButtonRenderer())
                                        .tooltip(widgetTypeToggleMessage(this.widgetType(), true))
                                        .id("widget_type_toggle")
                                        .horizontalSizing(Sizing.fixed(74))
                        ).margins(Insets.bottom(3)),
                1, 0);

        baseOptionPanel.child(
                createConfigComponent("main_widget_position",
                        this::mainWidgetPosition,
                        bl -> {
                            AccessoriesNetworking
                                    .sendToServer(SyncHolderChange.of(HolderProperty.MAIN_WIDGET_POSITION_PROP, bl));

                            this.mainWidgetPosition(bl);

                            this.uiAdapter.rootComponent.childById(InventoryEntityComponent.class, "entity_rendering_component")
                                    .startingRotation(this.mainWidgetPosition() ? -45 : 45);
                        }
                ).margins(Insets.bottom(3)),
                1, 1);

        baseOptionPanel.child(
                createConfigComponent("group_filter",
                        this::showGroupFilters,
                        bl -> {
                            AccessoriesNetworking.sendToServer(SyncHolderChange.of(HolderProperty.GROUP_FILTER_PROP, bl));

                            this.showGroupFilters(bl);

                            if(this.showGroupFilters()) {
                                var panel = this.uiAdapter.rootComponent.childById(FlowLayout.class, "accessories_toggle_panel");

                                if(panel != null) {
                                    var groupFilter = createGroupFilters();

                                    if (groupFilter != null) panel.child(groupFilter);
                                }
                            } else {
                                var component = this.uiAdapter.rootComponent.childById(io.wispforest.owo.ui.core.Component.class, "group_filter_component");

                                if (component != null) component.remove();
                            }

                            this.toggleCraftingGrid();
                        }
                ).margins(Insets.bottom(3)),
                2, 0);

        baseOptionPanel.child(
                createConfigComponent("side_widget_position",
                        this::sideWidgetPosition,
                        bl -> {
                            AccessoriesNetworking
                                    .sendToServer(SyncHolderChange.of(HolderProperty.SIDE_WIDGET_POSITION_PROP, bl));

                            this.sideWidgetPosition(bl);

                            this.swapOrCreateSideBarComponent();
                        }
                ).margins(Insets.bottom(3)),
                2, 1);

        baseOptionPanel.child(
                createConfigComponent("dark_mode_toggle",
                        () -> Accessories.config().screenOptions.isDarkMode(),
                        bl -> Accessories.config().screenOptions.isDarkMode(bl)
                ),
                3, 0);

        baseOptionPanel.child(
                createConfigComponent("show_equipped_stack_slot_type",
                        () -> Accessories.config().screenOptions.showEquippedStackSlotType(),
                        bl -> Accessories.config().screenOptions.showEquippedStackSlotType(bl)
                ),
                3, 1);

        baseOptionPanel.child(
                createConfigComponent("entity_look_at_cursor",
                        () -> Accessories.config().screenOptions.entityLooksAtMouseCursor(),
                        bl -> {
                            Accessories.config().screenOptions.entityLooksAtMouseCursor(bl);

                            var component = this.uiAdapter.rootComponent.childById(InventoryEntityComponent.class, "entity_rendering_component");

                            component.lookAtCursor(bl);
                        }
                ),
                4, 0);

        return Containers.verticalScroll(Sizing.expand(), Sizing.expand(), baseOptionPanel);
    }

    private io.wispforest.owo.ui.core.Component createConfigComponent(String type, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        return Containers.verticalFlow(Sizing.content(), Sizing.content())
                .child(Components.label(Accessories.translation(type + ".label")))
                .child(
                        Components.button(
                                        createToggleTooltip(type, false, getter.get()),
                                        btn -> {
                                            var newValue = !getter.get();

                                            setter.accept(newValue);

                                            btn.method_25355(createToggleTooltip(type, false, newValue));
                                            btn.tooltip(createToggleTooltip(type, true, newValue));
                                        })
                                .renderer(ComponentUtils.getButtonRenderer())
                                .tooltip(createToggleTooltip(type, true, getter.get()))
                                .id(type)
                                .horizontalSizing(Sizing.fixed(74))
                );
    }

    @Override
    public void onHolderChange(String key) {
        switch (key) {
            case "unused_slots" -> updateToggleButton("unused_slots", this::showUnusedSlots, () -> {
                this.method_17577().updateUsedSlots();

                Accessories.config().screenOptions.showUnusedSlots(this.showUnusedSlots());

                this.rebuildAccessoriesComponent();
            });
            case "group_filter" -> updateToggleButton("group_filter", this::showGroupFilters, this::rebuildAccessoriesComponent);
            case "main_widget_position" -> updateToggleButton("main_widget_position", this::mainWidgetPosition, () -> {
                this.rebuildAccessoriesComponent();
                this.swapOrCreateSideBarComponent();
            });
            case "side_widget_position" -> updateToggleButton("side_widget_position", this::sideWidgetPosition, this::swapOrCreateSideBarComponent);
        }
    }

    private void updateToggleButton(String baseId, Supplier<Boolean> getter, Runnable runnable) {
        var btn = this.uiAdapter.rootComponent.childById(ButtonComponent.class, baseId);

        var value = getter.get();

        btn.method_25355(createToggleTooltip(baseId, false, value));
        btn.tooltip(createToggleTooltip(baseId, true, value));

        runnable.run();
    }

    private void updateWidgetTypeToggleButton() {
        var btn = this.uiAdapter.rootComponent.childById(ButtonComponent.class, "widget_type_toggle");

        var value = this.widgetType();

        btn.method_25355(widgetTypeToggleMessage(value, false));
        btn.tooltip(widgetTypeToggleMessage(value, true));

        this.rebuildAccessoriesComponent();
    }

    private static class_2561 widgetTypeToggleMessage(int value, boolean isTooltip) {
        var type = value == 2 ? "scrollable" : "paginated";

        return Accessories.translation("widget_type." + type + (isTooltip ? ".tooltip" : ""));
    }

    private static class_2561 createToggleTooltip(String type, boolean isTooltip, boolean value) {
        return Accessories.translation(type + ".toggle." + (value ? "enabled" : "disabled") + (isTooltip ? ".tooltip" : ""));
    }

    //--

    public ExtendedSlotComponent slotAsComponent(int index) {
        return new ExtendedSlotComponent(this, index);
    }

    public class ExtendedSlotComponent extends SlotComponent {

        private boolean isBatched = false;

        protected final AccessoriesExperimentalScreen screen;
        protected int index;

        protected ExtendedSlotComponent(AccessoriesExperimentalScreen screen, int index) {
            super(index);

            this.screen = screen;
            this.index = index;

            this.didDraw = true;

            if (slot() instanceof AccessoriesBasedSlot accessoriesBasedSlot) {
                this.tooltip(accessoriesBasedSlot.getTooltipData());
            }
        }

        public final class_1735 slot() {
            return this.slot;
        }

        public final boolean isBatched() {
            return this.isBatched;
        }

        public ExtendedSlotComponent isBatched(boolean value) {
            this.isBatched = value;

            return this;
        }

        @Override
        public void dismount(DismountReason reason) {
            super.dismount(reason);

            if (reason == DismountReason.REMOVED) screen.hideSlot(slot);
        }

        @Override
        public void draw(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
            if (!(slot() instanceof SlotTypeAccessible)) {
                super.draw(context, mouseX, mouseY, partialTicks, delta);

                return;
            }

            this.didDraw = true;

            if (isBatched) return;

            RenderSystem.enableDepthTest();
            RenderSystem.enableBlend();

            renderSlot(context);

            renderCosmeticOverlay(context, false);

            renderHover(context, () -> screen.field_2787);
        }

        public void renderSlot(OwoUIDrawContext context) {
            int i = screen.field_2776;
            int j = screen.field_2800;

            context.push();
            context.translate((float) i, (float) j, 0);

            screen.forceRenderSlot(context, slot());

            context.pop();
        }

        public void renderCosmeticOverlay(OwoUIDrawContext context, boolean externalBatching) {
            if (!(slot() instanceof SlotTypeAccessible slotTypeAccessible) || !slotTypeAccessible.isCosmeticSlot())
                return;

            context.push();
            context.translate(0.0F, 0.0F, 101.0F);

            if (externalBatching) {
                GuiGraphicsUtils.drawRectOutlineWithSpectrumWithoutRecord(context, this.x(), this.y(), 0, 16, 16, 0.35f, true);
            } else {
                GuiGraphicsUtils.drawRectOutlineWithSpectrum(context, this.x(), this.y(), 0, 16, 16, 0.35f, true);
            }

            context.pop();
        }

        public void renderHover(OwoUIDrawContext context, Supplier<class_1735> hoverSlot) {
            var hoveredSlot = hoverSlot.get();

            if (this.slot.equals(hoveredSlot) && hoveredSlot.method_51306()) {
                context.push();

                context.method_51740(class_1921.method_51784(), x(), y(), x() + 16, y() + 16, -2130706433, -2130706433, 330);

                context.pop();
            }
        }

        @Override
        public void drawTooltip(OwoUIDrawContext context, int mouseX, int mouseY, float partialTicks, float delta) {
            RenderSystem.enableDepthTest();
            context.push().translate(0, 0, 300);

            AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(AccessoriesExperimentalScreen.this.mainWidgetPosition());
            super.drawTooltip(context, mouseX, mouseY, partialTicks, delta);
            AccessoriesScreenBase.FORCE_TOOLTIP_LEFT.setValue(false);
            context.pop();
        }
    }

    //--
    // Below is a copy of minecraft code for rendering slots and items stacks in a batched method for performance

    private final Surface SLOT_RENDERING_SURFACE = (context, component) -> {
        var validComponents = new ArrayList<ExtendedSlotComponent>();

        ComponentUtils.recursiveSearch(component, AccessoriesExperimentalScreen.ExtendedSlotComponent.class, slotComponent -> {
            if(!slotComponent.isBatched() || !(slotComponent.slot() instanceof SlotTypeAccessible)) return;

            validComponents.add(slotComponent);
        });

        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();

        context.push();
        context.translate(0, 0, 100.0F);

        //--

        Map<class_1735, Triplet<class_1799, Boolean, @Nullable String>> slotStateData = new HashMap<>();
        Map<class_1735, Boolean> allBl2s = new HashMap<>();

        //--

        var accessor = (AbstractContainerScreenAccessor) this;

        //--

        int i = this.field_2776;
        int j = this.field_2800;

        context.push();
        context.translate(i, j, 0);

        safeBatching(context, hasDrawCallOccur -> {
            for (var slotComponent : validComponents) {
                var slot = slotComponent.slot();

                var data = slotStateData.computeIfAbsent(slot, this::getRenderStack);

                if (data == null) continue;

                allBl2s.put(slot, renderSlotTexture(context, slot, data.getA()));

                hasDrawCallOccur.setValue(true);
            }
        });

        //--

        safeBatching(context, hasDrawCallOccur -> {
            for (var slotComponent : validComponents) {
                var slot = slotComponent.slot();

                var data = slotStateData.computeIfAbsent(slot, this::getRenderStack);

                if (data == null) return;

                var itemStack = data.getA();

                var bl2 = allBl2s.getOrDefault(slot, false)
                        || (slot == accessor.accessories$getClickedSlot() && !accessor.accessories$getDraggingItem().method_7960() && !accessor.accessories$isSplittingStack());

                if (!bl2) {
                    int slotX = slot.field_7873;
                    int slotY = slot.field_7872;

                    if (data.getB()) {
                        context.method_25294(slotX, slotY, slotX + 16, slotY + 16, -2130706433);
                    }

                    int k = slot.field_7873 + slot.field_7872 * this.field_2792;

                    if (slot.method_55059()) {
                        context.method_55231(itemStack, slotX, slotY, k);
                    } else {
                        context.method_51428(itemStack, slotX, slotY, k);
                    }

                    context.method_51432(this.field_22793, itemStack, slotX, slotY, data.getC());
                }

                hasDrawCallOccur.setValue(true);
            }
        });

        context.pop();

        safeBatching(context, hasDrawCallOccur -> {
            for (var slotComponent : validComponents) {
                slotComponent.renderCosmeticOverlay(context, true);

                hasDrawCallOccur.setValue(true);
            }
        });

        context.pop();

        validComponents.forEach(slotComponent -> slotComponent.renderHover(context, () -> this.field_2787));
    };

    private static boolean renderSlotTexture(class_332 context, class_1735 slot, class_1799 itemStack) {
        if (itemStack.method_7960() /*&& slot.isActive()*/) {
            com.mojang.datafixers.util.Pair<class_2960, class_2960> pair = slot.method_7679();

            if (pair != null) {
                class_1058 textureAtlasSprite = class_310.method_1551().method_1549(pair.getFirst()).apply(pair.getSecond());

                context.method_25298(slot.field_7873, slot.field_7872, 0, 16, 16, textureAtlasSprite);

                return true;
            }
        }

        return false;
    }

    public final Surface FULL_SLOT_RENDERING = BACKGROUND_SLOT_RENDERING_SURFACE.and(SLOT_RENDERING_SURFACE);

    //--

    @Nullable
    private Triplet<class_1799, Boolean, @Nullable String> getRenderStack(class_1735 slot) {
        var accessor = (AbstractContainerScreenAccessor) this;

        var itemStack = slot.method_7677();

        var bl = false;

        var itemStack2 = this.field_2797.method_34255();

        String string = null;

        if (slot == accessor.accessories$getClickedSlot() && !accessor.accessories$getDraggingItem().method_7960() && accessor.accessories$isSplittingStack() && !itemStack.method_7960()) {
            itemStack = itemStack.method_46651(itemStack.method_7947() / 2);
        } else if (this.field_2794 && this.field_2793.contains(slot) && !itemStack2.method_7960()) {
            if (this.field_2793.size() == 1) return null;

            if (class_1703.method_7592(slot, itemStack2, true) && this.field_2797.method_7615(slot)) {
                bl = true;

                int maxSlotStackSize = Math.min(itemStack2.method_7914(), slot.method_7676(itemStack2));
                int currentSlotStackSize = slot.method_7677().method_7960() ? 0 : slot.method_7677().method_7947();

                int newStackSize = class_1703.method_7617(this.field_2793, accessor.accessories$getQuickCraftingType(), itemStack2) + currentSlotStackSize;

                if (newStackSize > maxSlotStackSize) {
                    newStackSize = maxSlotStackSize;
                    string = class_124.field_1054.toString() + maxSlotStackSize;
                }

                itemStack = itemStack2.method_46651(newStackSize);
            } else {
                this.field_2793.remove(slot);
                accessor.accessories$recalculateQuickCraftRemaining();
            }
        }

        return new Triplet<>(itemStack, bl, string);
    }

    //--

    private <T> T getHolderValue(Function<AccessoriesHolder, T> getter, T defaultValue, String valueType) {
        return Optional.ofNullable(AccessoriesHolder.get(this.field_2797.owner()))
                .map(getter)
                .orElseGet(() -> {
                    LOGGER.warn("[AccessoriesScreen] Unable to get the given holder value '{}' for the given owner: {}", valueType, this.field_2797.owner().method_5477());

                    return defaultValue;
                });
    }

    private <T> void setHolderValue(BiFunction<AccessoriesHolder, T, AccessoriesHolder> setter, T value, String valueType) {
        var holder = AccessoriesHolder.get(this.field_2797.owner());

        if(holder == null) {
            LOGGER.warn("[AccessoriesScreen] Unable to set the given holder value '{}' for the given owner: {}", valueType, this.field_2797.owner().method_5477());

            return;
        }

        setter.apply(holder, value);
    }

    private int widgetType() {
        return this.getHolderValue(AccessoriesHolder::widgetType, 1, "widgetType");
    }

    private void widgetType(int type) {
        this.setHolderValue(AccessoriesHolder::widgetType, type, "widgetType");
    }

    private int columnAmount() {
        return this.getHolderValue(AccessoriesHolder::columnAmount, 1, "columnAmount");
    }

    private void columnAmount(int type) {
        this.setHolderValue(AccessoriesHolder::columnAmount, type, "columnAmount");
    }

    public boolean mainWidgetPosition() {
        return this.getHolderValue(AccessoriesHolder::mainWidgetPosition, false, "mainWidgetPosition");
    }

    private void mainWidgetPosition(boolean value) {
        this.setHolderValue(AccessoriesHolder::mainWidgetPosition, value, "mainWidgetPosition");
    }

    public boolean showGroupFilters() {
        return this.getHolderValue(AccessoriesHolder::showGroupFilter, false, "showGroupFilter");
    }

    private void showGroupFilters(boolean value) {
        this.setHolderValue(AccessoriesHolder::showGroupFilter, value, "showGroupFilter");
    }

    public boolean isGroupFiltersOpen() {
        return this.getHolderValue(AccessoriesHolder::isGroupFiltersOpen, false, "isGroupFiltersOpen");
    }

    private void isGroupFiltersOpen(boolean value) {
        this.setHolderValue(AccessoriesHolder::isGroupFiltersOpen, value, "isGroupFiltersOpen");
    }

    private boolean showUnusedSlots() {
        return this.getHolderValue(AccessoriesHolder::showUnusedSlots, false, "showUnusedSlots");
    }

    private void showUnusedSlots(boolean value) {
        this.setHolderValue(AccessoriesHolder::showUnusedSlots, value, "showUnusedSlots");
    }

    private boolean showAdvancedOptions() {
        return this.getHolderValue(AccessoriesHolder::showAdvancedOptions, false, "showAdvancedOptions");
    }

    private void showAdvancedOptions(boolean value) {
        this.setHolderValue(AccessoriesHolder::showAdvancedOptions, value, "showAdvancedOptions");
    }

    private boolean sideWidgetPosition() {
        return this.getHolderValue(AccessoriesHolder::sideWidgetPosition, false, "sideWidgetPosition");
    }

    private void sideWidgetPosition(boolean value) {
        this.setHolderValue(AccessoriesHolder::sideWidgetPosition, value, "sideWidgetPosition");
    }

    public boolean showCraftingGrid() {
        return this.getHolderValue(AccessoriesHolder::showCraftingGrid, false, "showCraftingGrid");
    }

    public void showCraftingGrid(boolean value) {
        this.setHolderValue(AccessoriesHolder::showCraftingGrid, value, "showCraftingGrid");
    }

    //--

    public static void safeBatching(OwoUIDrawContext context, Consumer<MutableBoolean> drawCallback) {
        context.recordQuads();

        var hasDrawCallOccur = new MutableBoolean(false);

        drawCallback.accept(hasDrawCallOccur);

        try {
            if(hasDrawCallOccur.booleanValue()) context.submitQuads();
        } catch (Exception e) {
            var test = "this is for debugging only really!";
        }
    }
}
