package io.wispforest.accessories.fabric.mixin;

import io.wispforest.accessories.impl.AccessoriesEventHandler;
import io.wispforest.accessories.pond.DroppedStacksExtension;
import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void accessories$tick(CallbackInfo ci){
        AccessoriesEventHandler.onLivingEntityTick((class_1309)(Object)this);
    }

    @Inject(method = "dropAllDeathLoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;dropEquipment()V"))
    private void handleAccessoriesDrop(class_3218 level, class_1282 damageSource, CallbackInfo ci) {
        var entity = (class_1309) (Object) this;
        var droppedStacks = AccessoriesEventHandler.onDeath(entity, damageSource);

        if (droppedStacks == null) return;

        if (this instanceof DroppedStacksExtension playerExtension) {
            playerExtension.addToBeDroppedStacks(droppedStacks);
        } else {
            for (var droppedStack : droppedStacks) {
                entity.method_5775(droppedStack);
            }
        }
    }
}
