package io.wispforest.accessories.fabric.mixin;

import io.wispforest.accessories.fabric.ExtraEntityTrackingEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3231.class)
public abstract class ServerEntityEvent {

    @Shadow @Final private class_1297 entity;

    @Inject(method = "addPairing", at = @At("TAIL"))
    private void onStartTracking(class_3222 player, CallbackInfo ci) {
        ExtraEntityTrackingEvents.POST_START_TRACKING.invoker().onStartTracking(this.entity, player);
    }
}
