package io.wispforest.accessories.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.AccessoriesLoaderInternals;
import io.wispforest.accessories.api.client.ArmorRenderingExtension;
import io.wispforest.accessories.compat.GeckoLibCompat;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.util.InternalUtil;

@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin<T extends class_1309, M extends class_572<T>, A extends class_572<T>> extends class_3887<T, M> implements ArmorRenderingExtension<T> {

    public HumanoidArmorLayerMixin(class_3883<T, M> renderer) {
        super(renderer);
    }

    @Shadow
    protected abstract void renderArmorPiece(class_4587 poseStack, class_4597 multiBufferSource, T livingEntity, class_1304 equipmentSlot, int i, A humanoidModel);

    @Shadow
    private A getArmorModel(class_1304 slot) { return null; }

    @Shadow protected abstract void setPartVisibility(A humanoidModel, class_1304 equipmentSlot);

    @Unique
    @Nullable
    private class_1799 tempStack = null;

    @Override
    public void renderEquipmentStack(class_1799 stack, class_4587 poseStack, class_4597 multiBufferSource, T livingEntity, class_1304 equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        this.tempStack = stack;

        if (!attemptGeckoRender(stack, poseStack, multiBufferSource, livingEntity, equipmentSlot, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch)) {
            this.renderArmorPiece(poseStack, multiBufferSource, livingEntity, equipmentSlot, light, this.getArmorModel(equipmentSlot));
        }

        this.tempStack = null;
    }

    @WrapOperation(method = "renderArmorPiece", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getItemBySlot(Lnet/minecraft/world/entity/EquipmentSlot;)Lnet/minecraft/world/item/ItemStack;"))
    private class_1799 getAlternativeStack(class_1309 instance, class_1304 equipmentSlot, Operation<class_1799> original) {
        if (tempStack != null) return tempStack;

        return original.call(instance, equipmentSlot);
    }

    @Unique
    private boolean attemptGeckoRender(class_1799 stack, class_4587 poseStack, class_4597 multiBufferSource, T livingEntity, class_1304 equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!AccessoriesLoaderInternals.isModLoaded("geckolib")) return false;

        return GeckoLibCompat.renderGeckoArmor(poseStack, multiBufferSource, livingEntity, stack, equipmentSlot, this.method_17165(), this.getArmorModel(equipmentSlot), partialTicks, light, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, this::setPartVisibility);
    }
}
