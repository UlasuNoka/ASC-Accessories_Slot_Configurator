package io.wispforest.accessories.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.wispforest.accessories.pond.CosmeticArmorLookupTogglable;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = class_922.class, remap = false)
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> extends class_897<T> implements class_3883<T, M> {

    protected LivingEntityRendererMixin(class_5617.class_5618 context) {
        super(context);
    }

    @WrapMethod(method = {
            "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            "method_4054(Lnet/minecraft/class_1309;FFLnet/minecraft/class_4587;Lnet/minecraft/class_4597;I)V" //TODO: WHY DO I NEEDED THIS!
    }, remap = false, expect = 1, require = 1, allow = 1)
    private void accessories$adjustArmorLookup(class_1309 entity, float entityYaw, float partialTicks, class_4587 poseStack, class_4597 buffer, int packedLight, Operation<Void> original) {
        ((CosmeticArmorLookupTogglable)entity).setLookupToggle(true);

        original.call(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);

        ((CosmeticArmorLookupTogglable)entity).setLookupToggle(false);
    }
}
