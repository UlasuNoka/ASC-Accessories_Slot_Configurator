package io.wispforest.accessories.fabric.mixin.trinkets;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import dev.emi.trinkets.api.LivingEntityTrinketComponent;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(value = LivingEntityTrinketComponent.class, remap = false)
public class LivingEntityTrinketComponentMixin {

    @Inject(method = "readFromNbt", at = @At("HEAD"), remap = false)
    private void stopDuplicateItemDecode(class_2487 tag, class_7225.class_7874 lookup, CallbackInfo ci, @Local(argsOnly = true) LocalRef<class_2487> tagRef) {
        if (tag.method_10545("data_written_by_accessories")) {
            tagRef.set(new class_2487());
        }
    }
}
