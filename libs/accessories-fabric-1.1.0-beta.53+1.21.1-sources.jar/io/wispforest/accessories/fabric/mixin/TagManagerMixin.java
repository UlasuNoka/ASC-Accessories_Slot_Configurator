package io.wispforest.accessories.fabric.mixin;

import io.wispforest.accessories.fabric.AccessoriesInternalsImpl;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_3505;

//Copy of Mixin found within FabricAPI found here https://github.com/FabricMC/fabric/blob/41bc64cd617f03d49ecc4a4f7788cb65d465415c/fabric-resource-conditions-api-v1/src/main/java/net/fabricmc/fabric/mixin/resource/conditions/TagManagerLoaderMixin.java
@Mixin(class_3505.class)
public abstract class TagManagerMixin {
    @Shadow
    private List<class_3505.class_6863<?>> results;

    // lambda body inside thenAcceptAsync, in the reload method
    @Dynamic
    @Inject(method = "method_40098(Ljava/util/List;Ljava/lang/Void;)V", at = @At("RETURN"))
    private void hookApply(List<?> list, Void void_, CallbackInfo ci) {
        AccessoriesInternalsImpl.setTags(results);
    }
}
