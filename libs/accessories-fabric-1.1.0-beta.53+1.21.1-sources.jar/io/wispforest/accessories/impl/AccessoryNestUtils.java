package io.wispforest.accessories.impl;

import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.AccessoryNest;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.api.components.AccessoryNestContainerContents;
import io.wispforest.accessories.api.slot.NestedSlotReferenceImpl;
import io.wispforest.accessories.api.slot.SlotReference;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_1799;

public class AccessoryNestUtils {

    @Nullable
    public static AccessoryNestContainerContents getData(class_1799 stack){
        var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

        if(!(accessory instanceof AccessoryNest)) return null;

        return stack.method_57824(AccessoriesDataComponents.NESTED_ACCESSORIES);
    }

    public static <T> @Nullable T recursiveStackHandling(class_1799 stack, SlotReference reference, BiFunction<class_1799, SlotReference, @Nullable T> function) {
        var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

        var value = function.apply(stack, reference);

        if (accessory instanceof AccessoryNest holdable && value == null) {
            var innerStacks = holdable.getInnerStacks(stack);

            for (int i = 0; i < innerStacks.size(); i++) {
                var innerStack = innerStacks.get(i);

                if (innerStack.method_7960()) continue;

                value = recursiveStackHandling(innerStack, create(reference, i), function);

                if(value != null) return value;
            }
        }

        return value;
    }

    public static void recursiveStackConsumption(class_1799 stack, SlotReference reference, BiConsumer<class_1799, SlotReference> consumer) {
        var accessory = AccessoriesAPI.getOrDefaultAccessory(stack);

        consumer.accept(stack, reference);

        if (!(accessory instanceof AccessoryNest holdable)) return;

        var innerStacks = holdable.getInnerStacks(stack);

        for (int i = 0; i < innerStacks.size(); i++) {
            var innerStack = innerStacks.get(i);

            if (innerStack.method_7960()) continue;

            recursiveStackConsumption(innerStack, create(reference, i), consumer);
        }
    }

    public static SlotReference create(SlotReference reference, int innerIndex) {
        var innerSlotIndices = new ArrayList<Integer>();

        if(reference instanceof NestedSlotReferenceImpl nestedSlotReference) {
            innerSlotIndices.addAll(nestedSlotReference.innerSlotIndices());
        }

        innerSlotIndices.add(innerIndex);

        return SlotReference.ofNest(reference.entity(), reference.slotName(), reference.slot(), innerSlotIndices);
    }
}
