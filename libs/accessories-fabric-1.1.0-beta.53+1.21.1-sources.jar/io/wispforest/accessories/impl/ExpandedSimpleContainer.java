package io.wispforest.accessories.impl;

import Z;
import com.mojang.datafixers.util.Pair;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.impl.caching.AccessoriesHolderLookupCache;
import io.wispforest.accessories.utils.ItemStackMutation;
import io.wispforest.owo.util.EventSource;
import io.wispforest.owo.util.EventSource.Subscription;
import it.unimi.dsi.fastutil.ints.Int2BooleanArrayMap;
import it.unimi.dsi.fastutil.ints.Int2BooleanMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * An implementation of SimpleContainer with easy utilities for iterating over the stacks
 * and holding on to previous stack info
 */
public class ExpandedSimpleContainer extends class_1277 implements Iterable<Pair<Integer, class_1799>> {

    private static final Logger LOGGER = LogUtils.getLogger();

    private final AccessoriesContainerImpl container;

    private final String name;
    private final class_2371<class_1799> previousItems;
    private final Int2BooleanMap setFlags = new Int2BooleanArrayMap();

    private boolean newlyConstructed;

    private final Int2ObjectMap<EventSource<ItemStackMutation>.Subscription> currentSubscriptions = new Int2ObjectOpenHashMap<>();

    public ExpandedSimpleContainer(AccessoriesContainerImpl container, int size, String name) {
        this(container, size, name, true);
    }

    public ExpandedSimpleContainer(AccessoriesContainerImpl container, int size, String name, boolean toggleNewlyConstructed) {
        super(size);

        this.container = container;

        this.method_5489(container);

        if(toggleNewlyConstructed) this.newlyConstructed = true;

        this.name = name;
        this.previousItems = class_2371.method_10213(size, class_1799.field_8037);
    }

    public String name() {
        return this.name;
    }

    //--

    public boolean wasNewlyConstructed() {
        var bl = newlyConstructed;

        this.newlyConstructed = false;

        return bl;
    }

    public boolean isSlotFlagged(int slot){
        var bl = setFlags.getOrDefault(slot, false);

        if(bl) setFlags.put(slot, false);

        return bl;
    }

    public void setPreviousItem(int slot, class_1799 stack) {
        if(slot >= 0 && slot < this.previousItems.size()) {
            this.previousItems.set(slot, stack);
            if (!stack.method_7960() && stack.method_7947() > this.method_5444()) {
                stack.method_7939(this.method_5444());
            }
        }
    }

    public class_1799 getPreviousItem(int slot) {
        return slot >= 0 && slot < this.previousItems.size()
                ? this.previousItems.get(slot)
                : class_1799.field_8037;
    }

    //--

    @Override
    public int method_58350(class_1799 itemStack) {
        var accessory = AccessoriesAPI.getOrDefaultAccessory(itemStack);

        return Math.min(super.method_58350(itemStack), accessory.maxStackSize(itemStack));
    }

    @Override
    public class_1799 method_5438(int slot) {
        if(!validIndex(slot)) return class_1799.field_8037;

        return super.method_5438(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        if(!validIndex(slot)) return class_1799.field_8037;

        var stack = super.method_5434(slot, amount);

        if (!stack.method_7960()) {
            this.setFlags.put(slot, true);

            var prevStack = this.method_5438(slot);

            if (prevStack.method_7960()) {
                var subscription = this.currentSubscriptions.remove(slot);

                if (subscription != null) subscription.cancel();
            }
        }

        return stack;
    }

    @Override
    public class_1799 method_5441(int slot) {
        if(!validIndex(slot)) return class_1799.field_8037;

        // TODO: Concerning the flagging system, should this work for it?

        var subscription = this.currentSubscriptions.remove(slot);

        if (subscription != null) subscription.cancel();

        return super.method_5441(slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if(!validIndex(slot)) return;

        var subscription = this.currentSubscriptions.remove(slot);

        if (subscription != null) subscription.cancel();

        super.method_5447(slot, stack);

        if (!stack.method_7960()) {
            this.currentSubscriptions.put(slot,
                    ItemStackMutation.getEvent(stack).source().subscribe((stack1, types) -> {
                        if (types.contains(AccessoriesDataComponents.ATTRIBUTES) || types.contains(AccessoriesDataComponents.NESTED_ACCESSORIES)) {
                            this.method_5431();
                        }

                        if (!this.container.capability.entity().method_37908().method_8608()) {
                            var cache = ((AccessoriesHolderImpl) this.container.capability.getHolder()).getLookupCache();

                            if (cache != null) cache.invalidateLookupData(this.container.getSlotName(), stack1, types);
                        }
                    })
            );
        }

        setFlags.put(slot, true);
    }

    // Simple validation method to make sure that the given access is valid before attempting an operation
    public boolean validIndex(int slot){
        var isValid = slot >= 0 && slot < this.method_5439();

        var nameInfo = (this.name != null ? "Container: " + this.name + ", " : "");

        if(!isValid && FabricLoader.getInstance().isDevelopmentEnvironment()){
            try {
                throw new IllegalStateException("Access to a given Inventory was found to be out of the range valid for the container! [Name: " + nameInfo + " Index: " + slot + "]");
            } catch (Exception e) {
                LOGGER.debug("Full Exception: ", e);
            }
        }

        return isValid;
    }

    //--

    @Override
    public void method_7659(class_2499 containerNbt, class_7225.class_7874 provider) {
        this.container.containerListenerLock = true;

        var capability = this.container.capability;

        var prevStacks = new ArrayList<class_1799>();
        for(int i = 0; i < this.method_5439(); ++i) {
            var currentStack = this.method_5438(i);

            prevStacks.add(currentStack);

            this.method_5447(i, class_1799.field_8037);
        }

        var invalidStacks = new ArrayList<class_1799>();
        var decodedStacks = new ArrayList<class_1799>();

        for(int i = 0; i < containerNbt.size(); ++i) {
            var compoundTag = containerNbt.method_10602(i);

            int j = compoundTag.method_10550("Slot");

            var stack = parseOptional(provider, compoundTag);

            decodedStacks.add(stack);

            if (j >= 0 && j < this.method_5439()) {
                this.method_5447(j, stack);
            } else {
                invalidStacks.add(stack);
            }
        }

        this.container.containerListenerLock = false;

        if (!capability.entity().method_37908().method_8608()) {
            if (!prevStacks.equals(decodedStacks)) {
                this.method_5431();
            }

            ((AccessoriesHolderImpl) capability.getHolder()).invalidStacks.addAll(invalidStacks);
        }
    }

    public class_1799 parseOptional(class_7225.class_7874 lookupProvider, class_2520 tag) {
        return class_1799.field_24671.parse(lookupProvider.method_57093(class_2509.field_11560), tag)
                .resultOrPartial(string -> {
                    LOGGER.error("[ExpandedSimpleContainer] An error has occured while decoding stack!");
                    LOGGER.error(" - Entity Effected: '{}'", this.container.capability.entity().toString());
                    LOGGER.error(" - Container Name: '{}'", this.container.getSlotName());
                    LOGGER.error(" - Tried to load invalid item: '{}'", string);
                    LOGGER.error(" - Stack Data: '{}'", tag.toString());
                })
                .orElse(class_1799.field_8037);
    }

    @Override
    public class_2499 method_7660(class_7225.class_7874 provider) {
        class_2499 listTag = new class_2499();

        for(int i = 0; i < this.method_5439(); ++i) {
            class_1799 itemStack = this.method_5438(i);

            if (!itemStack.method_7960()) {
                var compoundTag = new class_2487();

                compoundTag.method_10569("Slot", i);

                listTag.add(itemStack.method_57376(provider, compoundTag));
            }
        }

        return listTag;
    }

    //--

    @NotNull
    @Override
    public Iterator<Pair<Integer, class_1799>> iterator() {
        return new Iterator<>() {
            private int index = 0;

            @Override
            public boolean hasNext() {
                return index < ExpandedSimpleContainer.this.method_5439();
            }

            @Override
            public Pair<Integer, class_1799> next() {
                var pair = new Pair<>(index, ExpandedSimpleContainer.this.method_5438(index));

                index++;

                return pair;
            }
        };
    }

    public void setFromPrev(ExpandedSimpleContainer prevContainer) {
        prevContainer.forEach(pair -> this.setPreviousItem(pair.getFirst(), pair.getSecond()));
    }

    public void copyPrev(ExpandedSimpleContainer prevContainer) {
        for (int i = 0; i < prevContainer.method_5439(); i++) {
            if(i >= this.method_5439()) continue;

            var prevItem = prevContainer.getPreviousItem(i);

            if(!prevItem.method_7960()) this.setPreviousItem(i, prevItem);
        }
    }
}
