package io.wispforest.accessories.impl;

import io.wispforest.accessories.Accessories;
import net.minecraft.class_1299;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

@Deprecated(forRemoval = true)
public class AccessoriesTags {

    public static final class_6862<class_1299<?>> MODIFIABLE_ENTITY_WHITELIST = io.wispforest.accessories.api.data.AccessoriesTags.MODIFIABLE_ENTITY_WHITELIST;
    public static final class_6862<class_1299<?>> MODIFIABLE_ENTITY_BLACKLIST = io.wispforest.accessories.api.data.AccessoriesTags.MODIFIABLE_ENTITY_BLACKLIST;

    public static final class_6862<class_1887> VALID_FOR_REDIRECTION = ofTag(class_7924.field_41265, "valid_for_redirection");

    public static <T, R extends class_2378<T>> class_6862<T> ofTag(class_5321<R> resourceKey, String path) {
        return class_6862.method_40092(resourceKey, Accessories.of(path));
    }
}
