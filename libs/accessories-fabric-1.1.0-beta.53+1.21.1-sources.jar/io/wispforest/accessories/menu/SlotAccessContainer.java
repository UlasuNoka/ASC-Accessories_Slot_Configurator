package io.wispforest.accessories.menu;

import I;
import io.wispforest.accessories.pond.ItemBasedSteerable;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5630;
import org.jetbrains.annotations.Nullable;

public final class SlotAccessContainer implements class_1263 {

    private final class_5630 slotAccess;

    public SlotAccessContainer(class_5630 slotAccess) {
        this.slotAccess = slotAccess;
    }

    public static class_1263 ofArmor(class_1304 equipmentSlot, class_1309 livingEntity) {
        if(livingEntity instanceof class_1657 player) {
            return ofPlayerArmor(equipmentSlot, player);
        } else {
            return ofGenericArmor(equipmentSlot, livingEntity);
        }
    }

    public static class_1263 ofGenericArmor(class_1304 equipmentSlot, class_1309 livingEntity) {
        return new SlotAccessContainer(class_5630.method_32330(livingEntity, equipmentSlot));
    }

    @Nullable
    public static class_1263 ofPlayerArmor(class_1304 equipmentSlot, class_1657 player) {
        var index = 39 - switch (equipmentSlot) {
            case field_6169 -> 0;
            case field_6174 -> 1;
            case field_6172 -> 2;
            case field_6166 -> 3;
            default -> -1;
        };

        if(index == 40) return null;

        return new SlotAccessContainer(class_5630.method_32328(player.method_31548(), index));
    }

    //--

    @Nullable
    public static class_1263 ofSaddleSlot(class_1309 living) {
        if(living instanceof class_1496 abstractHorse) {
            return ofHorseSaddle(abstractHorse);
        } else if(living instanceof ItemBasedSteerable saddleable) {
            return ofGenericSaddle(saddleable);
        }

        return null;
    }

    public static class_1263 ofHorseSaddle(class_1496 abstractHorse) {
        return new SlotAccessContainer(abstractHorse.method_32318(400));
    }

    public static class_1263 ofGenericSaddle(ItemBasedSteerable saddleable) {
        return new SlotAccessContainer(
                class_5630.method_59666(
                        () -> saddleable.method_6725() ? class_1802.field_8175.method_7854() : class_1799.field_8037,
                        stack -> {
                            if(stack.method_7960()) {
                                saddleable.getInstance().method_26310(false);
                            } else {
                                saddleable.method_6576(stack, null);
                            }
                        }
                )
        );
    }

    //--

    @Override
    public int method_5439() {
        return 1;
    }

    @Override
    public boolean method_5442() {
        return method_5438(0).method_7960();
    }

    @Override
    public class_1799 method_5438(int slot) {
        return this.slotAccess.method_32327();
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        var stack = this.method_5438(0).method_7972();

        var removedStack = stack.method_7971(amount);

        this.slotAccess.method_32332(stack);

        return removedStack;
    }

    @Override
    public class_1799 method_5441(int slot) {
        var stack = this.method_5438(0).method_7972();

        this.slotAccess.method_32332(class_1799.field_8037);

        return stack;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        this.slotAccess.method_32332(stack);
    }

    @Override public void method_5431() {}
    @Override public boolean method_5443(class_1657 player) { return true; }
    @Override public void method_5448() {}
}
