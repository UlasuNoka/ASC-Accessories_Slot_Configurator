package io.wispforest.accessories.menu.networking;

import io.wispforest.owo.util.pond.OwoSlotExtension;
import java.util.Map;
import net.minecraft.class_1703;

public record ToggledSlots(Map<Integer, Boolean> changedSlotStates) {

    public static void initMenu(class_1703 menu) {
        menu.addServerboundMessage(ToggledSlots.class, (message) -> {
            message.changedSlotStates().forEach((index, state) -> {
                if (index >= menu.field_7761.size() || index < 0) return;

                var slot = ((OwoSlotExtension) menu.method_7611(index));

                if(state != slot.owo$getDisabledOverride()) slot.owo$setDisabledOverride(state);
            });
        });
    }
}
