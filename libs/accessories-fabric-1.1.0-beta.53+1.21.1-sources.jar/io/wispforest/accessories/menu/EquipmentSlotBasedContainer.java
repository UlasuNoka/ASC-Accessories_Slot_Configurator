package io.wispforest.accessories.menu;

import I;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_5630;

public interface EquipmentSlotBasedContainer extends class_1263 {

    static class_1263 of(class_1304 equipmentSlot, class_1309 livingEntity) {
        if(livingEntity instanceof class_1657 player) {
            return ofPlayer(equipmentSlot, player);
        } else {
            return ofLiving(equipmentSlot, livingEntity);
        }
    }

    static class_1263 ofLiving(class_1304 equipmentSlot, class_1309 livingEntity) {
        var slotAccess = class_5630.method_59666(
                () -> livingEntity.method_6118(equipmentSlot),
                stack -> livingEntity.method_5673(equipmentSlot, stack)
        );

        return new SlotAccessContainer(slotAccess);
    }

    static class_1263 ofPlayer(class_1304 equipmentSlot, class_1657 player) {
        var slotAccess = class_5630.method_59666(
                () -> {
                    var inv = player.method_31548();

                    var index = switch (equipmentSlot) {
                        case field_6169 -> 3;
                        case field_6174 -> 2;
                        case field_6172 -> 1;
                        case field_6166 -> 0;
                        default -> -1;
                    };

                    if(index == -1) return class_1799.field_8037;

                    return inv.method_7372(index);
                },
                stack -> {
                    var inv = player.method_31548();

                    var index = switch (equipmentSlot) {
                        case field_6169 -> 0;
                        case field_6174 -> 1;
                        case field_6172 -> 2;
                        case field_6166 -> 3;
                        default -> -1;
                    };

                    if(index == -1) return;


                    inv.method_5447(39 - index, stack);
                }
        );

        return new SlotAccessContainer(slotAccess);
    }

    class_1304 equipmentSlot();

    class_1799 getEquipmentStack(class_1304 equipmentSlot);

    void setEquipmentStack(class_1304 equipmentSlot, class_1799 stack);

    @Override
    default int method_5439() {
        return 1;
    }

    @Override
    default boolean method_5442() {
        return method_5438(0).method_7960();
    }

    @Override
    default class_1799 method_5438(int slot) {
        return this.getEquipmentStack(equipmentSlot());
    }

    @Override
    default class_1799 method_5434(int slot, int amount) {
        var stack = this.method_5438(0).method_7972();

        var removedStack = stack.method_7971(amount);

        this.setEquipmentStack(equipmentSlot(), stack);

        return removedStack;
    }

    @Override
    default class_1799 method_5441(int slot) {
        var stack = this.method_5438(0).method_7972();

        this.setEquipmentStack(equipmentSlot(), class_1799.field_8037);

        return stack;
    }

    @Override
    default void method_5447(int slot, class_1799 stack) {
        this.setEquipmentStack(equipmentSlot(), stack);
    }

    @Override
    default void method_5431() {}

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    default void method_5448() {}
}
