package io.wispforest.accessories.menu;

import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.pond.ArmorSlotExtension;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_9692;
import org.jetbrains.annotations.Nullable;

public class AccessoriesArmorSlot extends class_9692 implements SlotTypeAccessible, ArmorSlotExtension {

    public final AccessoriesContainer accessoriesContainer;

    public AccessoriesArmorSlot(AccessoriesContainer accessoriesContainer, class_1263 container, class_1309 livingEntity, class_1304 equipmentSlot, int slot, int x, int y, @Nullable class_2960 resourceLocation) {
        super(container, livingEntity, equipmentSlot, slot, x, y, resourceLocation);

        this.accessoriesContainer = accessoriesContainer;
    }

    @Override
    public String slotName() {
        return accessoriesContainer.getSlotName();
    }

    @Override
    public SlotType slotType() {
        return accessoriesContainer.slotType();
    }

    @Override
    public AccessoriesContainer getContainer() {
        return this.accessoriesContainer;
    }
}
