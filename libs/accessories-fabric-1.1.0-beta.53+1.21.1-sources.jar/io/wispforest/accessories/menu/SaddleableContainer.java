package io.wispforest.accessories.menu;

import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3419;
import net.minecraft.class_5146;
import net.minecraft.class_5630;
import org.jetbrains.annotations.Nullable;

public interface SaddleableContainer extends class_1263 {

    @Nullable
    static class_1263 of(class_1309 living) {
        if(living instanceof class_1496 abstractHorse) {
            return ofHorse(abstractHorse);
        } else if(living instanceof class_5146 saddleable) {
            return ofSaddleable(saddleable);
        }

        return null;
    }

    static class_1263 ofHorse(class_1496 abstractHorse) {
        return new SlotAccessContainer(abstractHorse.method_32318(400));

//        return new SaddleableContainer() {
//            private final SlotAccess slotAccess = abstractHorse.getSlot(400);
//
//            @Override
//            public Saddleable saddleable() {
//                return abstractHorse;
//            }
//
//            @Override
//            public ItemStack getSaddle() {
//                return this.slotAccess.get();
//            }
//
//            @Override
//            public ItemStack removeSaddle() {
//                this.slotAccess.set(ItemStack.EMPTY);
//
//                return this.slotAccess.get().copy();
//            }
//        };
    }

    static class_1263 ofSaddleable(class_5146 saddleable) {
        return new SlotAccessContainer(
                class_5630.method_59666(
                        () -> saddleable.method_6725() ? class_1802.field_8175.method_7854() : class_1799.field_8037,
                        stack -> saddleable.method_6576(stack, class_3419.field_15254)
                )
        );

//        return new SaddleableContainer() {
//            @Override
//            public Saddleable saddleable() {
//                return saddleable;
//            }
//
//            @Override
//            public ItemStack getSaddle() {
//                return saddleable.isSaddled() ? Items.SADDLE.getDefaultInstance() : ItemStack.EMPTY;
//            }
//
//            @Override
//            public ItemStack removeSaddle() {
//                saddleable.equipSaddle(ItemStack.EMPTY, null);
//
//                return ItemStack.EMPTY;
//            }
//        };
    }

    class_5146 saddleable();

    class_1799 getSaddle();

    class_1799 removeSaddle();

    @Override
    default int method_5439() {
        return 1;
    }

    @Override
    default boolean method_5442() {
        return method_5438(0).method_7960();
    }

    @Override
    default class_1799 method_5438(int slot) {
        return getSaddle();
    }

    @Override
    default class_1799 method_5434(int slot, int amount) {
        if(amount <= 0) return class_1799.field_8037;

        return removeSaddle();
    }

    @Override
    default class_1799 method_5441(int slot) {
        return removeSaddle();
    }

    @Override
    default void method_5447(int slot, class_1799 stack) {
        saddleable().method_6576(stack, class_3419.field_15254);
    }

    @Override
    default void method_5431() {}

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    default void method_5448() {}
}
