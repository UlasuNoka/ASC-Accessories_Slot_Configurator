package io.wispforest.accessories.menu.variants;

import I;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.accessories.mixin.CraftingMenuAccessor;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.ScreenOpen;
import io.wispforest.endec.StructEndec;
import it.unimi.dsi.fastutil.Pair;
import net.minecraft.class_1263;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1662;
import net.minecraft.class_1715;
import net.minecraft.class_1729;
import net.minecraft.class_1731;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import net.minecraft.class_3955;
import net.minecraft.class_5421;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public abstract class AccessoriesMenuBase extends class_1729<class_9694, class_3955> {

    @Nullable protected final class_8566 craftSlots;
    @Nullable protected final class_1731 resultSlots = new class_1731();

    protected final class_1657 owner;

    @Nullable
    protected final class_1309 targetEntity;

    protected boolean sendCarriedStackToInventory = false;

    protected int slotAmountAdded = -1;
    protected boolean isValid = true;

    protected AccessoriesMenuBase(class_3917<? extends AccessoriesMenuBase> menuType, int containerId, class_1661 inventory, @Nullable class_1309 targetEntity) {
        super(menuType, containerId);

        this.owner = inventory.field_7546;
        this.targetEntity = targetEntity;

        if (this instanceof AccessoriesExperimentalMenu) {
            this.craftSlots = new class_1715(this, 2, 2);

            this.method_7621(new class_1734(inventory.field_7546, this.craftSlots, this.resultSlots, 0, 154, 28));

            for (int y = 0; y < 2; ++y) {
                for (int x = 0; x < 2; ++x) {
                    this.method_7621(new class_1735(this.craftSlots, x + y * 2, 98 + x * 18, 18 + y * 18));
                }
            }
        } else {
            this.craftSlots = new class_1715(this, 0, 0);
        }

        this.addServerboundMessage(SetTransferFlag.class, StructEndec.unit(SetTransferFlag::new), setTransferFlag -> {
            this.sendCarriedStackToInventory = true;
        });
    }

    public final AccessoriesMenuVariant menuVariant() {
        return AccessoriesMenuVariant.getVariant((class_3917<? extends AccessoriesMenuBase>) this.method_17358());
    }

    @Nullable
    public final class_1309 targetEntity() {
        return this.targetEntity;
    }

    public final class_1657 owner() {
        return this.owner;
    }

    public final void reopenMenu() {
        AccessoriesNetworking.sendToServer(ScreenOpen.of(this.targetEntity(), this.menuVariant()));
    }

    public void transferAndClose(Runnable setupCall) {
        this.sendMessage(new SetTransferFlag());

        setupCall.run();

        this.player().method_7346();
    }

    public int slotAmountAdded() {
        return slotAmountAdded;
    }

    public AccessoriesMenuBase isSyncedWithServer(int serverSlotAmountAdded) {
        this.isValid = slotAmountAdded == serverSlotAmountAdded;

        return this;
    }

    public boolean isValidMenu() {
        return this.isValid;
    }

    @Override
    public void method_7610(int stateId, List<class_1799> items, class_1799 carried) {
        if (!this.isValidMenu()) return;

        super.method_7610(stateId, items, carried);
    }

    //--

    @Nullable
    public Pair<class_1799, class_1799> quickMoveStackCrafting(int index) {
        var slot = this.field_7761.get(index);

        if (slot.method_7681()) {
            var itemStack2 = slot.method_7677();
            var itemStack = itemStack2.method_7972();

            var endIndex = 5 + (4 * 9);

            if (index == 0) {
                if (!this.method_7616(itemStack2, 5, endIndex, true)) return Pair.of(class_1799.field_8037, null);

                slot.method_7670(itemStack2, itemStack);
            } else if (index >= 1 && index < 5) {
                if (!this.method_7616(itemStack2, 5, endIndex, false)) return Pair.of(class_1799.field_8037, null);
            }

            if (itemStack2.method_7947() == itemStack.method_7947()) return null;

            return Pair.of(itemStack, itemStack2);
        }

        return null;
    }

    public void method_7654(class_1662 itemHelper) {
        this.craftSlots.method_7683(itemHelper);
    }

    public void method_7657() {
        this.resultSlots.method_5448();
        this.craftSlots.method_5448();
    }

    public boolean method_7652(class_8786<class_3955> recipe) {
        return recipe.comp_1933().method_8115(this.craftSlots.method_59961(), this.owner.method_37908());
    }

    public void method_7609(class_1263 container) {
        CraftingMenuAccessor.accessories$slotChangedCraftingGrid(this, this.owner.method_37908(), this.owner, this.craftSlots, this.resultSlots, (class_8786) null);
    }

    public void method_7595(class_1657 player) {
        if (player.field_7498.method_34255().method_7960() && this.sendCarriedStackToInventory) {
            player.field_7498.method_34254(this.method_34255());
            this.method_34254(class_1799.field_8037);
        }

        super.method_7595(player);
        this.resultSlots.method_5448();
        if (!player.method_37908().field_9236) {
            this.method_7607(player, this.craftSlots);
        }
    }

    public boolean method_7613(class_1799 stack, class_1735 slot) {
        return slot.field_7871 != this.resultSlots && super.method_7613(stack, slot);
    }

    public int method_7655() {
        return -1;
    }

    public int method_7653() {
        return this.craftSlots.method_17398();
    }

    public int method_7656() {
        return this.craftSlots.method_17397();
    }

    public int method_7658() {
        return this.craftSlots.method_17398() * this.craftSlots.method_17397() + 1;
    }

    public class_5421 method_30264() {
        return class_5421.field_25763;
    }

    public boolean method_32339(int slotIndex) {
        return slotIndex != this.method_7655();
    }

    private record SetTransferFlag() {}
}
