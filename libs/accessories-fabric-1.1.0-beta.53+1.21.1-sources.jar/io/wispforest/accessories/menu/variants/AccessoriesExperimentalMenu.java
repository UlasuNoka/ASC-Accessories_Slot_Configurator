package io.wispforest.accessories.menu.variants;

import I;
import Z;
import com.mojang.datafixers.util.Pair;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.menu.AccessoriesBasedSlot;
import io.wispforest.accessories.api.slot.SlotGroup;
import io.wispforest.accessories.api.slot.SlotType;
import io.wispforest.accessories.api.slot.SlotTypeReference;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import io.wispforest.accessories.data.SlotGroupLoader;
import io.wispforest.accessories.menu.*;
import io.wispforest.accessories.menu.networking.ToggledSlots;
import io.wispforest.owo.client.screens.SlotGenerator;
import io.wispforest.owo.util.pond.OwoSlotExtension;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1263;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1501;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1816;
import net.minecraft.class_2960;
import net.minecraft.class_9692;

public class AccessoriesExperimentalMenu extends AccessoriesMenuBase {

    private final Set<SlotType> usedSlots = new HashSet<>();

    private final Set<SlotGroup> selectedGroups = new HashSet<>();

    private final List<AccessoriesBasedSlot> accessoriesSpecificSlots = new ArrayList<>();

    private int addedArmorSlots = 0;

    private int startArmorSlots = 0;
    private int startingAccessoriesSlot = 0;

    private boolean includeSaddle = false;

    public static AccessoriesExperimentalMenu of(int containerId, class_1661 inventory, AccessoriesMenuData data) {
        var targetEntity = data.targetEntityId()
                .map(i -> (inventory.field_7546.method_37908().method_8469(i) instanceof class_1309 livingEntity)
                        ? livingEntity
                        : null
                ).orElse(null);

        var menu = new AccessoriesExperimentalMenu(containerId, inventory, targetEntity)
                .isSyncedWithServer(data.slotAmountAdded());

        return (AccessoriesExperimentalMenu) menu;
    }

    public AccessoriesExperimentalMenu(int containerId, class_1661 inventory, @Nullable class_1309 targetEntity) {
        super(AccessoriesMenuTypes.EXPERIMENTAL_MENU, containerId, inventory, targetEntity);

        var accessoryTarget = targetEntity != null ? targetEntity : owner;

        var capability = AccessoriesCapability.get(accessoryTarget);

        if (capability == null) return;

        this.updateUsedSlots();

        //--

        SlotGenerator.begin(this::method_7621, -300, -300)
                .playerInventory(inventory);

        //--

        this.method_7621(new class_1735(inventory, 40, -300, -300) {
            @Override
            public void method_48931(class_1799 itemStack, class_1799 itemStack2) {
                inventory.field_7546.method_6116(class_1304.field_6171, itemStack2, itemStack);
                super.method_48931(itemStack, itemStack2);
            }

            @Override
            public Pair<class_2960, class_2960> method_7679() {
                return Pair.of(class_1723.field_21668, class_1723.field_21673);
            }
        });

        var saddleInv = SlotAccessContainer.ofSaddleSlot(accessoryTarget);

        if(saddleInv != null) {
            this.includeSaddle = true;

            var iconPath = targetEntity instanceof class_1501 ? "container/horse/llama_armor_slot" : "container/horse/saddle_slot" ;

            this.method_7621(
                    new class_1735(saddleInv, 0, -300, -300){
                        @Override
                        public boolean method_7680(class_1799 stack) {
                            return stack.method_7909() instanceof class_1816 && super.method_7680(stack);
                        }

                        @Override
                        public Pair<class_2960, class_2960> method_7679() {
                            return Pair.of(ArmorSlotTypes.SPRITE_ATLAS_LOCATION, class_2960.method_60656(iconPath));
                        }
                    }
            );
        }

        this.startArmorSlots = this.field_7761.size();

        var containers = capability.getContainers();

        var validEquipmentSlots = new ArrayList<class_1304>();

        for (var value : class_1304.values()) {
            if (!accessoryTarget.method_56991(value)) continue;

            var armorRef = ArmorSlotTypes.getReferenceFromSlot(value);

            if (armorRef == null || containers.get(armorRef.slotName()) == null) continue;

            validEquipmentSlots.add(value);
        }

        for (var equipmentSlot : validEquipmentSlots.reversed()) {
            if (addArmorSlot(equipmentSlot, accessoryTarget, ArmorSlotTypes.getReferenceFromSlot(equipmentSlot), containers)) {
                addedArmorSlots += 2;
            }
        }

        this.startingAccessoriesSlot = this.field_7761.size();

        //--

        var validGroupData = SlotGroupLoader.getValidGroups(accessoryTarget);

        var slotTypes = validGroupData.values()
                .stream()
                .flatMap(Collection::stream)
                .toList();

        for (var slot : slotTypes) {
            var accessoryContainer = containers.get(slot.name());

            if (accessoryContainer == null || accessoryContainer.slotType() == null) continue;

            for (int i = 0; i < accessoryContainer.getSize(); i++) {
                var cosmeticSlot = new AccessoriesInternalSlot(accessoryContainer, true, i, -300, -300)
                        .useCosmeticIcon(false);

                this.method_7621(cosmeticSlot);
                this.accessoriesSpecificSlots.add(cosmeticSlot);

                var baseSlot = new AccessoriesInternalSlot(accessoryContainer, false, i, -300, -300);

                this.method_7621(baseSlot);
                this.accessoriesSpecificSlots.add(baseSlot);
            }
        }

        ToggledSlots.initMenu(this);

        this.slotAmountAdded = this.field_7761.size() - this.startArmorSlots;
    }

    private boolean addArmorSlot(class_1304 equipmentSlot, class_1309 targetEntity, SlotTypeReference armorReference, Map<String, AccessoriesContainer> containers) {
        var location = ArmorSlotTypes.getEmptyTexture(equipmentSlot, targetEntity);

        var armorContainer = containers.get(armorReference.slotName());

        if(armorContainer == null) return false;

        var armorSlot = new AccessoriesArmorSlot(armorContainer, SlotAccessContainer.ofArmor(equipmentSlot, targetEntity), targetEntity, equipmentSlot, 0, -300, -300, location != null ? location.second() : null)
                .setAtlasLocation(location != null ? location.first() : null); // 39 - i

        this.method_7621(armorSlot);

        var cosmeticSlot = new AccessoriesInternalSlot(armorContainer, true, 0, -300, -300){
            @Override
            public @Nullable Pair<class_2960, class_2960> method_7679() {
                if(location == null) return null;

                var atlasLocation = location.first();

                if(atlasLocation == null) atlasLocation = class_2960.method_60656("textures/atlas/blocks.png");

                return Pair.of(atlasLocation, location.second());
            }
        };

        this.method_7621(cosmeticSlot);

        return true;
    }

    public final class_1309 targetEntityDefaulted() {
        var targetEntity = this.targetEntity();

        return (targetEntity != null) ? targetEntity : this.owner();
    }

    public int startingAccessoriesSlot() {
        return this.startArmorSlots;
    }

    public List<AccessoriesBasedSlot> getAccessoriesSlots() {
        return this.accessoriesSpecificSlots;
    }

    public List<class_1735> getVisibleAccessoriesSlots() {
        var filteredList = new ArrayList<class_1735>();

        var groups = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted());

        var usedSlots = this.getUsedSlots();

        if (usedSlots != null) {
            groups.forEach((group, groupSlots) -> {
                if (groupSlots.stream().noneMatch(usedSlots::contains)) this.removeSelectedGroup(group);
            });
        }

        var selectedGroupedSlots = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted()).entrySet()
                .stream()
                .filter(entry -> this.selectedGroups.isEmpty() || this.selectedGroups.contains(entry.getKey()))
                .flatMap(entry -> entry.getValue().stream())
                .toList();

        for (int i = 0; i < (this.accessoriesSpecificSlots.size() / 2); i++) {
            var cosmetic = (i * 2);
            var accessory = cosmetic + 1;

            var cosmeticSlot = this.accessoriesSpecificSlots.get(cosmetic);
            var accessorySlot = this.accessoriesSpecificSlots.get(accessory);

            var slotType = accessorySlot.slotType();

            var isVisible = (this.usedSlots.isEmpty() || this.usedSlots.contains(slotType))
                    && (selectedGroupedSlots.isEmpty() || selectedGroupedSlots.contains(slotType));

            if(isVisible){
                filteredList.add(cosmeticSlot);
                filteredList.add(accessorySlot);
            }
        }

        return filteredList;
    }

    @Nullable
    public Set<SlotType> getUsedSlots() {
        return this.areUnusedSlotsShown() ? null : this.usedSlots;
    }

    public void updateUsedSlots() {
        this.usedSlots.clear();

        if(!this.areUnusedSlotsShown()) {
            var currentlyUsedSlots = AccessoriesAPI.getUsedSlotsFor(this.targetEntity != null ? this.targetEntity : this.owner, this.owner.method_31548());

            if(!currentlyUsedSlots.isEmpty()) {
                this.usedSlots.addAll(currentlyUsedSlots);
            } else {
                this.usedSlots.add(null);
            }
        }
    }

    public Set<SlotGroup> usedGroups() {
        var groups = SlotGroupLoader.getValidGroups(this.targetEntityDefaulted()).entrySet().stream();

        var usedSlots = this.getUsedSlots();

        groups = groups
                .filter(entry -> {
                    var groupSlots = entry.getValue()
                            .stream()
                            .filter(slotType -> {
                                if (UniqueSlotHandling.isUniqueSlot(slotType.name())) return false;

                                var capability = this.targetEntityDefaulted().accessoriesCapability();

                                if (capability == null) return false;

                                var container = capability.getContainer(slotType);

                                if (container == null) return false;

                                return container.getSize() > 0;
                            })
                            .collect(Collectors.toSet());

                    return !groupSlots.isEmpty() && (usedSlots == null || groupSlots.stream().anyMatch(usedSlots::contains));
                });

        return groups.map(Map.Entry::getKey).collect(Collectors.toSet());
    }

    public Set<SlotGroup> selectedGroups() {
        return this.selectedGroups;
    }

    public boolean isGroupSelected(SlotGroup slotGroup) {
        return this.selectedGroups.contains(slotGroup);
    }

    public void addSelectedGroup(SlotGroup slotGroup) {
        this.selectedGroups.add(slotGroup);

        if (this.selectedGroups.containsAll(usedGroups())) {
            this.selectedGroups.clear();
        }
    }

    public void removeSelectedGroup(SlotGroup slotGroup) {
        this.selectedGroups.remove(slotGroup);
    }

    public int addedArmorSlots() {
        return this.addedArmorSlots;
    }

    public boolean includeSaddle() {
        return this.includeSaddle;
    }

    public boolean areUnusedSlotsShown() {
        return Optional.ofNullable(AccessoriesHolder.get(owner)).map(AccessoriesHolder::showUnusedSlots).orElse(false);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        var slot = this.field_7761.get(index);

        if(!slot.method_7681()) return class_1799.field_8037;

        var itemStack2 = slot.method_7677();
        var itemStack = itemStack2.method_7972();

        // 0 1 2 3 : 6 - 7 / 4 - 5 / 2 - 3 / 0 - 1
        var equipmentSlot = player.method_32326(itemStack);
        int bottomArmorIndex = 42 + (8 - ((equipmentSlot.method_5927() + 1) * 2));
        int topArmorIndex = bottomArmorIndex + 1;

        var upperInventorySize = this.startingAccessoriesSlot;

        /*
         * Player Indies
         *       0: Result slot
         *  1 -  5: Crafting Grid
         *  5 - 41: Player Inv
         *      41: Offhand Slot
         * 41 - 49: Armor Slots
         * 49 -   : Accessories Slots
         */

        if (index == 0) { // If from Crafting Result move to player inventory
            if (!this.method_7616(itemStack2, 5, 41, true)) return class_1799.field_8037;

            slot.method_7670(itemStack2, itemStack);
        }
        else if ((index >= 1 && index < 5) || (index >= upperInventorySize) || Objects.equals(41, index) || (index >= 43)) { // If from Crafting Grid move to player inventory
            if (!this.method_7616(itemStack2, 5, 41, false)) return class_1799.field_8037;
        }
        else if (equipmentSlot.method_46643() && !this.field_7761.get(bottomArmorIndex).method_7681()) {
            if(!this.method_7616(itemStack2, bottomArmorIndex, topArmorIndex, false)) return class_1799.field_8037;
        }
        else if (equipmentSlot == class_1304.field_6171 && !this.field_7761.get(41).method_7681()) {
            if(!this.method_7616(itemStack2, 41, 42, false)) return class_1799.field_8037;
        }
        else {
            boolean changeOccured = false;

            if (canMoveToAccessorySlot(itemStack2, this.targetEntityDefaulted())) {
                method_7616(itemStack2, upperInventorySize, field_7761.size(), false);

                if (itemStack2.method_7947() != itemStack.method_7947() || itemStack2.method_7960()) {
                    changeOccured = true;
                }
            }

            if(!changeOccured) {
                if (index >= 5 && index < 32) {
                    if (!this.method_7616(itemStack2, 32, 41, false)) return class_1799.field_8037;
                } else if (index >= 32 && index < 41) {
                    if (!this.method_7616(itemStack2, 5, 32, false)) return class_1799.field_8037;
                }
            }
        }

        if (itemStack2.method_7947() == itemStack.method_7947()) return class_1799.field_8037;

        if (itemStack2.method_7960()) {
            slot.method_48931(class_1799.field_8037, itemStack);
        } else {
            slot.method_7668();
        }

        if (itemStack2.method_7947() == itemStack.method_7947()) return class_1799.field_8037;

        slot.method_7667(player, itemStack2);

        if (index == 0) player.method_7328(itemStack2, false);

        return itemStack;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    protected boolean canMoveToAccessorySlot(class_1799 stack, class_1309 living) {
        var capability = living.accessoriesCapability();

        if (capability == null) return false;

        var validSlotTypes = AccessoriesAPI.getStackSlotTypes(living, stack);

        for (var slot : this.field_7761.subList(this.startingAccessoriesSlot, this.field_7761.size())) {
            if (slot instanceof SlotTypeAccessible accessible && validSlotTypes.contains(accessible.slotType())) return true;
        }

        return false;
    }

    protected boolean method_7616(class_1799 stack, int startIndex, int endIndex, boolean reverseDirection) {
        boolean bl = false;
        int i = reverseDirection ? endIndex - 1 : startIndex;

        if (stack.method_7946()) {
            while (!stack.method_7960() && (reverseDirection ? i >= startIndex : i < endIndex)) {
                var slot = this.field_7761.get(i);

                if (slot.method_7682()) {
                    var itemStack = slot.method_7677();

                    if (!itemStack.method_7960() && class_1799.method_31577(stack, itemStack)) {
                        int j = itemStack.method_7947() + stack.method_7947();
                        int k = slot.method_7676(itemStack);

                        if (j <= k) {
                            stack.method_7939(0);
                            itemStack.method_7939(j);
                            slot.method_7668();
                            bl = true;
                        } else if (itemStack.method_7947() < k) {
                            stack.method_7934(k - itemStack.method_7947());
                            itemStack.method_7939(k);
                            slot.method_7668();
                            bl = true;
                        }
                    }
                }

                i += (reverseDirection) ? -1 : 1;
            }
        }

        if (!stack.method_7960()) {
            i = reverseDirection ? endIndex - 1 : startIndex;

            while (reverseDirection ? i >= startIndex : i < endIndex) {
                var slot = this.field_7761.get(i);

                if(slot.method_7682()) {
                    var itemStack = slot.method_7677();

                    if (itemStack.method_7960() && slot.method_7680(stack)) {
                        int j = slot.method_7676(stack);

                        slot.method_53512(stack.method_7971(Math.min(stack.method_7947(), j)));
                        slot.method_7668();

                        bl = true;
                        break;
                    }
                }

                i += (reverseDirection) ? -1 : 1;
            }
        }

        return bl;
    }

    // REQUIRED TO PREVENT THE MENU FROM RESETTING THE CACHE WITH STACKS THAT ARE ALREADY SYNCED TO THE CLIENT
    // SINCE ACCESSORIES CONTAINERS ARE FULLY SYNCED
    @Override
    public void method_7610(int stateId, List<class_1799> items, class_1799 carried) {
        if (!this.isValidMenu()) return;

        for(int i = 0; i < items.size(); ++i) {
            var slot = this.method_7611(i);

            if (slot instanceof SlotTypeAccessible) continue;

            slot.method_7673(items.get(i));
        }

        super.method_7610(stateId, List.of(), carried);
    }
}
