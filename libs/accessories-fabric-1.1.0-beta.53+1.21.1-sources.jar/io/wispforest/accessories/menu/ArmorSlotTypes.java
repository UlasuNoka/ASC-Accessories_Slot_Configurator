package io.wispforest.accessories.menu;

import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesContainer;
import io.wispforest.accessories.api.Accessory;
import io.wispforest.accessories.api.SoundEventData;
import io.wispforest.accessories.api.slot.EntityBasedPredicate;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.api.slot.SlotTypeReference;
import io.wispforest.accessories.api.slot.UniqueSlotHandling;
import it.unimi.dsi.fastutil.Pair;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1501;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_5151;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.apache.logging.log4j.util.TriConsumer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ArmorSlotTypes implements UniqueSlotHandling.RegistrationCallback {

    private static final Accessory armorAccessory = new Accessory() {
        @Override
        @Nullable
        public SoundEventData getEquipSound(class_1799 stack, SlotReference reference) {
            var sound = (stack.method_7909() instanceof class_5151 equipable) ? equipable.method_31570() : class_3417.field_14883;

            return new SoundEventData(sound, 1.0f, 1.0f);
        }
    };

    public static final Map<class_1304, class_2960> TEXTURE_EMPTY_SLOTS = Map.of(
            class_1304.field_6166, class_2960.method_60656("item/empty_armor_slot_boots"),
            class_1304.field_6172, class_2960.method_60656("item/empty_armor_slot_leggings"),
            class_1304.field_6174, class_2960.method_60656("item/empty_armor_slot_chestplate"),
            class_1304.field_6169, class_2960.method_60656("item/empty_armor_slot_helmet")
    );

    public static final class_1304[] SLOT_IDS = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};

    public static final ArmorSlotTypes INSTANCE = new ArmorSlotTypes();

    private static final class_2960 HEAD_PREDICATE_LOCATION = Accessories.of("head");
    private static final class_2960 CHEST_PREDICATE_LOCATION = Accessories.of("chest");
    private static final class_2960 LEGS_PREDICATE_LOCATION = Accessories.of("legs");
    private static final class_2960 FEET_PREDICATE_LOCATION = Accessories.of("feet");
    private static final class_2960 ANIMAL_BODY_PREDICATE_LOCATION  = Accessories.of("animal_body");

    private SlotTypeReference headSlotReference = null;
    private SlotTypeReference chestSlotReference = null;
    private SlotTypeReference legsSlotReference = null;
    private SlotTypeReference feetSlotReference = null;
    private SlotTypeReference animalBodySlotReference = null;

    private ArmorSlotTypes() {}

    public static boolean isArmorType(String slotType) {
        return headSlot().slotName().equals(slotType)
                || chestSlot().slotName().equals(slotType)
                || legsSlot().slotName().equals(slotType)
                || feetSlot().slotName().equals(slotType);
    }

    public static SlotTypeReference headSlot() {
        return ArmorSlotTypes.INSTANCE.headSlotReference;
    }

    public static SlotTypeReference chestSlot() {
        return ArmorSlotTypes.INSTANCE.chestSlotReference;
    }

    public static SlotTypeReference legsSlot() {
        return ArmorSlotTypes.INSTANCE.legsSlotReference;
    }

    public static SlotTypeReference feetSlot() {
        return ArmorSlotTypes.INSTANCE.feetSlotReference;
    }

    public static SlotTypeReference animalBody() {
        return ArmorSlotTypes.INSTANCE.animalBodySlotReference;
    }

    public static List<SlotTypeReference> getArmorReferences() {
        return List.of(headSlot(), chestSlot(), legsSlot(), feetSlot());
    }

    public static final class_2960 SPRITE_ATLAS_LOCATION = class_2960.method_60656("textures/atlas/gui.png");

    private static final class_2960 LLAMA_ARMOR_SLOT_SPRITE = class_2960.method_60656("container/horse/llama_armor_slot");
    private static final class_2960 HORSE_ARMOR_SLOT_SPRITE = class_2960.method_60656("container/horse/armor_slot");

    @Nullable
    public static Pair<@Nullable class_2960, class_2960> getEmptyTexture(class_1304 slot, class_1309 living) {
        var texture = TEXTURE_EMPTY_SLOTS.get(slot);

        if (texture != null) return Pair.of(null, texture);


        if (living instanceof class_1496 horse) {
            if (horse.method_56991(class_1304.field_48824)) {
                if (horse instanceof class_1501) return Pair.of(SPRITE_ATLAS_LOCATION, LLAMA_ARMOR_SLOT_SPRITE);

                return Pair.of(SPRITE_ATLAS_LOCATION, HORSE_ARMOR_SLOT_SPRITE);
            }
        }

        return null;
    }

    @Nullable
    public static SlotTypeReference getReferenceFromSlot(class_1304 equipmentSlot) {
        return switch (equipmentSlot) {
            case field_6169 -> headSlot();
            case field_6174 -> chestSlot();
            case field_6172 -> legsSlot();
            case field_6166 -> feetSlot();
            case field_48824 -> animalBody();
            default -> null;
        };
    }

    public static boolean isValidEquipable(class_1304 equipmentSlot) {
        return switch (equipmentSlot) {
            case field_6169, field_6172, field_6174, field_6166, field_48824 -> true;
            default -> false;
        };
    }

    public void init() {
        UniqueSlotHandling.EVENT.register(this);

        AccessoriesAPI.registerPredicate(HEAD_PREDICATE_LOCATION, (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, class_1304.field_6169)));
        AccessoriesAPI.registerPredicate(CHEST_PREDICATE_LOCATION, (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, class_1304.field_6174)));
        AccessoriesAPI.registerPredicate(LEGS_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, class_1304.field_6172)));
        AccessoriesAPI.registerPredicate(FEET_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, class_1304.field_6166)));
        AccessoriesAPI.registerPredicate(ANIMAL_BODY_PREDICATE_LOCATION,  (EntityBasedPredicate) ((level, entity, slotType, slot, stack) -> isValid(entity, stack, class_1304.field_48824)));
    }

    public void registerAccessories(Consumer<TriConsumer<Integer, class_2960, class_1792>> eventRegister) {
        class_7923.field_41178.forEach(this::tryToRegisterItem);

        eventRegister.accept((integer, resourceLocation, item) -> tryToRegisterItem(item));
    }

    private void tryToRegisterItem(class_1792 item) {
        if(item instanceof class_5151 equipable && isValidEquipable(equipable.method_7685())) {
            var accessory = AccessoriesAPI.getAccessory(item);

            if(accessory == null) AccessoriesAPI.registerAccessory(item, armorAccessory);
        }
    }

    @Override
    public void registerSlots(UniqueSlotHandling.UniqueSlotBuilderFactory factory) {
        headSlotReference = factory.create(Accessories.of("head"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(HEAD_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(class_1299.field_6097, class_1299.field_6131)
                .build();

        chestSlotReference = factory.create(Accessories.of("chest"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(CHEST_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(class_1299.field_6097, class_1299.field_6131)
                .build();

        legsSlotReference = factory.create(Accessories.of("legs"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(LEGS_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(class_1299.field_6097, class_1299.field_6131)
                .build();

        feetSlotReference = factory.create(Accessories.of("feet"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(FEET_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(class_1299.field_6097, class_1299.field_6131)
                .build();

        animalBodySlotReference = factory.create(Accessories.of("animal_body"), 1)
                .allowTooltipInfo(false)
                .slotPredicates(ANIMAL_BODY_PREDICATE_LOCATION)
                .strictMode(true)
                .allowResizing(false)
                .allowEquipFromUse(false)
                .validTypes(class_1299.field_6139, class_1299.field_6055)
                .build();
    }

    private static TriState isValid(class_1309 livingEntity, class_1799 stack, class_1304 equipmentSlot) {
        class_1304 stackEquipmentSlot = null;

        if(livingEntity == null) {
            var equipable = class_5151.method_48957(stack);

            if(equipable != null) stackEquipmentSlot = equipable.method_7685();
        } else {
            stackEquipmentSlot = livingEntity.method_32326(stack);
        }

        return equipmentSlot.equals(stackEquipmentSlot) ? TriState.TRUE : TriState.DEFAULT;
    }

    @Nullable
    public static class_1799 getAlternativeStack(class_1309 instance, class_1304 equipmentSlot) {
        var capability = instance.accessoriesCapability();

        if (capability != null) {
            var reference = ArmorSlotTypes.getReferenceFromSlot(equipmentSlot);

            if (reference != null) {
                var container = capability.getContainer(reference);

                if (container != null) {
                    if(!container.shouldRender(0)) return class_1799.field_8037;

                    var stack = container.getCosmeticAccessories().method_5438(0);

                    if (!stack.method_7960() && Accessories.config().clientOptions.showCosmeticAccessories()) return stack;
                }
            }
        }

        return null;
    }
}
