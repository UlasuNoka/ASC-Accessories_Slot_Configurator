package io.wispforest.accessories.menu;

import io.wispforest.accessories.compat.config.ScreenType;
import io.wispforest.accessories.menu.variants.AccessoriesExperimentalMenu;
import io.wispforest.accessories.menu.variants.AccessoriesMenu;
import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public enum AccessoriesMenuVariant {
    ORIGINAL(() -> AccessoriesMenuTypes.ORIGINAL_MENU),
    EXPERIMENTAL_V1(() -> AccessoriesMenuTypes.EXPERIMENTAL_MENU);

    public final Supplier<class_3917<? extends AccessoriesMenuBase>> supplier;

    AccessoriesMenuVariant(Supplier<class_3917<? extends AccessoriesMenuBase>> supplier) {
        this.supplier = supplier;
    }

    @Nullable
    public static AccessoriesMenuVariant getVariant(ScreenType screenType) {
        return switch (screenType) {
            case ORIGINAL -> ORIGINAL;
            case EXPERIMENTAL_V1 -> EXPERIMENTAL_V1;
            default -> null;
        };
    }

    public static AccessoriesMenuVariant getVariant(class_3917<? extends AccessoriesMenuBase> menuType) {
        for (var value : AccessoriesMenuVariant.values()) {
            if(value.supplier.get().equals(menuType)) return value;
        }

        throw new IllegalArgumentException("Unknown MenuType passed to get Accessories Menu Variant! [Type: " + class_7923.field_41187.method_10221(menuType) + "]");
    }

    public static class_1703 openMenu(int i, class_1661 inv, AccessoriesMenuVariant variant, @Nullable class_1309 target, @Nullable class_1799 carriedStack) {
        var menu = switch (variant) {
            case AccessoriesMenuVariant.EXPERIMENTAL_V1 -> new AccessoriesExperimentalMenu(i, inv, target);
            case ORIGINAL -> new AccessoriesMenu(i, inv, target);
            default -> throw new IllegalArgumentException("Unknown AccessoriesMenuVariant passed to construct Menu! [Variant: " + variant.name() + "]");
        };

        if(carriedStack != null) menu.method_34254(carriedStack);

        return menu;
    }
}
