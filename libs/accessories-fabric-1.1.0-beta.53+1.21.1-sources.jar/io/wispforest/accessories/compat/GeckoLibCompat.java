package io.wispforest.accessories.compat;

import org.jetbrains.annotations.ApiStatus;
import software.bernie.geckolib.util.InternalUtil;

import java.util.function.BiConsumer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;

@ApiStatus.Internal
public class GeckoLibCompat {
    public static <T extends class_1309, M extends class_572<T>, A extends class_572<T>> boolean renderGeckoArmor(class_4587 poseStack, class_4597 bufferSource, T entity, class_1799 stack, class_1304 equipmentSlot, M parentModel, A baseModel, float partialTicks, int light, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, BiConsumer<A, class_1304> partVisibilitySetter) {
        return InternalUtil.tryRenderGeoArmorPiece(poseStack, bufferSource, entity, stack, equipmentSlot, parentModel, baseModel, partialTicks, light, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, partVisibilitySetter);
    }
}
