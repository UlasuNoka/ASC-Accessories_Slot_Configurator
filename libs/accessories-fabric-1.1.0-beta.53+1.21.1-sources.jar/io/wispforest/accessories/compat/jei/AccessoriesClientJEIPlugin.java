package io.wispforest.accessories.compat.jei;

import I;
import Z;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.client.gui.AccessoriesExperimentalScreen;
import io.wispforest.accessories.client.gui.AccessoriesScreen;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.handlers.IGuiContainerHandler;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import net.minecraft.class_2960;
import net.minecraft.class_768;
import java.util.List;

@JeiPlugin
public class AccessoriesClientJEIPlugin implements IModPlugin {
    @Override
    public class_2960 getPluginUid() {
        return Accessories.of("main");
    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addGuiContainerHandler(AccessoriesScreen.class, new IGuiContainerHandler<>() {
            @Override
            public List<class_768> getGuiExtraAreas(AccessoriesScreen screen) {
                var leftPos = screen.leftPos();
                var topPos = screen.topPos();

                var bl = screen.method_17577().showingSlots();

                var x = leftPos - screen.getPanelWidth() - (bl ? 15 : 0);
                var y = topPos;

                var width = screen.getPanelWidth() + (bl ? 15 : 0) + 176;
                var height = screen.getPanelHeight();

                return List.of(new class_768(x, y, width, height));
            }
        });

        registration.addGuiContainerHandler(AccessoriesExperimentalScreen.class, new IGuiContainerHandler<AccessoriesExperimentalScreen>() {
            @Override
            public List<class_768> getGuiExtraAreas(AccessoriesExperimentalScreen screen) {
                return screen.componentsForExclusionAreas()
                        .map(rectangle -> new class_768(rectangle.x(), rectangle.y(), rectangle.width(), rectangle.height()))
                        .toList();
            }
        });
    }
}
