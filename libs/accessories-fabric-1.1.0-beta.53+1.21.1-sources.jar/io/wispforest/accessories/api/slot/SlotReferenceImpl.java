package io.wispforest.accessories.api.slot;

import net.minecraft.class_1309;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record SlotReferenceImpl(class_1309 entity, String slotName, int slot) implements SlotReference {

    public SlotReferenceImpl {
        if(slot < -1) {
            throw new IndexOutOfBoundsException("A given Slot Reference was attempted to be created with a negative index!");
        }
    }
}
