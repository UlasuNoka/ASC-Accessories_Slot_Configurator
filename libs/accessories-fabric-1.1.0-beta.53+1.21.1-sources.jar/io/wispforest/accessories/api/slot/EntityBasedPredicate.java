package io.wispforest.accessories.api.slot;

import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;

/**
 * Similar to {@link SlotBasedPredicate} but allows for {@link class_1309} if such is required
 */
public interface EntityBasedPredicate extends SlotBasedPredicate {

    TriState isValid(class_1937 level, @Nullable class_1309 entity, SlotType slotType, int slot, class_1799 stack);

    @Override
    default TriState isValid(class_1937 level, SlotType slotType, int slot, class_1799 stack) {
        return isValid(level, null, slotType, slot, stack);
    }
}
