package io.wispforest.accessories.api.attributes;

import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

public record AttributeModificationData(@Nullable String slotPath, class_6880<class_1320> attribute, class_1322 modifier) {

    public AttributeModificationData(class_6880<class_1320> attribute, class_1322 modifier) {
        this(null, attribute, modifier);
    }

    @Override
    public class_1322 modifier() {
        return (this.slotPath != null)
                ? new class_1322(modifier.comp_2447().method_45134((path) -> this.slotPath + "/" + path), modifier.comp_2449(), modifier.comp_2450())
                : modifier;
    }

    @Override
    public String toString() {
        return "AttributeModifierInstance[" +
                "attribute=" + this.attribute + ", " +
                "modifier=" + this.modifier +
                "slotPath=" + (this.slotPath != null ? this.slotPath : "none") +
                ']';
    }
}
