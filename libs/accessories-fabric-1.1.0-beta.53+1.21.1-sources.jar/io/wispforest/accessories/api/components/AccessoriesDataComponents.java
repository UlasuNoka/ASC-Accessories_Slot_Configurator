package io.wispforest.accessories.api.components;

import io.wispforest.accessories.Accessories;
import io.wispforest.endec.SerializationAttributes;
import io.wispforest.endec.SerializationContext;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.UnaryOperator;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class AccessoriesDataComponents {

    private static final SerializationContext BASE_CTX = SerializationContext.attributes(SerializationAttributes.HUMAN_READABLE);

    public static final class_9331<AccessoryNestContainerContents> NESTED_ACCESSORIES = register(Accessories.of("nested_accessories"),
            builder -> builder.endec(AccessoryNestContainerContents.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryRenderOverrideComponent> RENDER_OVERRIDE = register(Accessories.of("render_override"),
            builder -> builder.endec(AccessoryRenderOverrideComponent.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryRenderTransformations> RENDER_TRANSFORMATIONS = register(Accessories.of("render_transformations"),
            builder -> builder.endec(AccessoryRenderTransformations.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessorySlotValidationComponent> SLOT_VALIDATION = register(Accessories.of("slot_validation"),
            builder -> builder.endec(AccessorySlotValidationComponent.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryItemAttributeModifiers> ATTRIBUTES = register(Accessories.of("attributes"),
            builder -> builder.endec(AccessoryItemAttributeModifiers.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryStackSizeComponent> STACK_SIZE = register(Accessories.of("stack_size"),
            builder -> builder.endec(AccessoryStackSizeComponent.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryCustomRendererComponent> CUSTOM_RENDERER = register(Accessories.of("custom_renderer"),
            builder -> builder.endec(AccessoryCustomRendererComponent.ENDEC, BASE_CTX)
    );

    public static final class_9331<AccessoryItemCosmeticOverride> ITEM_MODEL_OVERRIDE = register(Accessories.of("item_cosmetic_override"),
            builder -> builder.endec(AccessoryItemCosmeticOverride.ENDEC, BASE_CTX)
    );

    private static <T> class_9331<T> register(class_2960 string, UnaryOperator<class_9331.class_9332<T>> unaryOperator) {
        return class_2378.method_10230(class_7923.field_49658, string, ((class_9331.class_9332)unaryOperator.apply(class_9331.method_57873())).method_57880());
    }

    @ApiStatus.Internal
    public static void init() {}
}
