package io.wispforest.accessories.api;

import net.minecraft.class_1792;

/**
 * Helper base class for accessory items with automatic registration.
 */
public class AccessoryItem extends class_1792 implements Accessory {
    public AccessoryItem(class_1793 properties) {
        super(properties);

        AccessoriesAPI.registerAccessory(this, this);
    }
}
