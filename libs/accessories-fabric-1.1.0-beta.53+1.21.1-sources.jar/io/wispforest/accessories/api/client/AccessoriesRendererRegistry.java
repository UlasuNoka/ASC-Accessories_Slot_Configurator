package io.wispforest.accessories.api.client;

import F;
import Z;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.client.rendering.ClientRenderingUtils;
import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import io.wispforest.accessories.api.components.AccessoryCustomRendererComponent;
import io.wispforest.accessories.api.components.AccessoryRenderOverrideComponent;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.impl.AccessoryNestUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5151;
import net.minecraft.class_583;
import net.minecraft.class_7923;
import net.minecraft.class_8921;
import net.minecraft.class_9276;
import net.minecraft.class_9334;

/**
 * Main class used to register and hold {@link AccessoryRenderer}'s. This contains a method to
 * reload all renders when a data reload occurs for the client combined with method to retrieve renders.
 */
public class AccessoriesRendererRegistry {

    private static final Logger LOGGER = LogUtils.getLogger();

    private static final Map<class_2960, Supplier<AccessoryRenderer>> RENDERERS = new HashMap<>();

    private static final BiMap<class_2960, AccessoryRenderer> CACHED_RENDERERS = HashBiMap.create();

    public static void registerRenderer(class_2960 location, Supplier<AccessoryRenderer> renderer) {
        RENDERERS.put(location, renderer);
    }

    /**
     * Main method used to register an {@link class_1792} with a given {@link AccessoryRenderer}
     */
    public static void registerRenderer(class_1792 item, Supplier<@NotNull AccessoryRenderer> renderer){
        registerRenderer(getRendererId(item), renderer);
    }

    /**
     * Method used to prevent default rendering for the given {@link class_1792}
     * <br/>
     * This should ONLY be used if ABSOLUTELY necessary
     */
    public static void registerNoRenderer(class_1792 item){
        registerRenderer(item, EmptyRenderer::new);
    }

    /**
     * Registers the given item as if it should render like armor piece equipped within the targeted slot
     * as dictated by {@link class_5151#method_7685()}
     */
    public static void registerArmorRendering(class_1792 item) {
        if (item instanceof class_5151 && !AccessoriesRendererRegistry.hasRenderer(item)) {
            AccessoriesRendererRegistry.registerRenderer(item, () -> new AccessoryArmorRenderer(){});
        }
    }

    public static boolean hasRenderer(class_1792 item) {
        return hasRenderer(class_7923.field_41178.method_10221(item));
    }

    public static boolean hasRenderer(class_2960 rendererId) {
        return RENDERERS.containsKey(rendererId);
    }

    //--

    /**
     * @return Either the {@link AccessoryRenderer} bound to the item or the instance of the {@link DefaultAccessoryRenderer}
     */
    public static AccessoryRenderer getRenderer(class_1799 stack){
        if (stack.method_57826(AccessoriesDataComponents.CUSTOM_RENDERER) && !stack.method_31574(class_1802.field_27023)) {
            return DataDrivenAccessoryRenderer.INSTANCE;
        }

        var renderOverrides = stack.method_57825(AccessoriesDataComponents.RENDER_OVERRIDE, AccessoryRenderOverrideComponent.DEFAULT);

        var defaultRenderOverride = renderOverrides.defaultRenderOverride();

        if(defaultRenderOverride != null) {
            if(defaultRenderOverride) {
                return DefaultAccessoryRenderer.INSTANCE;
            } else if(AccessoriesAPI.isDefaultAccessory(AccessoriesAPI.getOrDefaultAccessory(stack))) {
                return new EmptyRenderer();
            }
        }

        var armorRenderOverride = renderOverrides.useArmorRenderer();

        if(armorRenderOverride) {
            return ArmorRenderingExtension.RENDERER;
        }

        return getRenderer(stack.method_7909());
    }

    /**
     * @return Either the {@link AccessoryRenderer} bound to the item or the instance of the {@link DefaultAccessoryRenderer}
     */
    public static AccessoryRenderer getRenderer(class_1792 item){
        var id = getRendererId(item);
        var renderer = getRenderer(id);

        if (!CACHED_RENDERERS.containsKey(id)) {
            renderer = DefaultAccessoryRenderer.INSTANCE;
        }

        if(renderer instanceof EmptyRenderer && Accessories.config().clientOptions.forceNullRenderReplacement()) {
            renderer = DefaultAccessoryRenderer.INSTANCE;
        }

        return renderer == null ? new EmptyRenderer() : renderer;
    }

    @Nullable
    public static AccessoryRenderer getRenderer(class_2960 rendererId) {
        return CACHED_RENDERERS.get(rendererId);
    }

    @Nullable
    public static class_2960 getRendererId(AccessoryRenderer renderer) {
        return CACHED_RENDERERS.inverse().get(renderer);
    }

    //--

    public static class_2960 getRendererId(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    @ApiStatus.Internal
    public static void onReload() {
        CACHED_RENDERERS.clear();

        RENDERERS.forEach((rendererId, supplier) -> {
            var renderer = supplier.get();

            if (renderer == null) {
                LOGGER.warn("A given renderer [{}] was found to be returning a null renderer which is not advised as method to indicate no rendering!", rendererId);

                renderer = new EmptyRenderer();
            }

            var otherRendererId = CACHED_RENDERERS.inverse().get(renderer);

            if (otherRendererId != null) {
                LOGGER.warn("A given renderer [{}] was found to be shared by another renderer [{}], such will be wrapped to prevent crashing and should be reported!", rendererId, otherRendererId);

                renderer = new WrappedAccessoryRenderer(renderer);
            }

            CACHED_RENDERERS.put(rendererId, renderer);
        });
    }

    @ApiStatus.Internal
    public static class DataDrivenAccessoryRenderer implements AccessoryRenderer {

        public static final DataDrivenAccessoryRenderer INSTANCE = new DataDrivenAccessoryRenderer();

        @Override
        public <M extends class_1309> void render(class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            var data = stack.method_57824(AccessoriesDataComponents.CUSTOM_RENDERER);

            if (data == null) return;

            ClientRenderingUtils.handle(stack, reference.entity(), null, model, matrices, multiBufferSource, partialTicks,15728880, class_4608.field_21444, -1, data.renderingFunctions());
        }

        @Override
        public <M extends class_1309> void renderOnFirstPerson(class_1306 arm, class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light) {
            var data = stack.method_57824(AccessoriesDataComponents.CUSTOM_RENDERER);

            if (data == null) return;

            var targetEntity = reference.entity();

            var tickRateManager = targetEntity.method_37908().method_54719();

            var partialTicks = class_310.method_1551().method_60646().method_60637(!tickRateManager.method_54746(targetEntity));

            ClientRenderingUtils.handle(stack, targetEntity, arm, model, matrices, multiBufferSource, partialTicks,15728880, class_4608.field_21444, -1, data.renderingFunctions());
        }


        // TODO: ATTEMPT TO DEAL WITH ALWAYS RENDERING BY CHECKING THE TREE OF FUNCTIONS TO SEE IF SUCH EXISTS INSTAED OF ALWAYS TRUE
        @Override
        public boolean shouldRenderInFirstPerson(class_1306 arm, class_1799 stack, SlotReference reference) {
            return true;
        }
    }

    @ApiStatus.Internal
    private static class BundleAccessoryRenderer implements AccessoryRenderer {
        @Override
        public <M extends class_1309> void render(class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
            var contents = stack.method_57824(class_9334.field_49650);

            if (contents == null) return;

            DataDrivenAccessoryRenderer.INSTANCE.render(stack, reference, matrices, model, multiBufferSource, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch);

            if (contents.method_57421() instanceof List<class_1799> list) {
                for (int i = 0; i < list.size(); i++) {
                    var innerStack = list.get(i);

                    if (innerStack.method_7960()) continue;

                    var renderer = AccessoriesRendererRegistry.getRenderer(innerStack);

                    if (renderer.isEmpty()) continue;

                    matrices.method_22903();

                    try {
                        renderer.render(innerStack, AccessoryNestUtils.create(reference, i), matrices, model, multiBufferSource, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch);
                    } catch (Throwable e) {
                        throw new IllegalStateException("[BundleAccessoryRenderer] Unable to render a given inner item stack due the following error: ", e);
                    }

                    matrices.method_22909();
                }
            }
        }

        @Override
        public <M extends class_1309> void renderOnFirstPerson(class_1306 arm, class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light) {
            var contents = stack.method_57824(class_9334.field_49650);

            if (contents == null) return;

            DataDrivenAccessoryRenderer.INSTANCE.renderOnFirstPerson(arm, stack, reference, matrices, model, multiBufferSource, light);

            if (contents.method_57421() instanceof List<class_1799> list) {
                for (int i = 0; i < list.size(); i++) {
                    var innerStack = list.get(i);

                    if (innerStack.method_7960()) continue;

                    var renderer = AccessoriesRendererRegistry.getRenderer(innerStack);

                    var ref = AccessoryNestUtils.create(reference, i);

                    if (renderer.isEmpty() || !renderer.shouldRenderInFirstPerson(arm, innerStack, ref)) continue;

                    matrices.method_22903();

                    try {
                        renderer.renderOnFirstPerson(arm, innerStack, ref, matrices, model, multiBufferSource, light);
                    } catch (Throwable e) {
                        throw new IllegalStateException("[BundleAccessoryRenderer] Unable to render a given inner item stack due the following error: ", e);
                    }

                    matrices.method_22909();
                }
            }
        }
    }

    static {
        AccessoriesRendererRegistry.registerRenderer(class_1802.field_27023, BundleAccessoryRenderer::new);
    }

    /**
     * @deprecated Use {@link #getRenderer(class_1799)}
     */
    @Deprecated(forRemoval = true)
    public static AccessoryRenderer getRender(class_1799 stack){
        return getRenderer(stack);
    }

    /**
     * @deprecated Use {@link #getRenderer(class_1792)}
     */
    @Deprecated(forRemoval = true)
    public static AccessoryRenderer getRender(class_1792 item){
        return getRenderer(item);
    }
}