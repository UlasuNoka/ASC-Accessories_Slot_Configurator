package io.wispforest.accessories.api.client;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.mixin.client.LivingEntityRendererAccessor;
import java.util.Optional;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5151;
import net.minecraft.class_583;
import net.minecraft.class_897;

public interface AccessoryArmorRenderer extends AccessoryRenderer {
    @Override
    default <M extends class_1309> void render(class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        var entityRender = class_310.method_1551().method_1561().method_3953(reference.entity());

        if (!(entityRender instanceof LivingEntityRendererAccessor<?, ?> accessor)) return;

        if (!(stack.method_7909() instanceof class_5151 equipable)) return;

        var equipmentSlot = equipable.method_7685();

        var possibleLayer = accessor.getLayers().stream()
                .filter(renderLayer -> renderLayer instanceof ArmorRenderingExtension)
                .findFirst();

        possibleLayer.ifPresent(layer -> ((ArmorRenderingExtension) layer).renderEquipmentStack(stack, matrices, multiBufferSource, reference.entity(), equipmentSlot, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch));
    }
}
