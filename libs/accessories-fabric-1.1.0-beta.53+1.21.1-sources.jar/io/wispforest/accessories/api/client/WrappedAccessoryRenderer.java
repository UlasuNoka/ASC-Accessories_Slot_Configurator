package io.wispforest.accessories.api.client;

import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;

public class WrappedAccessoryRenderer implements AccessoryRenderer {

    private final AccessoryRenderer delegate;

    public WrappedAccessoryRenderer(AccessoryRenderer delegate) {
        this.delegate = delegate;
    }

    @Override
    public <M extends class_1309> void render(class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        delegate.render(stack, reference, matrices, model, multiBufferSource, light, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch);
    }

    @Override
    public boolean shouldRender(boolean isRendering) {
        return delegate.shouldRender(isRendering);
    }

    @Override
    public boolean shouldRenderInFirstPerson(class_1306 arm, class_1799 stack, SlotReference reference) {
        return delegate.shouldRenderInFirstPerson(arm, stack, reference);
    }

    @Override
    public <M extends class_1309> void renderOnFirstPerson(class_1306 arm, class_1799 stack, SlotReference reference, class_4587 matrices, class_583<M> model, class_4597 multiBufferSource, int light) {
        delegate.renderOnFirstPerson(arm, stack, reference, matrices, model, multiBufferSource, light);
    }
}
