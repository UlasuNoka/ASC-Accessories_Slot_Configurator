package io.wispforest.accessories.api.client.rendering;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import io.wispforest.accessories.client.ClientDelayedCache;
import io.wispforest.accessories.data.CustomRendererLoader;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_583;
import net.minecraft.class_827;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import org.slf4j.Logger;

import java.lang.ref.SoftReference;
import java.util.*;

@ApiStatus.Experimental
@Environment(EnvType.CLIENT)
public class ClientRenderingUtils {

    private static final ClientDelayedCache<ParticleTimeKey> PARTICLE_UPDATE_CACHE = new ClientDelayedCache<>();

    public static void handle(class_1799 stack, class_1309 targetEntity, @Nullable class_1306 arm, class_583<? extends class_1309> entityModel, class_4587 poseStack, class_4597 buffer, float partialTicks, int packedLight, int packedOverlay, int color, List<RenderingFunction> functions) {
        handle(class_1799.method_57355(stack), targetEntity, arm, entityModel, poseStack, buffer, partialTicks, packedLight, packedOverlay, color, functions);
    }
    private static final Map<class_1299, EntityData> ENTITY_CACHE = new HashMap<>();

    private static final class EntityData {
        private final class_2487 defaultData;

        private @Nullable SoftReference<class_1297> reference;
        private boolean wasSpawnable;

        private EntityData(@Nullable SoftReference<class_1297> reference, class_2487 defaultData, boolean wasSpawnable) {
            this.reference = reference;
            this.defaultData = defaultData;
            this.wasSpawnable = wasSpawnable;
        }

        private boolean canBeGotten() {
            return reference != null && reference.get() != null;
        }

        public @Nullable SoftReference<class_1297> reference() {
            return reference;
        }

        public void resetEntity() {
            if (this.reference == null) return;

            var entity = this.reference.get();

            if (entity == null) return;

            try {
                entity.method_5651(defaultData);
            } catch (Exception ignored) {}
        }

        public void createNewReference(class_1299 type, class_1937 level) {
            var entity = type.method_5883(level);

            if (entity == null) {
                this.wasSpawnable = false;

                return;
            }

            this.reference = new SoftReference<>(entity);
        }

        public class_2487 defaultData() {
            return defaultData;
        }

        public boolean wasSpawnable() {
            return wasSpawnable;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (EntityData) obj;
            return Objects.equals(this.reference, that.reference) &&
                    Objects.equals(this.defaultData, that.defaultData) &&
                    this.wasSpawnable == that.wasSpawnable;
        }

        @Override
        public int hashCode() {
            return Objects.hash(reference, defaultData, wasSpawnable);
        }

        @Override
        public String toString() {
            return "EntityData[" +
                    "reference=" + reference + ", " +
                    "defaultData=" + defaultData + ", " +
                    "wasSpawnable=" + wasSpawnable + ']';
        }
    }

    public static void handle(int uniqueKey, class_1309 targetEntity, @Nullable class_1306 arm, class_583<? extends class_1309> entityModel, class_4587 poseStack, class_4597 buffer, float partialTicks, int packedLight, int packedOverlay, int color, List<RenderingFunction> functions) {
        var client = Minecraft.getInstance();
        var level = Minecraft.getInstance().level;

        for (var function : functions) {
            switch (function) {
                case RenderingFunction.Transformation transformation -> {
                    ClientTransformationUtils.transformStack(transformation.transformations(), poseStack, targetEntity, entityModel, () -> handle(uniqueKey, targetEntity, arm, entityModel, poseStack, buffer, partialTicks, packedLight, packedOverlay, color, List.of(transformation.renderingFunction())));
                }
                case RenderingFunction.Block blockData -> {
                    var state = blockData.state();
                    var blockEntity = (blockData.type() != null) ? net.minecraft.world.level.block.entity.BlockEntity.loadStatic(BlockPos.ZERO, blockData.state(), blockData.data(), level.registryAccess()) : null;

                    poseStack.pushPose();

                    poseStack.translate(-0.5, 0, -0.5);

                    renderBlock(client, state, blockEntity, 0, poseStack, buffer, packedLight, packedOverlay, color);

                    poseStack.popPose();
                }
                case RenderingFunction.Entity entityData -> {
                    try {
                        var currentEntityData = ENTITY_CACHE.computeIfAbsent(entityData.entityType(), entityType -> {
                            var entity = entityData.entityType().create(level);

                            if (entity != null) {
                                var defaultData = entity.saveWithoutId(new CompoundTag());

                                return new EntityData(new SoftReference<>(entity), defaultData, true);
                            }

                            return new EntityData(null, new CompoundTag(), false);
                        });

                        if (!currentEntityData.wasSpawnable()) continue;

                        if (!currentEntityData.canBeGotten()) {
                            currentEntityData.createNewReference(entityData.entityType(), level);
                        }

                        if (!currentEntityData.wasSpawnable()) continue;

                        Entity entity = currentEntityData.reference().get();

                        if (entity == null) continue;

                        boolean customData = false;

                        if (!entityData.data().isEmpty()) {
                            customData = true;

                            entity.load(entityData.data());
                        }

                        if (entityData.allowTicking() || entity instanceof Display) entity.tick();

                        client.getEntityRenderDispatcher()
                                .render(entity, 0, 0, 0, 0, partialTicks, poseStack, buffer, packedLight);

                        if (customData) {
                            currentEntityData.resetEntity();
                        }
                    } catch (Exception e) {
                        continue;
                    }
                }
                case RenderingFunction.Item itemData -> {
                    ItemStack stack = itemData.stack();

                    client.getItemRenderer().render(
                            stack,
                            ItemDisplayContext.GUI,
                            false,
                            poseStack,
                            buffer,
                            packedLight,
                            packedOverlay,
                            client.getItemRenderer().getModel(stack, level, null, 0)
                    );
                }
                case RenderingFunction.Model modelData -> {
                    var model = Minecraft.getInstance().getModelManager().getModel(new ModelResourceLocation(modelData.id(), modelData.variant()));

                    client.getItemRenderer().render(
                            Items.BEDROCK.getDefaultInstance(),
                            ItemDisplayContext.GROUND,
                            false,
                            poseStack,
                            buffer,
                            packedLight,
                            packedOverlay,
                            model
                    );
                }
                case RenderingFunction.Particle particleData -> {
                    if (PARTICLE_UPDATE_CACHE.hasAllottedTime(new ParticleTimeKey(targetEntity.getUUID(), uniqueKey, particleData), particleData.delay())) {
                        var pos = new Vector3f(0, 0, 0)
                                .mulPosition(poseStack.last().pose())
                                .add(Minecraft.getInstance().gameRenderer.getMainCamera().getPosition().toVector3f());

                        renderParticle(level, particleData, pos.x(), pos.y(), pos.z());
                    }
                }
                case RenderingFunction.Compound compoundFunction -> {
                    if (arm == null || compoundFunction.firstPersonArmTarget().hasArm(arm)) {
                        handle(uniqueKey, targetEntity, arm, entityModel, poseStack, buffer, partialTicks, packedLight, packedOverlay, color, compoundFunction.renderingFunctions());
                    }
                }
                case CustomDataRenderer renderer -> {
                    var renderFunction = CustomRendererLoader.getOrResolveRenderer(renderer, !CustomRendererLoader.isConstantResolveTarget());

                    if(renderFunction != null) handle(uniqueKey, targetEntity, arm, entityModel, poseStack, buffer, partialTicks, packedLight, packedOverlay, color, List.of(renderFunction));
                }
                default -> throw new IllegalStateException("Unimplemented RendererFunc: " + function.key());
            }
        }
    }

    private static final Logger LOGGER = LogUtils.getLogger();

    private static void renderParticle(class_1937 level, RenderingFunction.Particle particle, double x, double y, double z) {
        var random = level.method_8409();

        try {
            if (particle.count() == 0) {
                double xSpd = particle.speed() * particle.delta().x();
                double ySpd = particle.speed() * particle.delta().y();
                double zSpd = particle.speed() * particle.delta().z();

                level.method_8466(particle.particleData(), particle.force(), x, y, z, xSpd, ySpd, zSpd);
            } else {
                for (int i = 0; i < particle.count(); i++) {
                    double g = random.method_43059() * particle.delta().x();
                    double h = random.method_43059() * particle.delta().y();
                    double j = random.method_43059() * particle.delta().z();

                    double k = random.method_43059() * (double)particle.speed();
                    double l = random.method_43059() * (double)particle.speed();
                    double m = random.method_43059() * (double)particle.speed();

                    level.method_8466(particle.particleData(), particle.force(), x + g, y + h, z + j, k, l, m);
                }
            }
        } catch (Throwable var16) {
            LOGGER.warn("Could not spawn particle effect {}", particle.particleData());
        }
    }

    private static void renderBlock(class_310 client, class_2680 state, @Nullable class_2586 blockEntity, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, int packedOverlay, int color) {
        RenderSystem.runAsFancy(() -> {
            if (state.method_26217() != class_2464.field_11456) {
                client.method_1541().method_3353(state, poseStack, buffer, packedLight, packedOverlay);
            }

            if (blockEntity != null) {
                class_827<class_2586> медведь = client.method_31975().method_3550(blockEntity);
                if (медведь != null) {
                    медведь.method_3569(blockEntity, partialTick, poseStack, buffer, 15728880, class_4608.field_21444);
                }
            }

//            if (buffer instanceof MultiBufferSource.BufferSource || buffer instanceof OutlineBufferSource) {
//                RenderSystem.setShaderLights(new Vector3f(-1.5F, -0.5F, 0.0F), new Vector3f(0.0F, -1.0F, 0.0F));
//                if (buffer instanceof MultiBufferSource.BufferSource bufferSource) {
//                    bufferSource.endBatch();
//                } else if (buffer instanceof OutlineBufferSource outlineBufferSource) {
//                    outlineBufferSource.endOutlineBatch();
//                }
//                Lighting.setupFor3DItems();
//            }
        });
    }

    private record ParticleTimeKey(UUID entityUUID, int uniqueKey, RenderingFunction.Particle particleData) {

    }
}
