package io.wispforest.accessories.api.client.rendering;

import com.google.common.base.CaseFormat;
import com.google.common.base.Supplier;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.wispforest.accessories.Accessories;
import io.wispforest.accessories.utils.EndecUtils;
import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.format.edm.EdmElement;
import io.wispforest.endec.format.edm.EdmSerializer;
import io.wispforest.endec.impl.StructEndecBuilder;
import io.wispforest.owo.serialization.CodecUtils;
import io.wispforest.owo.serialization.endec.MinecraftEndecs;
import io.wispforest.owo.serialization.format.nbt.NbtEndec;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import java.lang.reflect.Field;
import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

@ApiStatus.Experimental
public sealed interface RenderingFunction permits CustomDataRenderer, RenderingFunction.Block, RenderingFunction.Compound, RenderingFunction.Conditional, RenderingFunction.Entity, RenderingFunction.Item, RenderingFunction.Model, RenderingFunction.Particle, RenderingFunction.Transformation {

    static Transformation ofTransformation(List<io.wispforest.accessories.api.client.Transformation> transformations, RenderingFunction innerRendering) {
        return new Transformation(transformations, innerRendering);
    }

    static Model ofModel(class_2960 id, String variant) {
        return new Model(id, variant);
    }

    static Block ofBlock(net.minecraft.class_2248 block) {
        return ofBlock(block.method_9564());
    }

    static Block ofBlock(class_2680 state) {
        return new Block(state, null, new class_2487());
    }

    static Block ofBlockEntity(net.minecraft.class_2248 block, class_2591<? extends net.minecraft.class_2586> type, class_1937 level) {
        return ofBlockEntity(block.method_9564(), type, level);
    }

    static Block ofBlockEntity(class_2680 blockState, class_2591<? extends net.minecraft.class_2586> type, class_1937 level) {
        var blockEntity = type.method_11032(class_2338.field_10980, blockState);

        if (blockEntity == null) throw new IllegalStateException("Unable to create render function of the given block entity");

        return ofBlockEntity(blockState, type, blockEntity.method_38244(level.method_30349()));
    }

    static Block ofBlockEntity(class_2680 blockState, class_2591<? extends net.minecraft.class_2586> type, class_2487 data) {
        return new Block(blockState, type, data);
    }

    static Item ofItem(class_1799 stack) {
        return new Item(stack);
    }

    static Entity ofEntity(class_1299<? extends net.minecraft.class_1297> entityType, class_1937 level) {
        var entity = entityType.method_5883(level);
        if (entity == null) throw new IllegalStateException("Unable to create render function of the given entity");

        var compound = new class_2487();

        String string = entity.method_5653();
        if (string == null) throw new IllegalStateException("Unable to create render function of the given entity");

        compound.method_10582("id", string);
        entity.method_5647(compound);

        return new Entity(entityType, compound, true);
    }

    static Entity ofEntity(class_1299<? extends net.minecraft.class_1297> entityType, class_2487 data) {
        return new Entity(entityType, data, true);
    }

    static Particle ofParticle(class_2960 uniqueId, float delay, class_2394 particleData, Vector3f delta, float speed, int count, boolean force) {
        return new Particle(uniqueId, delay, particleData, delta, speed, count, force);
    }

    //--

    Endec<RenderingFunction> ENDEC = Endec.dispatchedStruct(
            key -> switch (key) {
                case "transformation" -> RenderingFunction.Transformation.ENDEC;
                case "model" -> RenderingFunction.Model.ENDEC;
                case "block" -> RenderingFunction.Block.ENDEC;
                case "item" -> RenderingFunction.Item.ENDEC;
                case "entity" -> RenderingFunction.Entity.ENDEC;
                case "particle" -> RenderingFunction.Particle.ENDEC;
                case "compound" -> RenderingFunction.Compound.ENDEC;
                case "renderer" -> CustomDataRenderer.ENDEC;
                case "conditional" -> RenderingFunction.Conditional.ENDEC;
                default -> throw new IllegalStateException("A invalid rendering function was created meaning such is unable to be decoded!");
            },
            RenderingFunction::key,
            Endec.STRING,
            "type"
    );

    default String key() {
        return CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, this.getClass().getSimpleName());
    }

    record Transformation(List<io.wispforest.accessories.api.client.Transformation> transformations, RenderingFunction renderingFunction) implements RenderingFunction {
        public static final StructEndec<Transformation> ENDEC = StructEndecBuilder.of(
                io.wispforest.accessories.api.client.Transformation.ENDEC.listOf().fieldOf("transformations", Transformation::transformations),
                RenderingFunction.ENDEC.fieldOf("rendering_function", Transformation::renderingFunction),
                Transformation::new
        );
    }

    record Model(class_2960 id, String variant) implements RenderingFunction {
        public static final StructEndec<Model> ENDEC = StructEndecBuilder.of(
                MinecraftEndecs.IDENTIFIER.fieldOf("id", Model::id),
                Endec.STRING.optionalFieldOf("variant", Model::variant, () -> ""),
                Model::new
        );
    }

    record Block(class_2680 state, @Nullable class_2591<?> type, class_2487 data) implements RenderingFunction {
        public static final StructEndec<Block> ENDEC = StructEndecBuilder.of(
                EndecUtils.blockStateEndec("id").flatFieldOf(Block::state),
                CodecUtils.toEndec(class_7923.field_41181.method_39673()).optionalFieldOf("entity_id", Block::type, (class_2591<?>) null),
                NbtEndec.COMPOUND.optionalFieldOf("data", Block::data, class_2487::new),
                Block::new
        );
    }

    record Item(class_1799 stack) implements RenderingFunction {
        public static final StructEndec<Item> ENDEC = StructEndecBuilder.of(
                new EndecUtils.LazyStructEndec<>(() -> {
                    var baseCodec = class_1799.field_24671;

                    try {
                        var field = baseCodec.getClass().getDeclaredField("wrapped");

                        field.setAccessible(true);

                        var supplier = (Supplier<Codec<class_1799>>) field.get(baseCodec);

                        return CodecUtils.toStructEndec(((MapCodec.MapCodecCodec<class_1799>) supplier.get()).codec());
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }
                }).flatFieldOf(Item::stack),
                Item::new
        );
    }

    record Entity(class_1299<?> entityType, class_2487 data, boolean allowTicking) implements RenderingFunction {
        public static final StructEndec<Entity> ENDEC = StructEndecBuilder.of(
                CodecUtils.toEndec(class_7923.field_41177.method_39673()).fieldOf("entity_id", Entity::entityType),
                NbtEndec.COMPOUND.optionalFieldOf("stack", Entity::data, class_2487::new),
                Endec.BOOLEAN.optionalFieldOf("allow_ticking", Entity::allowTicking, false),
                Entity::new
        );
    }

    record Particle(class_2960 uniqueId, float delay, class_2394 particleData, Vector3f delta, float speed, int count, boolean force) implements RenderingFunction {
        private static final Endec<class_2394> PARTICLE_OPTIONS_ENDEC = CodecUtils.toEndec(class_2398.field_25125);

        public static final StructEndec<Particle> ENDEC = StructEndecBuilder.of(
                MinecraftEndecs.IDENTIFIER.optionalFieldOf("unique_id", Particle::uniqueId, () -> Accessories.of("shared")),
                Endec.FLOAT.optionalFieldOf("delay", Particle::delay, () -> 20f),
                PARTICLE_OPTIONS_ENDEC.fieldOf("particle_data", Particle::particleData),
                EndecUtils.VECTOR_3_F_ENDEC.flatFieldOf(Particle::delta),
                Endec.FLOAT.optionalFieldOf("speed", Particle::speed, 1f),
                Endec.INT.optionalFieldOf("count", Particle::count, 1),
                Endec.BOOLEAN.optionalFieldOf("force", Particle::force, false),
                Particle::new
        );

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            if (obj == null || obj.getClass() != this.getClass()) return false;
            var that = (Particle) obj;

            var rawParticleData = PARTICLE_OPTIONS_ENDEC.encodeFully(EdmSerializer::of, this.particleData);
            var thatRawParticleData = PARTICLE_OPTIONS_ENDEC.encodeFully(EdmSerializer::of, that.particleData);

            return Objects.equals(rawParticleData, thatRawParticleData) &&
                    Objects.equals(this.delta, that.delta) &&
                    Float.floatToIntBits(this.speed) == Float.floatToIntBits(that.speed) &&
                    this.count == that.count &&
                    this.force == that.force;
        }

        @Override
        public int hashCode() {
            return Objects.hash(PARTICLE_OPTIONS_ENDEC.encodeFully(EdmSerializer::of, this.particleData), delta, speed, count, force);
        }

        @Override
        public String toString() {
            return "Particle[" +
                    "particleData=" + particleData + ", " +
                    "delta=" + delta + ", " +
                    "speed=" + speed + ", " +
                    "count=" + count + ", " +
                    "force=" + force + ']';
        }
    }

    record Compound(List<RenderingFunction> renderingFunctions, ArmTarget firstPersonArmTarget) implements RenderingFunction {
        public static final StructEndec<Compound> ENDEC = StructEndecBuilder.of(
                RenderingFunction.ENDEC.listOf().fieldOf("rendering_functions", Compound::renderingFunctions),
                Endec.forEnum(ArmTarget.class).optionalFieldOf("first_person_arm_target", Compound::firstPersonArmTarget, () -> ArmTarget.NONE),
                Compound::new
        );
    }

    record Conditional(List<RenderingFunctionPredicate> predicates, RenderingFunction renderingFunction) implements RenderingFunction {
        public static final StructEndec<Conditional> ENDEC = StructEndecBuilder.of(
                RenderingFunctionPredicate.ENDEC.listOf().fieldOf("predicates", Conditional::predicates),
                RenderingFunction.ENDEC.fieldOf("rendering_function", Conditional::renderingFunction),
                Conditional::new
        );
    }

    enum ArmTarget {
        LEFT(class_1306.field_6182),
        RIGHT(class_1306.field_6183),
        BOTH(class_1306.field_6182, class_1306.field_6183),
        NONE;

        private final Set<class_1306> arms;

        ArmTarget(class_1306 ...arms){
            var result = EnumSet.noneOf(class_1306.class);

            result.addAll(Set.of(arms));

            this.arms = result;
        }

        public final boolean hasArm(class_1306 arm){
            return this.arms.contains(arm);
        }
    }
}
