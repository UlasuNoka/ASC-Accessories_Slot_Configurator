package io.wispforest.accessories.api.client;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.mixin.client.LivingEntityRendererAccessor;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public interface ArmorRenderingExtension<T extends class_1309> {

    @Deprecated
    AccessoryRenderer RENDERER = new AccessoryArmorRenderer() {};

    default void renderEquipmentStack(class_1799 stack, class_4587 poseStack, class_4597 multiBufferSource, T livingEntity, class_1304 equipmentSlot, int light, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
        throw new IllegalStateException("Injected interface method is unimplemented!");
    }
}