package io.wispforest.accessories.api.client;

import io.wispforest.endec.Endec;
import net.minecraft.class_2350;
import net.minecraft.class_2382;

/**
 * Class acting as a wrapper around {@link class_2350} with easy
 * to understand names used within rendering
 */
public enum Side {
    BOTTOM(class_2350.field_11033),
    TOP(class_2350.field_11036),
    BACK(class_2350.field_11043),
    FRONT(class_2350.field_11035),
    LEFT(class_2350.field_11039),
    RIGHT(class_2350.field_11034);

    public static final Endec<Side> ENDEC = Endec.forEnum(Side.class);

    public final class_2350 direction;

    Side(class_2350 direction) {
        this.direction = direction;
    }

    public class_2382 rotationAxis() {
        return this.direction.method_10163();
    }
}