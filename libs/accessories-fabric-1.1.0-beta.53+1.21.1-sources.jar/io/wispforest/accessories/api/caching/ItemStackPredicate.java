package io.wispforest.accessories.api.caching;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_1799;

public class ItemStackPredicate extends ItemStackBasedPredicate {
    private final Predicate<class_1799> predicate;

    public ItemStackPredicate(String name, Predicate<class_1799> predicate) {
        super(name);

        this.predicate = predicate;
    }

    @Override
    public boolean test(class_1799 stack) {
        return this.predicate.test(stack);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.predicate);
    }

    @Override
    protected boolean isEqual(Object other) {
        var itemPredicate = (ItemStackPredicate) other;

        return this.predicate.equals(itemPredicate.predicate);
    }

    @Override
    public String extraStringData() {
        return "Predicate: " + this.predicate.toString();
    }
}
