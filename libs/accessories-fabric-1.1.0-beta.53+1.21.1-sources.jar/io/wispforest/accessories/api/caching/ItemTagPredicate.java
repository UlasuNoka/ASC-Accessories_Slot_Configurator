package io.wispforest.accessories.api.caching;

import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_6862;

public class ItemTagPredicate extends ItemStackBasedPredicate{

    private final class_6862<class_1792> itemTagKey;

    public ItemTagPredicate(String name, class_6862<class_1792> itemTagKey) {
        super(name);
        this.itemTagKey = itemTagKey;
    }

    @Override
    public boolean test(class_1799 stack) {
        return stack.method_31573(this.itemTagKey);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.itemTagKey);
    }

    @Override
    protected boolean isEqual(Object other) {
        var itemTagPredicate = (ItemTagPredicate) other;

        return this.itemTagKey.equals(itemTagPredicate.itemTagKey);
    }

    @Override
    public String extraStringData() {
        return "ItemTag: " + this.itemTagKey.toString();
    }
}
