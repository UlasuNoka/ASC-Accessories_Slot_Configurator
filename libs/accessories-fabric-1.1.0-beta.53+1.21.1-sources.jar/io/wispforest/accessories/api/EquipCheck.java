package io.wispforest.accessories.api;

import net.minecraft.class_1799;

public interface EquipCheck {
    boolean isValid(class_1799 stack, boolean isSwapping);
}
