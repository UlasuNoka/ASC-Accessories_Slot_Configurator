package io.wispforest.accessories.api.events.extra;

import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.impl.event.WrappedEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_173;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_3218;
import net.minecraft.class_47;
import net.minecraft.class_47.class_48;
import net.minecraft.class_8567;
import java.util.Optional;

/**
 * @deprecated Use {@link io.wispforest.accessories.api.events.extra.v2.LootingAdjustment} instead!
 */
@Deprecated(forRemoval = true)
public interface LootingAdjustment {

    @Deprecated(forRemoval = true)
    Event<LootingAdjustment> EVENT = new WrappedEvent<>(
            io.wispforest.accessories.api.events.extra.v2.LootingAdjustment.EVENT,
            (adjustment) -> (stack, reference, target, context, damageSource, currentLevel) -> adjustment.getLootingAdjustment(stack, reference, target, damageSource, currentLevel),
            lootingAdjustmentEvent -> {
                return (stack, reference, target, damageSource, currentLevel) -> {
                    var contextBuilder = new class_47.class_48(
                            new class_8567.class_8568((class_3218) reference.entity().method_37908())
                                    .method_51874(class_181.field_1226, reference.entity())
                                    .method_51874(class_181.field_24424, reference.entity().method_19538())
                                    .method_51874(class_181.field_1231, damageSource)
                                    .method_51874(class_181.field_1230, target)
                                    .method_51875(class_173.field_1173)
                    );

                    return lootingAdjustmentEvent.invoker().getLootingAdjustment(stack, reference, target, contextBuilder.method_309(Optional.empty()), damageSource, currentLevel);
                };
            }
    );

    int getLootingAdjustment(class_1799 stack, SlotReference reference, class_1309 target, class_1282 damageSource, int currentLevel);
}
