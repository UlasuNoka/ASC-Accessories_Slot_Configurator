package io.wispforest.accessories.api;

import io.wispforest.accessories.api.slot.SlotReference;
import net.minecraft.class_1799;
import net.minecraft.class_3414;
import net.minecraft.class_6880;

/**
 * Represents a sound event with volume and pitch data.
 *
 * @see Accessory#getEquipSound(class_1799, SlotReference)
 */
public record SoundEventData(class_6880<class_3414> event, float volume, float pitch) { }
