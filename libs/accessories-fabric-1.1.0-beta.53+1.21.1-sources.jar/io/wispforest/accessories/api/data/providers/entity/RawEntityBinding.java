package io.wispforest.accessories.api.data.providers.entity;

import io.wispforest.endec.Endec;
import io.wispforest.endec.StructEndec;
import io.wispforest.endec.impl.BuiltInEndecs;
import io.wispforest.endec.impl.StructEndecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public record RawEntityBinding(Optional<Boolean> replace, List<class_6862<class_1299<?>>> tags, List<class_1299<?>> entityTypes, List<String> slots) {

    public static final StructEndec<RawEntityBinding> ENDEC = StructEndecBuilder.of(
            Endec.BOOLEAN.optionalOf().optionalFieldOf("replace", RawEntityBinding::replace, Optional.empty()),
            Endec.STRING.listOf().fieldOf("entities", rawEntityBinding -> {
                return Stream.concat(
                        rawEntityBinding.tags().stream().map(tag -> "#" + tag.comp_327()),
                        rawEntityBinding.entityTypes().stream().map(entityType -> class_7923.field_41177.method_10221(entityType).toString())
                ).toList();
            }),
            Endec.STRING.listOf().fieldOf("slots", RawEntityBinding::slots),
            (replace, entities, slots) -> {
                var tags = new ArrayList<class_6862<class_1299<?>>>();
                var entityTypes = new ArrayList<class_1299<?>>();

                for (var entity : entities) {
                    if(entity.charAt(0) == '#') {
                        var tag = class_6862.method_40092(class_7924.field_41266, class_2960.method_60654(entity.replace("#", "")));

                        tags.add(tag);
                    } else {
                        var entityType = class_7923.field_41177.method_31140(class_5321.method_29179(class_7924.field_41266, class_2960.method_60654(entity)));

                        entityTypes.add(entityType);
                    }
                }

                return new RawEntityBinding(replace, tags, entityTypes, slots);
            }
    );
}
