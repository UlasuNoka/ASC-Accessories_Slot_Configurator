package io.wispforest.accessories.api.data.providers.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_6862;

public class EntityBindingBuilder {

    private final boolean replace;

    private final List<class_6862<class_1299<?>>> tags = new ArrayList<>();
    private final List<class_1299<?>> entityTypes = new ArrayList<>();
    private final List<String> slots = new ArrayList<>();

    public EntityBindingBuilder(boolean replace) {
        this.replace = replace;
    }

    @SafeVarargs
    public final EntityBindingBuilder tag(class_6862<class_1299<?>>... tagKeys) {
        this.tags.addAll(List.of(tagKeys));

        return this;
    }

    public final EntityBindingBuilder entityType(class_1299<?>... entityTypes) {
        this.entityTypes.addAll(List.of(entityTypes));

        return this;
    }

    public final EntityBindingBuilder slots(String... slots) {
        this.slots.addAll(List.of(slots));

        return this;
    }

    public RawEntityBinding create() {
        return new RawEntityBinding(
                this.replace ? Optional.of(true) : Optional.empty(),
                this.tags,
                this.entityTypes,
                this.slots
        );
    }
}
