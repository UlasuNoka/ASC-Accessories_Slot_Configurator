package io.wispforest.accessories.mixin.client.owo;

import io.wispforest.accessories.pond.owo.ComponentExtension;
import io.wispforest.owo.ui.core.Component;
import io.wispforest.owo.ui.util.ScissorStack;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = ScissorStack.class)
public abstract class ScissorStackMixin {

    @Inject(method = "isVisible(Lio/wispforest/owo/ui/core/Component;Lcom/mojang/blaze3d/vertex/PoseStack;)Z", at = @At("HEAD"), cancellable = true)
    private static void accessories$allowIndividualOverdraw(Component component, class_4587 matrices, CallbackInfoReturnable<Boolean> cir) {
        if(component instanceof ComponentExtension<?> extension && extension.allowIndividualOverdraw()) {
            cir.setReturnValue(true);
        }
    }
}
