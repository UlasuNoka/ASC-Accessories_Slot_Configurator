package io.wispforest.accessories.mixin.client;

import Z;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.ContainerScreenExtension;
import net.minecraft.class_1058;
import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin implements ContainerScreenExtension {

    @Shadow protected abstract void renderSlot(class_332 guiGraphics, class_1735 slot);

    @Inject(method = "isHovering(Lnet/minecraft/world/inventory/Slot;DD)Z", at = @At("HEAD"), cancellable = true)
    private void accessories$isHoveringOverride(class_1735 slot, double mouseX, double mouseY, CallbackInfoReturnable<Boolean> cir){
        var override = this.isHovering_Logical(slot, mouseX, mouseY);

        if(override != null) cir.setReturnValue(override);
    }

    @Inject(method = "renderSlot", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V"), cancellable = true)
    private void accessories$shouldRenderSlot(class_332 guiGraphics, class_1735 slot, CallbackInfo ci) {
        if(accessories$bypassSlotCheck) return;

        var result = this.shouldRenderSlot(slot);

        if(result != null && !result) ci.cancel();
    }

    @WrapOperation(method = "renderSlot", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blit(IIIIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;)V"))
    private void accessories$adjustFor18x18(class_332 instance, int x, int y, int blitOffset, int width, int height, class_1058 sprite, Operation<Void> original) {
        var is18x18 = sprite.method_45851().method_45807() == 18 && sprite.method_45851().method_45815() == 18;

        if(is18x18) {
            width = 18;
            height = 18;

            x = x - 1;
            y = y - 1;
        }

        original.call(instance, x, y, blitOffset, width, height, sprite);
    }

    @WrapOperation(method = "renderFloatingItem", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"))
    private void accessories$adjustZOffset(class_4587 instance, float x, float y, float z, Operation<Void> original) {
        original.call(instance, x, y, z + this.hoverStackOffset());
    }

    @Unique
    private boolean accessories$bypassSlotCheck = false;

    @Override
    public void forceRenderSlot(class_332 context, class_1735 slot) {
        this.accessories$bypassSlotCheck = true;

        this.renderSlot(context, slot);

        this.accessories$bypassSlotCheck = false;
    }
}