package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.gui.components.ComponentUtils;
import io.wispforest.accessories.client.gui.components.ComponentUtils.OnCreativeTabChange;
import io.wispforest.accessories.networking.AccessoriesNetworking;
import io.wispforest.accessories.networking.server.NukeAccessories;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1761;
import net.minecraft.class_2561;
import net.minecraft.class_481;
import net.minecraft.class_485;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_481.class)
public abstract class CreativeInventoryScreenMixin extends class_485<class_481.class_483> implements ComponentUtils.CreativeScreenExtension {

    @Shadow private static class_1761 selectedTab;

    public CreativeInventoryScreenMixin(class_481.class_483 menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
    }

    @Unique private int nukeCoolDown = 0;

    @Inject(method = "containerTick", at = @At("HEAD"))
    private void nukeCooldown(CallbackInfo ci){
        if(this.nukeCoolDown > 0) this.nukeCoolDown--;
    }

    @Inject(method = "selectTab", at = @At(value = "TAIL"))
    private void adjustAccessoryButton(class_1761 tab, CallbackInfo ci){
        getEvent().invoker().onTabChange(tab);
    }

    @Inject(method = "slotClicked", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/NonNullList;size()I", ordinal = 0, shift = At.Shift.BEFORE))
    private void clearAccessoriesWithClearSlot(class_1735 slot, int slotId, int mouseButton, class_1713 type, CallbackInfo ci) {
        if(this.nukeCoolDown <= 0) {
            AccessoriesNetworking.sendToServer(new NukeAccessories());

            this.nukeCoolDown = 10;
        }
    }

    //--

    @Unique
    private final Event<ComponentUtils.OnCreativeTabChange> onTabChangeEvent = EventFactory.createArrayBacked(ComponentUtils.OnCreativeTabChange.class, invokers -> (tab) -> {
        for (var invoker : invokers) invoker.onTabChange(tab);
    });

    @Override
    public Event<ComponentUtils.OnCreativeTabChange> getEvent() {
        return this.onTabChangeEvent;
    }

    @Override
    public class_1761 getTab() {
        return selectedTab;
    }
}
