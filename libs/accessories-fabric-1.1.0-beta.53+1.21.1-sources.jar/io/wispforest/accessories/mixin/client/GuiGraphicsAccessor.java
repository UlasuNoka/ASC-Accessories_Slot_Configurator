package io.wispforest.accessories.mixin.client;

import net.minecraft.class_1058;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_332.class)
public interface GuiGraphicsAccessor {
    @Invoker("blitSprite") void callBlitSprite(class_1058 sprite, int x, int y, int blitOffset, int width, int height);
}
