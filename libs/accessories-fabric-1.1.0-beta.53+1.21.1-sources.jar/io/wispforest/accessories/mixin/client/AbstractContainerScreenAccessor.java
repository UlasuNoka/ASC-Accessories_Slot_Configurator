package io.wispforest.accessories.mixin.client;

import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("clickedSlot") @Nullable class_1735 accessories$getClickedSlot();

    @Accessor("draggingItem") class_1799 accessories$getDraggingItem();

    @Accessor("isSplittingStack") boolean accessories$isSplittingStack();

    @Accessor("quickCraftingType") int accessories$getQuickCraftingType();

    @Invoker("recalculateQuickCraftRemaining") void accessories$recalculateQuickCraftRemaining();

    @Accessor("leftPos") int accessories$leftPos();

    @Accessor("topPos") int accessories$topPos();
}
