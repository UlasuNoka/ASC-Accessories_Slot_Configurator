package io.wispforest.accessories.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.CloseContainerTransfer;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin implements CloseContainerTransfer {

    @Unique
    private class_437 transferedScreen = null;

    @WrapOperation(method = "clientSideCloseContainer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;setScreen(Lnet/minecraft/client/gui/screens/Screen;)V"))
    private void test(class_310 instance, class_437 screen, Operation<Void> original) {
        original.call(instance, transferedScreen != null ? transferedScreen : screen);

        this.transferedScreen = null;
    }

    @Override
    public void accessories$setScreenTransfer(class_437 screen) {
        this.transferedScreen = screen;
    }
}
