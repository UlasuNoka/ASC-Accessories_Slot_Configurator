package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.AccessoriesClient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Function;
import net.minecraft.class_1041;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_310;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
    @Shadow @Final private class_1041 window;

    @Inject(method = "resizeDisplay", at = @At(value = "TAIL"))
    private void captureResize(CallbackInfo ci){
        AccessoriesClient.WINDOW_RESIZE_CALLBACK_EVENT.invoker().onResized(((class_310) ((Object) this)), this.window);
    }

    @Unique
    private static final class_2960 SPRITE_ATLAS_LOCATION = class_2960.method_60656("textures/atlas/gui.png");

    @Inject(method = "getTextureAtlas", at = @At(value = "HEAD"), cancellable = true)
    private void allowForGuiSprites(class_2960 location, CallbackInfoReturnable<Function<class_2960, class_1058>> cir) {
        if(location.equals(SPRITE_ATLAS_LOCATION)) {
            cir.setReturnValue(class_310.method_1551().method_52699()::method_18667);
        }
    }
}