package io.wispforest.accessories.mixin.client.cosmetic;

import io.wispforest.accessories.pond.CosmeticArmorLookupTogglable;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public abstract class MobMixin extends class_1309 implements CosmeticArmorLookupTogglable {

    protected MobMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getItemBySlot", at = @At("HEAD"), cancellable = true)
    private void accessories$getCosmeticAlternative(class_1304 slot, CallbackInfoReturnable<class_1799> cir) {
        CosmeticArmorLookupTogglable.getAlternativeStack(this, slot, cir::setReturnValue);
    }

    @Inject(method = "getBodyArmorItem", at = @At("HEAD"), cancellable = true)
    private void accessories$getCosmeticAlternative(CallbackInfoReturnable<class_1799> cir) {
        CosmeticArmorLookupTogglable.getAlternativeStack(this, class_1304.field_48824, cir::setReturnValue);
    }
}
