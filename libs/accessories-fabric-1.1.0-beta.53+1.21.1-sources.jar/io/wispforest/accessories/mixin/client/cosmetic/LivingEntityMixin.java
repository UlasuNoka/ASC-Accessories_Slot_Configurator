package io.wispforest.accessories.mixin.client.cosmetic;

import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.pond.CosmeticArmorLookupTogglable;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin implements CosmeticArmorLookupTogglable {

    private boolean accessories$cosmeticArmorAlternative = false;

    @Override
    public void setLookupToggle(boolean value) {
        var capability = AccessoriesCapability.get((class_1309) (Object) this);

        if(capability == null) {
            this.accessories$cosmeticArmorAlternative = false;

            return;
        }

        this.accessories$cosmeticArmorAlternative = value;
    }

    @Override
    public boolean getLookupToggle() {
        if(!((class_1309)(Object) this).method_37908().method_8608()) return false;

        return accessories$cosmeticArmorAlternative;
    }
}
