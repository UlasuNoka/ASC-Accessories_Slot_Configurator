package io.wispforest.accessories.mixin.client.cosmetic;

import io.wispforest.accessories.pond.CosmeticArmorLookupTogglable;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1531.class)
public abstract class ArmorStandMixin extends class_1309 {

    protected ArmorStandMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "getItemBySlot", at = @At("HEAD"), cancellable = true)
    private void accessories$getCosmeticAlternative(class_1304 slot, CallbackInfoReturnable<class_1799> cir) {
        CosmeticArmorLookupTogglable.getAlternativeStack(this, slot, cir::setReturnValue);
    }
}
