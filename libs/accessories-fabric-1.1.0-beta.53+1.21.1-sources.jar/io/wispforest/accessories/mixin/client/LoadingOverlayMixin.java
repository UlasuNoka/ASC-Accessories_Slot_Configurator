package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.ClientLifecycleEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_425;

@Mixin(class_425.class)
public abstract class LoadingOverlayMixin {

    @ModifyVariable(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Overlay;<init>()V", shift = At.Shift.AFTER), argsOnly = true)
    private Consumer<Optional<Throwable>> addEventHook(Consumer<Optional<Throwable>> value) {
        return (throwable) -> {
            ClientLifecycleEvents.END_DATA_PACK_RELOAD.invoker().endDataPackReload(class_310.method_1551(), throwable.isEmpty());

            value.accept(throwable);
        };
    }
}
