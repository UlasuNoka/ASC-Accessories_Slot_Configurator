package io.wispforest.accessories.mixin.client.model;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.ModelPartLoadingHelper;
import net.minecraft.class_2586;
import net.minecraft.class_5614;
import net.minecraft.class_5616;
import net.minecraft.class_827;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5616.class)
public abstract class BlockEntityRenderersMixin {

    @WrapOperation(method = "method_32145", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRendererProvider;create(Lnet/minecraft/client/renderer/blockentity/BlockEntityRendererProvider$Context;)Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderer;"))
    private static <T extends class_2586> class_827<T> accessories$attemptToSaveRoot(class_5614<T> instance, class_5614.class_5615 context, Operation<class_827<T>> original) {
        var renderer = original.call(instance, context);

        // Attempts to clear queue in case issues with saving root model part goes wrong
        ((ModelPartLoadingHelper) context.method_32142()).accessories$clearQueue();

        return renderer;
    }
}
