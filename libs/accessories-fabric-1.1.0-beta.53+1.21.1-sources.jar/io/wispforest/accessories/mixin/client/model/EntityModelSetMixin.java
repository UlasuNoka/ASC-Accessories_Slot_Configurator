package io.wispforest.accessories.mixin.client.model;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.ModelPartLoadingHelper;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_5599;
import net.minecraft.class_5607;
import net.minecraft.class_630;

@Mixin(class_5599.class)
public abstract class EntityModelSetMixin implements ModelPartLoadingHelper {

    @Unique
    private final Deque<class_630> accessories$modelPartStorage = new ArrayDeque<>();

    @Override
    public void accessories$pushRoot(class_630 root) {
        accessories$modelPartStorage.push(root);
    }

    @Override
    @Nullable
    public class_630 accessories$pollRoot() {
        return accessories$modelPartStorage.poll();
    }

    @Override
    public void accessories$clearQueue() {
        accessories$modelPartStorage.clear();
    }

    //--

    @WrapOperation(method = "bakeLayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/geom/builders/LayerDefinition;bakeRoot()Lnet/minecraft/client/model/geom/ModelPart;"))
    private class_630 accessories$saveRootPart(class_5607 instance, Operation<class_630> original) {
        var part = original.call(instance);

        accessories$pushRoot(part);

        return part;
    }
}
