package io.wispforest.accessories.mixin.client.model;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.wispforest.accessories.pond.ModelPartLoadingHelper;
import net.minecraft.class_1297;
import net.minecraft.class_5617;
import net.minecraft.class_5619;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5619.class)
public abstract class EntityRenderersMixin {

    @WrapOperation(method = {
        "method_32174",
        "lambda$createEntityRenderers$2" // Dev Neoforge
    }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/EntityRendererProvider;create(Lnet/minecraft/client/renderer/entity/EntityRendererProvider$Context;)Lnet/minecraft/client/renderer/entity/EntityRenderer;"),
        expect = 1, require = 1, allow = 1)
    private static <T extends class_1297> class_897<T> accessories$attemptToSaveRoot1(class_5617<T> instance, class_5617.class_5618 context, Operation<class_897<T>> original) {
        var renderer = original.call(instance, context);

        // Attempts to clear queue in case issues with saving root model part goes wrong
        ((ModelPartLoadingHelper) context.method_32170()).accessories$clearQueue();

        return renderer;
    }

    @WrapOperation(method = {
        "method_32175",
        "lambda$createPlayerRenderers$3" // Dev Neoforge
    }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/EntityRendererProvider;create(Lnet/minecraft/client/renderer/entity/EntityRendererProvider$Context;)Lnet/minecraft/client/renderer/entity/EntityRenderer;"),
        expect = 1, require = 1, allow = 1)
    private static <T extends class_1297> class_897<T> accessories$attemptToSaveRoot2(class_5617<T> instance, class_5617.class_5618 context, Operation<class_897<T>> original) {
        var renderer = original.call(instance, context);

        // Attempts to clear queue in case issues with saving root model part goes wrong
        ((ModelPartLoadingHelper) context.method_32170()).accessories$clearQueue();

        return renderer;
    }
}
