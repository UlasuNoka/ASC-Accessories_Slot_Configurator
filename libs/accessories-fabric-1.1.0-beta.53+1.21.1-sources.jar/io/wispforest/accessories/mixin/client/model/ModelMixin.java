package io.wispforest.accessories.mixin.client.model;

import io.wispforest.accessories.pond.ModelPartLoadingHelper;
import io.wispforest.accessories.pond.ModelRootAccess;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Function;
import net.minecraft.class_310;
import net.minecraft.class_3879;
import net.minecraft.class_5597;
import net.minecraft.class_5599;
import net.minecraft.class_630;

@Mixin(class_3879.class)
public abstract class ModelMixin implements ModelRootAccess {

    @Nullable
    @Unique
    private class_630 accessories$rootPart = null;

    @Inject(method = "<init>", at = @At(value = "TAIL"))
    private void accessories$saveRootPart(Function renderType, CallbackInfo ci) {
        if (((class_3879)(Object) this) instanceof class_5597<?>) return;

        // For cases where Modder's bypass model loading and instantiate models outside such loading
        var modelSet = class_310.method_1551().method_31974();
        if (modelSet == null) return;

        this.accessories$rootPart = ((ModelPartLoadingHelper) modelSet).accessories$pollRoot();
    }

    @Override
    @Nullable
    public class_630 accessories$rootPart() {
        if (((class_3879)(Object) this) instanceof class_5597<?> hierarchicalModel){
            return hierarchicalModel.method_32008();
        }

        return this.accessories$rootPart;
    }
}
