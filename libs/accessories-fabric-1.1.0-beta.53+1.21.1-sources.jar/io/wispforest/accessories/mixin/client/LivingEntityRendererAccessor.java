package io.wispforest.accessories.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_3887;
import net.minecraft.class_583;
import net.minecraft.class_922;

@Mixin(class_922.class)
public interface LivingEntityRendererAccessor<T extends class_1309, M extends class_583<T>> {
    @Accessor("layers") List<class_3887<T, M>> getLayers();
}