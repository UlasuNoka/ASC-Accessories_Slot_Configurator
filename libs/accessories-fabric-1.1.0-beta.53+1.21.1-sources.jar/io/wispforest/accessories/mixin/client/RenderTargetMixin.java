package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.client.AccessoriesClient;
import io.wispforest.accessories.pond.AccessoriesFrameBufferExtension;
import net.minecraft.class_276;
import net.minecraft.class_5944;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_276.class)
public abstract class RenderTargetMixin implements AccessoriesFrameBufferExtension {

    @Unique
    private boolean useHighlightShader = false;

    @ModifyVariable(method = "_blitToScreen", at = @At(value = "CONSTANT", args = "stringValue=DiffuseSampler", shift = At.Shift.BEFORE))
    private class_5944 gliscoLikesShaders(class_5944 value) {
        if (this.useHighlightShader) return AccessoriesClient.BLIT_SHADER;
        return value;
    }

    @Override
    public void accessories$setUseHighlightShader(boolean useHighlightShader) {
        this.useHighlightShader = useHighlightShader;
    }
}
