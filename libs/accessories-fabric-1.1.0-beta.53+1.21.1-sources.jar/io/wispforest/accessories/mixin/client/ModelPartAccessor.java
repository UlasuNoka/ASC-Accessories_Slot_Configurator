package io.wispforest.accessories.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.Map;
import net.minecraft.class_630;

@Mixin(class_630.class)
public interface ModelPartAccessor {
    @Accessor("cubes") List<class_630.class_628> getCubes();

    @Accessor("children") Map<String, class_630> getChildren();
}
