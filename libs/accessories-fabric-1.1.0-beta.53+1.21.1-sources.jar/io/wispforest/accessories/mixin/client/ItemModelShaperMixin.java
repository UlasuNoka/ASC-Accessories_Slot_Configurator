package io.wispforest.accessories.mixin.client;

import io.wispforest.accessories.api.components.AccessoriesDataComponents;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_1799;
import net.minecraft.class_763;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_763.class)
public abstract class ItemModelShaperMixin {
    @Shadow @Final private class_1092 modelManager;

    @Inject(method = "getItemModel(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/client/resources/model/BakedModel;", at = @At("HEAD"), cancellable = true)
    private void accessories$adjustModelFromComponent(class_1799 stack, CallbackInfoReturnable<class_1087> cir) {
        if (!stack.method_57826(AccessoriesDataComponents.ITEM_MODEL_OVERRIDE)) return;

        var model = this.modelManager.method_4742(class_1091.method_61078(stack.method_57824(AccessoriesDataComponents.ITEM_MODEL_OVERRIDE).id()));

        cir.setReturnValue(model);
    }
}
