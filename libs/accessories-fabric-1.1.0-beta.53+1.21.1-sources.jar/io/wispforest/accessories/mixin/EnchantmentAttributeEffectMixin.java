package io.wispforest.accessories.mixin;

import com.google.common.collect.HashMultimap;
import io.wispforest.accessories.AccessoriesInternals;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_6880;
import net.minecraft.class_9720;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9720.class)
public abstract class EnchantmentAttributeEffectMixin {

    @Inject(method = "makeAttributeMap", at = @At("HEAD"), cancellable = true)
    private void returnEmptyIfAccessoriesSlot(int i, class_1304 equipmentSlot, CallbackInfoReturnable<HashMultimap<class_6880<class_1320>, class_1322>> cir) {
        if(equipmentSlot.equals(AccessoriesInternals.INTERNAL_SLOT)) cir.setReturnValue(HashMultimap.create());
    }
}
