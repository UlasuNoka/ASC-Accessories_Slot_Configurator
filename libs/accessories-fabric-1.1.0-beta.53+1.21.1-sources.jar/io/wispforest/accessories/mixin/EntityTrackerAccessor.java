package io.wispforest.accessories.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_3898;
import net.minecraft.class_5629;

@Mixin(class_3898.class_3208.class)
public interface EntityTrackerAccessor {
    @Accessor("seenBy")
    Set<class_5629> accessories$getSeenBy();
}
