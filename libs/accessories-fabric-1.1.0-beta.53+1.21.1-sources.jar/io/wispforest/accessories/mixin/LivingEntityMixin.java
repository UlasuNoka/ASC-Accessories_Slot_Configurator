package io.wispforest.accessories.mixin;

import Z;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.api.SoundEventData;
import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import io.wispforest.accessories.api.slot.SlotReference;
import io.wispforest.accessories.data.EntitySlotLoader;
import io.wispforest.accessories.impl.AccessoriesCapabilityImpl;
import io.wispforest.accessories.pond.AccessoriesAPIAccess;
import io.wispforest.accessories.pond.AccessoriesLivingEntityExtension;
import java.util.Map;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_5712;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 implements AccessoriesAPIAccess, AccessoriesLivingEntityExtension {

    @Unique
    private AccessoriesCapabilityImpl capability = null;

    protected LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Unique
    private AccessoriesCapability getOrCreateAccessoriesCapability() {
        if (capability == null) {
            this.capability = new AccessoriesCapabilityImpl((class_1309) (Object) this);
        }

        return capability;
    }

    @Override
    @Nullable
    public AccessoriesCapability accessoriesCapability() {
        var slots = EntitySlotLoader.getEntitySlots((class_1309) (Object) this);

        if(slots.isEmpty()) return null;

        var capability = getOrCreateAccessoriesCapability();

        // Used to init some functions behind the scene
        capability.getHolder();

        return capability;
    }

    @Override
    @Nullable
    public AccessoriesHolder accessoriesHolder() {
        var capability = getOrCreateAccessoriesCapability();

        return capability != null ? capability.getHolder() : null;
    }

    //--

    @Inject(method = "onEquippedItemBroken", at = @At("HEAD"), cancellable = true)
    private void sendAccessoriesBreakInstead(class_1792 item, class_1304 slot, CallbackInfo ci){
        if(slot.equals(AccessoriesInternals.INTERNAL_SLOT)) ci.cancel();
    }

    @Inject(method = "entityEventForEquipmentBreak", at = @At("HEAD"), cancellable = true)
    private static void preventMatchExceptionForAccessories(class_1304 slot, CallbackInfoReturnable<Byte> cir) {
        if(slot.equals(AccessoriesInternals.INTERNAL_SLOT)) cir.setReturnValue((byte) -1);
    }

    public void onEquipItem(SlotReference slotReference, class_1799 oldItem, class_1799 newItem) {
        var level = this.method_37908();

        if (!class_1799.method_31577(oldItem, newItem) && !this.field_5953 && !level.method_8608() && !this.method_7325()) {
            var isEquitableFor = newItem.method_7960() || AccessoriesAPI.canInsertIntoSlot(newItem, slotReference);

            if (!this.method_5701() && !newItem.method_7960()) {
                var sound = AccessoriesAPI.getOrDefaultAccessory(newItem).getEquipSound(newItem, slotReference);

                if(sound != null) level.method_47967(null, this.method_23317(), this.method_23318(), this.method_23321(), sound.event().comp_349(), this.method_5634(), sound.volume(), sound.pitch(), this.field_5974.method_43055());
            }

            if (isEquitableFor) this.method_32876(!newItem.method_7960() ? class_5712.field_28739 : class_5712.field_45787);
        }
    }

    //--

    @ModifyReturnValue(method = "canFreeze", at = @At(value = "RETURN", ordinal = 1))
    private boolean canFreezeAccessoriesCheck(boolean bl) {
        var state = ExtraEventHandler.canFreezeEntity((class_1309) (Object) this);

        return state.orElse(bl);
    }

//    @WrapOperation(method = "getDamageAfterMagicAbsorb", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getArmorAndBodyArmorSlots()Ljava/lang/Iterable;"))
//    private Iterable<ItemStack> addAccessories(LivingEntity instance, Operation<Iterable<ItemStack>> original){
//        var iterable = original.call(instance);
//
//        if((Object) this instanceof LivingEntity livingEntity) {
//            var capability = livingEntity.accessoriesCapability();
//
//            if(capability != null) iterable = Iterables.concat(iterable, capability.getAllEquipped().stream().map(SlotEntryReference::stack).toList());
//        }
//
//        return iterable;
//    }

    // TODO: SEEM IF THIS IS STILL SOMETHING TO HAVE WITHIN THE FUTURE! BUGS OCCUR THOUGH WITH INV HUD+
//    @ModifyReturnValue(method = "getAllSlots", at = @At("RETURN"))
//    private Iterable<ItemStack> addAccessories(Iterable<ItemStack> original){
//        if((Object) this instanceof LivingEntity livingEntity && !livingEntity.isRemoved()) {
//            var capability = livingEntity.accessoriesCapability();
//
//            if(capability != null) return Iterables.concat(original, capability.getAllEquipped().stream().map(SlotEntryReference::stack).toList());
//        }
//
//        return original;
//    }
}
