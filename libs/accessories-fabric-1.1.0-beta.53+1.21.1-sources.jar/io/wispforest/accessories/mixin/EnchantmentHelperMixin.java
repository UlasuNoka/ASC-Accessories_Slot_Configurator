package io.wispforest.accessories.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.wispforest.accessories.AccessoriesInternals;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.AccessoriesCapability;
import io.wispforest.accessories.api.data.AccessoriesTags;
import io.wispforest.accessories.api.slot.SlotEntryReference;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2378;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.class_9699;

@Mixin(class_1890.class)
public abstract class EnchantmentHelperMixin {

    @Shadow
    private static void runIterationOnItem(class_1799 itemStack, class_1304 equipmentSlot, class_1309 livingEntity, class_1890.class_9702 enchantmentInSlotVisitor) {}

    @WrapOperation(method = "getEnchantmentLevel", at = @At(value = "INVOKE", target = "Ljava/util/Map;values()Ljava/util/Collection;"))
    private static Collection<class_1799> addAccessoriesStacks(Map instance, Operation<Collection<class_1799>> original, @Local(argsOnly = true) class_6880<class_1887> enchantment, @Local(argsOnly = true) class_1309 entity){
        var stacks = original.call(instance);

        //if(Accessories.enchantmentValidForRedirect(enchantment)) {
        var capability = entity.accessoriesCapability();

        if(capability != null) {
            stacks = new ArrayList<>(stacks);

            for (var slotEntryReference : capability.getAllEquipped()) {
                stacks.add(slotEntryReference.stack());
            }
        }
        //}

        return stacks;
    }

    @Inject(method = "getRandomItemWith", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getRandom()Lnet/minecraft/util/RandomSource;"))
    private static void adjustListForAccessories(class_9331<?> dataComponentType, class_1309 livingEntity, Predicate<class_1799> predicate, CallbackInfoReturnable<Optional<class_9699>> cir, @Local(ordinal = 0) List<class_9699> list) {
        var capability = livingEntity.accessoriesCapability();

        if(capability != null){
            for (var ref : capability.getAllEquipped()) {
                var itemStack = ref.stack();

                if(!predicate.test(ref.stack())) continue;

                var itemEnchantments = itemStack.method_57825(class_9334.field_49633, class_9304.field_49385);

                for(var entry : itemEnchantments.method_57539()) {
                    var holder = entry.getKey();
                    var value = holder.comp_349();

                    if (value.comp_2689().method_57832(dataComponentType) && enchantmentValidForRedirect(livingEntity.method_56673(), value)) { //((Enchantment)holder.value()).matchingSlot(equipmentSlot)
                        list.add(new class_9699(itemStack, AccessoriesInternals.INTERNAL_SLOT, livingEntity, item -> AccessoriesAPI.breakStack(ref.reference())));
                    }
                }
            }
        }
    }

    @Inject(method = "runIterationOnEquipment", at = @At("TAIL"))
    private static void adjustIterationWithAccessories(class_1309 livingEntity, class_1890.class_9702 enchantmentInSlotVisitor, CallbackInfo ci) {
        var capability = livingEntity.accessoriesCapability();

        if(capability != null){
            for (var ref : capability.getAllEquipped()) {
                runIterationOnItem(ref.stack(), AccessoriesInternals.INTERNAL_SLOT, livingEntity, enchantmentInSlotVisitor);
            }
        }
    }

    @ModifyExpressionValue(
            method = "runIterationOnItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/enchantment/EnchantmentHelper$EnchantmentInSlotVisitor;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/Enchantment;matchingSlot(Lnet/minecraft/world/entity/EquipmentSlot;)Z")
    )
    private static boolean adjustIfIterationOccurs(boolean original, @Local(argsOnly = true) class_1304 equipmentSlot, @Local(argsOnly = true) class_1309 livingEntity, @Local(ordinal = 0) class_6880<class_1887> holder) {
        if(equipmentSlot.equals(AccessoriesInternals.INTERNAL_SLOT) && enchantmentValidForRedirect(livingEntity.method_56673(), holder.comp_349())) {
            return true;
        }

        return original;
    }

    @Unique
    private static boolean enchantmentValidForRedirect(class_5455 access, class_1887 enchantment) {
        var enchantments = access.method_33310(class_7924.field_41265).orElseThrow();

        return !enchantments.method_40264(enchantments.method_29113(enchantment).orElseThrow())
                .orElseThrow()
                .method_40220(AccessoriesTags.INVALID_FOR_REDIRECTION);
    }
}
