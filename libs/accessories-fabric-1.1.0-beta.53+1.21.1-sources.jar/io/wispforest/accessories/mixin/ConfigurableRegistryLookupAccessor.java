package io.wispforest.accessories.mixin;

import net.minecraft.class_5350;
import net.minecraft.class_5455;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5350.class_9180.class)
public interface ConfigurableRegistryLookupAccessor {
    @Accessor("registryAccess")
    class_5455 getRegistryAccess();
}
