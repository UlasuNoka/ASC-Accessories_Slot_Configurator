package io.wispforest.accessories.mixin;

import io.wispforest.accessories.pond.DroppedStacksExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

@Mixin(class_1657.class)
public abstract class PlayerMixin implements DroppedStacksExtension {

    @Unique
    private Collection<class_1799> toBeDroppedStacks = List.of();

    @Override
    public void addToBeDroppedStacks(Collection<class_1799> list) {
        this.toBeDroppedStacks = list;
    }

    @Override
    public Collection<class_1799> toBeDroppedStacks() {
        return this.toBeDroppedStacks;
    }
}
