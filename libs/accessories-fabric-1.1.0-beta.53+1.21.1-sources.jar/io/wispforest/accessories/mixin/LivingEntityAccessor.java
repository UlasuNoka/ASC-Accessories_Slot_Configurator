package io.wispforest.accessories.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {
    @Invoker("breakItem") public void accessors$breakItem(class_1799 stack);
}
