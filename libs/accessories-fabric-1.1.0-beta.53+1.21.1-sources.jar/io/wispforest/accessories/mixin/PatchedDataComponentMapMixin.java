package io.wispforest.accessories.mixin;

import Z;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.wispforest.accessories.pond.stack.PatchedDataComponentMapExtension;
import io.wispforest.accessories.utils.ItemStackMutation;
import io.wispforest.owo.util.EventStream;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import net.minecraft.class_9335;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import java.util.Map.Entry;

@Mixin(class_9335.class)
public abstract class PatchedDataComponentMapMixin implements PatchedDataComponentMapExtension {

    @Unique
    private boolean changeCheckStack = false;

    @Nullable
    private class_1799 itemStack = null;

    @Nullable
    private EventStream<ItemStackMutation> mutationEvent = null;

    @Override
    public EventStream<ItemStackMutation> accessories$getMutationEvent(class_1799 itemStack) {
        Objects.requireNonNull(itemStack);

        this.itemStack = itemStack;

        if (mutationEvent == null) {
            mutationEvent = new EventStream<>(invokers -> (stack, types) -> {
                invokers.forEach(itemStackMutation -> itemStackMutation.onMutation(stack, types));
            });
        }

        return mutationEvent;
    }

    @Override
    public boolean accessories$hasChanged() {
        var bl = changeCheckStack;

        this.changeCheckStack = false;

        return bl;
    }

    @Inject(method = "set", at = @At("HEAD"))
    private <T> void accessories$updateChangeValue_set(class_9331<? super T> component, @Nullable T value, CallbackInfoReturnable<T> cir){
        this.changeCheckStack = true;

        this.accessories$handleMutationEvent(List.of(component));
    }

    @Inject(method = "remove", at = @At("HEAD"))
    private <T> void accessories$updateChangeValue_remove(class_9331<? super T> component, CallbackInfoReturnable<T> cir){
        this.changeCheckStack = true;

        this.accessories$handleMutationEvent(List.of(component));
    }

    @Unique
    private boolean inApplyPatchLock = false;

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentPatch;)V", at = @At("HEAD"))
    private void accessories$updateChangeValue_applyPatchHead(class_9326 patch, CallbackInfo ci){
        this.changeCheckStack = true;

        this.inApplyPatchLock = true;
    }

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentPatch;)V", at = @At("TAIL"))
    private void accessories$updateChangeValue_applyPatchTail(class_9326 patch, CallbackInfo ci){
        this.inApplyPatchLock = false;

        var list = new ArrayList<class_9331<?>>();
        for (var entry : patch.method_57846()) list.add(entry.getKey());
        this.accessories$handleMutationEvent(list);
    }

    @Inject(method = "applyPatch(Lnet/minecraft/core/component/DataComponentType;Ljava/util/Optional;)V", at = @At("HEAD"))
    private void accessories$updateChangeValue_applyPatch(class_9331<?> component, Optional<?> value, CallbackInfo ci){
        this.changeCheckStack = true;

        if (!this.inApplyPatchLock) {
            this.accessories$handleMutationEvent(List.of(component));
        }
    }

    @Inject(method = "restorePatch", at = @At("HEAD"))
    private void accessories$updateChangeValue_restorePatch(class_9326 patch, CallbackInfo ci){
        this.changeCheckStack = true;

        var list = new ArrayList<class_9331<?>>();
        for (var entry : patch.method_57846()) list.add(entry.getKey());
        this.accessories$handleMutationEvent(list);
    }

    @Unique
    private void accessories$handleMutationEvent(List<class_9331<?>> changedDataTypes) {
        if(this.mutationEvent == null) return;

        this.mutationEvent.sink().onMutation(this.itemStack, changedDataTypes);
    }
}
