package io.wispforest.accessories.mixin;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.class_3898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3898.class)
public interface ServerChunkLoadingManagerAccessor {
    @Accessor("entityMap")
    Int2ObjectMap<EntityTrackerAccessor> accessories$getEntityMap();
}
