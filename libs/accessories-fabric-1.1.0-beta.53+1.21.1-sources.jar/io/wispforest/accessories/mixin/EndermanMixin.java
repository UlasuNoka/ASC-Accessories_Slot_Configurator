package io.wispforest.accessories.mixin;

import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1560.class)
public abstract class EndermanMixin {

    @Inject(method = "isLookingAtMe", at = @At("HEAD"), cancellable = true)
    private void isEndermanMaskAccessory(class_1657 player, CallbackInfoReturnable<Boolean> cir){
        var state = ExtraEventHandler.isEndermanMask(player, (class_1560) (Object) this);

        if(state != TriState.DEFAULT) cir.setReturnValue(state.orElse(false));
    }
}
