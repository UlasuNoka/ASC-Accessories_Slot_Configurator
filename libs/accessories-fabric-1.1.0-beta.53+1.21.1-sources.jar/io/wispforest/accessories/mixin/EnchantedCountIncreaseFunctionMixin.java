package io.wispforest.accessories.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import net.minecraft.class_125;
import net.minecraft.class_1309;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_47;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_125.class)
public abstract class EnchantedCountIncreaseFunctionMixin {

    @WrapOperation(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;getEnchantmentLevel(Lnet/minecraft/core/Holder;Lnet/minecraft/world/entity/LivingEntity;)I"))
    private int attemptAdjustCountWithAccessoriesLooting(class_6880<class_1887> holder, class_1309 livingEntity, Operation<Integer> original, @Local(argsOnly = true) class_47 context) {
        var amount = original.call(holder, livingEntity);

        if(holder.comp_349() == livingEntity.method_56673().method_46762(class_7924.field_41265).method_46747(class_1893.field_9110).comp_349()){
            amount = ExtraEventHandler.lootingAdjustments(livingEntity, context, amount);
        }

        return amount;
    }
}
