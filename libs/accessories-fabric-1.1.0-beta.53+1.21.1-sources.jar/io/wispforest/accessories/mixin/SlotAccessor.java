package io.wispforest.accessories.mixin;

import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1735.class)
public interface SlotAccessor {
    @Mutable @Accessor("y") void accessories$setY(int y);
}
