package io.wispforest.accessories.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.wispforest.accessories.api.events.extra.ExtraEventHandler;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_47;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_94;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_94.class)
public abstract class ApplyBonusCountMixin {

    @Shadow @Final private class_6880<class_1887> enchantment;

    @ModifyArg(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/loot/functions/ApplyBonusCount$Formula;calculateNewCount(Lnet/minecraft/util/RandomSource;II)I"), index = 2)
    private int test(int value, @Local(argsOnly = true) class_47 context){
        return (this.enchantment.comp_349() == context.method_299().method_30349().method_33310(class_7924.field_41265).orElseThrow().method_40290(class_1893.field_9130).comp_349())
                ? ExtraEventHandler.fortuneAdjustment(context, value)
                : value;
    }
}
