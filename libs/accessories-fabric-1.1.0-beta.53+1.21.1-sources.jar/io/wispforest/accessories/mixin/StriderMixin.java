package io.wispforest.accessories.mixin;

import io.wispforest.accessories.pond.ItemBasedSteerable;
import net.minecraft.class_4980;
import net.minecraft.class_4985;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_4985.class)
public abstract class StriderMixin implements ItemBasedSteerable {

    @Shadow
    @Final
    private class_4980 steering;

    @Override
    public class_4980 getInstance() {
        return steering;
    }
}
