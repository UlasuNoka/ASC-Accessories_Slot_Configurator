package io.wispforest.accessories.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1714;
import net.minecraft.class_1731;
import net.minecraft.class_1937;
import net.minecraft.class_3955;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1714.class)
public interface CraftingMenuAccessor {
    @Invoker("slotChangedCraftingGrid")
    static void accessories$slotChangedCraftingGrid(class_1703 abstractContainerMenu, class_1937 level, class_1657 player, class_8566 craftingContainer, class_1731 resultContainer, @Nullable class_8786<class_3955> recipeHolder) {}
}
