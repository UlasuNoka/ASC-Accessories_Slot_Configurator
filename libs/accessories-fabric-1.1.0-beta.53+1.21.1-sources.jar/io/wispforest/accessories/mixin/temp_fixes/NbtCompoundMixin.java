package io.wispforest.accessories.mixin.temp_fixes;

import ;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2514;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Debug;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

// TODO: REMOVE IN THE FUTURE 1.21.5?
@Debug(export = true)
@Mixin(class_2487.class)
public abstract class NbtCompoundMixin {

    @Shadow @Nullable public abstract class_2520 get(String string);

    @Inject(method = "hasUUID", at = @At(value = "JUMP", opcode = Opcodes.IFNULL, ordinal = 0), cancellable = true)
    private void adjustCheckForListVariants(String key, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 0) class_2520 tag) {
        if(tag instanceof class_2499 listTag && listTag.method_10601() == class_2520.field_33253 && listTag.size() == 4) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getByteArray", at = @At(value = "HEAD"), cancellable = true)
    private void adjustByteArrayForRegularList(String key, CallbackInfoReturnable<byte[]> cir) {
        if(get(key) instanceof class_2499 listTag && listTag.method_10601() == class_2520.field_33251) {
            var array = new byte[listTag.size()];

            for (int i = 0; i < listTag.size(); i++) {
                var tagEntry = listTag.method_10534(i);

                array[i] = ((class_2514) tagEntry).method_10698();
            }

            cir.setReturnValue(array);
        }
    }

    @Inject(method = "getIntArray", at = @At(value = "HEAD"), cancellable = true)
    private void adjustIntArrayForRegularList(String key, CallbackInfoReturnable<int[]> cir) {
        if(get(key) instanceof class_2499 listTag && listTag.method_10601() == class_2520.field_33253) {
            var array = new int[listTag.size()];

            for (int i = 0; i < listTag.size(); i++) {
                var tagEntry = listTag.method_10534(i);

                array[i] = ((class_2514) tagEntry).method_10701();
            }

            cir.setReturnValue(array);
        }
    }

    @Inject(method = "getLongArray", at = @At(value = "HEAD"), cancellable = true)
    private void adjustLongArrayForRegularList(String key, CallbackInfoReturnable<long[]> cir) {
        if(get(key) instanceof class_2499 listTag && listTag.method_10601() == class_2520.field_33254) {
            var array = new long[listTag.size()];

            for (int i = 0; i < listTag.size(); i++) {
                var tagEntry = listTag.method_10534(i);

                array[i] = ((class_2514) tagEntry).method_10699();
            }

            cir.setReturnValue(array);
        }
    }
}
