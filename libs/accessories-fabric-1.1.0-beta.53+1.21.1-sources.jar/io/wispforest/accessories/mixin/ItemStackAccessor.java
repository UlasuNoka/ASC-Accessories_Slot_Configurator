package io.wispforest.accessories.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.function.Consumer;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_6880;
import net.minecraft.class_9335;

@Mixin(class_1799.class)
public interface ItemStackAccessor {
    @Invoker("addModifierTooltip")
    void accessories$addModifierTooltip(Consumer<class_2561> consumer, @Nullable class_1657 player, class_6880<class_1320> holder, class_1322 attributeModifier);

    @Accessor("components")
    class_9335 accessories$components();
}
