package io.wispforest.accessories.mixin;

import net.minecraft.class_174;
import net.minecraft.class_179;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_174.class)
public interface CriteriaTriggersAccessor {

    @Invoker("register")
    static <T extends class_179<?>> T accessories$callRegister(String name, T trigger) {
        throw new UnsupportedOperationException();
    }
}